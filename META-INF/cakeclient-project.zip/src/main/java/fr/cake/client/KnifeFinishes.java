package fr.cake.client;
public final class KnifeFinishes{public static final String[] NAMES={"Factory CS","Amethyst Marble","Blackout","Solar Fade","Damascus","Carbon Weave","Crimson Web","Aurora","Porcelain","Circuit","Obsidian Gold","Ice Fracture","Bronze Patina","Ember"};}
