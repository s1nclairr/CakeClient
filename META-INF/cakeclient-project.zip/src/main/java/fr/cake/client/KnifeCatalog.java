package fr.cake.client;

/** Stable saved indices. Each entry is backed by its own CS2 source mesh and clips. */
public final class KnifeCatalog {
 private KnifeCatalog(){}
 public static final String[] IDS={"karambit","butterfly","bayonet","bowie","classic","m9","flip","gut","huntsman","falchion","shadow","navaja","stiletto","ursus","talon","skeleton","nomad","paracord","survival","kukri","default_ct","default_t"};
 public static final String[] LABELS={"Karambit","Butterfly","Baïonnette","Bowie","Classic","M9 Bayonet","Flip","Gut","Huntsman","Falchion","Shadow Daggers","Navaja","Stiletto","Ursus","Talon","Skeleton","Nomad","Paracord","Survival","Kukri","Couteau CT","Couteau T"};
 public static final int COUNT=IDS.length;
}
