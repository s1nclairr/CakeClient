package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class PanelUploadTest {
 @Test void unchanged1080pPixelsRequireNoUpload(){int[] frame=new int[1920*1080];java.util.Arrays.fill(frame,0xff201030);assertNull(DirtyRegion.between(frame,frame.clone(),1920,1080));}
 @Test void movingAControlUpdatesOnlyItsBounds(){int[] old=new int[1920*1080],next=old.clone();next[400*1920+390]=0xffabcdef;next[420*1920+450]=0xff000001;assertEquals(new DirtyRegion(390,400,61,21),DirtyRegion.between(next,old,1920,1080));}
 @Test void dirtyBoundsIncludeEdgesAndDoNotMissClearedAlpha(){int[] old=new int[24],next=old.clone();old[0]=0xff123456;next[23]=1;assertEquals(new DirtyRegion(0,0,6,4),DirtyRegion.between(next,old,6,4));}
}
