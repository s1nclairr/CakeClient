package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.*;import java.util.*;import java.util.zip.*;
class Visual67Test {
 @Test void catalogAlwaysCyclesOnlyAvailableAssets(){for(int item=0;item<5;item++){int id=0;Set<Integer> seen=new HashSet<>();do{id=PvpCatalog.next(item,id,1);assertTrue(PvpCatalog.get(id).supports(item));assertTrue(seen.add(id));}while(id!=0);assertTrue(seen.size()>=11);assertEquals(0,PvpCatalog.valid(item,-1));assertEquals(0,PvpCatalog.valid(item,500));}}
 @Test void independentPackImagesDecodeAndModelTextureReferencesResolve()throws Exception{
  for(var choice:PvpCatalog.CHOICES){if(choice.id()<=8)continue;for(int item:choice.items())try(var in=getClass().getResourceAsStream("/assets/cakeclient/pvp/"+choice.id()+"-"+item+".zip")){assertNotNull(in);Set<String> paths=new HashSet<>();Map<String,byte[]> entries=new HashMap<>();try(var zip=new ZipInputStream(in)){ZipEntry e;while((e=zip.getNextEntry())!=null){assertTrue(paths.add(e.getName()));entries.put(e.getName(),zip.readAllBytes());}}assertFalse(entries.isEmpty());for(var e:entries.entrySet()){if(e.getKey().endsWith(".png")){var image=javax.imageio.ImageIO.read(new ByteArrayInputStream(e.getValue()));assertNotNull(image,e.getKey());assertTrue(image.getWidth()>0);}if(e.getKey().contains("/models/item/")&&e.getKey().endsWith(".json")){var model=com.google.gson.JsonParser.parseString(new String(e.getValue(),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();if(model.has("textures"))for(var t:model.getAsJsonObject("textures").entrySet()){String tex=t.getValue().getAsString();if(tex.startsWith("#"))continue;String path=tex.contains(":")?"assets/"+tex.replace(":","/textures/")+".png":"assets/minecraft/textures/"+tex+".png";assertTrue(entries.containsKey(path),choice.name()+" "+path);}}}
   try(var preview=getClass().getResourceAsStream("/assets/cakeclient/pvp/previews/"+choice.id()+"-"+item+"-0.png")){assertNotNull(preview,choice.name());var image=javax.imageio.ImageIO.read(preview);assertEquals(1080,image.getWidth());assertEquals(1080,image.getHeight());}
  }}
 }
 @Test void malformedAvatarFailsWithAnIoError(){assertThrows(IOException.class,()->AvatarMesh.read(new ByteArrayInputStream(new byte[]{1,2,3})));}
}
