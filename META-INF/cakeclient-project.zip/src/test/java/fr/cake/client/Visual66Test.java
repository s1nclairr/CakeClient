package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;import java.nio.*;import java.util.*;import java.io.*;
class Visual66Test{
 @Test void allAvatarsRetainRealWeightedGeometryAndOriginalMotion()throws Exception{
  var hashes=new HashSet<Integer>();for(var id:SkinCatalog.IDS)try(var in=getClass().getResourceAsStream("/assets/cakeclient/avatars/"+AvatarSkins.IDS[id-1]+".avm")){
   assertNotNull(in,"skin "+id);byte[] bytes=in.readAllBytes();assertTrue(hashes.add(Arrays.hashCode(bytes)));var mesh=AvatarMesh.read(new ByteArrayInputStream(bytes));assertTrue(mesh.vertices>=100);assertTrue(mesh.indices.length>=300);assertTrue(mesh.bones>=1);
   for(int v=0;v<mesh.vertices;v++){float sum=0;for(int k=0;k<4;k++)sum+=mesh.data[v*12+8+k];assertEquals(1,sum,.0001);}
   for(double time:new double[]{0,.17,.43,1.1})for(var matrix:mesh.pose(time,time,.65f))assertTrue(matrix.isFinite());
   var pose=mesh.pose(.13,.13,0);float min=Float.POSITIVE_INFINITY,max=Float.NEGATIVE_INFINITY;for(int v=0;v<mesh.vertices;v++){var point=new org.joml.Vector3f();for(int k=0;k<4;k++){int i=v*12;var p=pose[mesh.joints[v*4+k]].transformPosition(mesh.data[i],mesh.data[i+1],mesh.data[i+2],new org.joml.Vector3f());point.fma(mesh.data[i+8+k],p);}min=Math.min(min,point.y);max=Math.max(max,point.y);}assertTrue(max-min>1.4&&max-min<2.2,id+" normalized height");
  }
 }
 @Test void everyPvpOptionContainsEveryRequiredTexture()throws Exception{String[] files={"entity_end_crystal_end_crystal.png","item_mace.png","item_totem_of_undying.png","block_obsidian.png","block_respawn_anchor_top.png","block_respawn_anchor_bottom.png","block_respawn_anchor_side0.png","block_respawn_anchor_side1.png","block_respawn_anchor_side2.png","block_respawn_anchor_side3.png","block_respawn_anchor_side4.png"};for(int i=1;i<=8;i++)for(var file:files)try(var in=getClass().getResourceAsStream("/assets/cakeclient/pvp/"+i+"/"+file)){assertNotNull(in,i+"/"+file);assertNotNull(javax.imageio.ImageIO.read(in));}}
}
