package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class CsSourceV6Test {
 @Test void karambitPalmMatchesOriginalWristAndMiddleKnuckleInsteadOfWeaponPivot()throws Exception{
  var model=CsKnifeAsset.load("karambit");var p=model.clips[0].hand(0);
  assertEquals(0.08559642,p.x,.00002);assertEquals(-0.10561211,p.y,.00002);assertEquals(-0.45345540,p.z,.00002);
 }
 @Test void bayonetAndBowieHaveTheirOwnInspectionAndDrawClips()throws Exception{
  var bayonet=CsKnifeAsset.load("bayonet");var bowie=CsKnifeAsset.load("bowie");
  assertEquals(6.2,bayonet.clips[bayonet.find("inspect")].duration,.0001);
  assertEquals(6.1666,bowie.clips[bowie.find("inspect")].duration,.0001);
  assertEquals(1.1666,bayonet.clips[bayonet.find("deploy")].duration,.0001);
  assertEquals(1.1,bowie.clips[bowie.find("deploy")].duration,.0001);
  assertFalse(bayonet.clips[1].matrix(0,1).equals(bowie.clips[1].matrix(0,1),.001f));
 }
 @Test void butterflyIncludesDistinctOriginalInspectAndDrawVariants()throws Exception{
  var model=CsKnifeAsset.load("butterfly");
  for(String alias:new String[]{"inspect2","inspect3","deploy2"})assertTrue(model.find(alias)>=0);
  assertFalse(model.clips[model.find("inspect")].matrix(0,.3).equals(model.clips[model.find("inspect2")].matrix(0,.3),.001f));
 }
}
