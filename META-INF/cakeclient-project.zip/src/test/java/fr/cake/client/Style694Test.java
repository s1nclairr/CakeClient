package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;import java.util.zip.*;
class Style694Test{
 @Test void dampedCapeSettlesAtItsTargetWithoutDiverging(){float x=0,v=0,target=.7f;for(int i=0;i<600;i++){v=CapeCloth.integrate(x,v,target,1/60f);x+=v/60f;assertTrue(Float.isFinite(x));assertTrue(Math.abs(x)<2);}assertEquals(target,x,.001);}
 @Test void externalShaderCarriesSourceAndOriginalLicense()throws Exception{boolean shader=false,license=false;try(var zip=new ZipInputStream(getClass().getResourceAsStream("/assets/cakeclient/realism/MakeUp-UltraFast-9.6.zip"))){ZipEntry e;while((e=zip.getNextEntry())!=null){if(e.getName().equals("shaders/shaders.properties"))shader=true;if(e.getName().equals("LICENSE")){license=new String(zip.readAllBytes()).contains("LESSER GENERAL PUBLIC LICENSE");}}}assertTrue(shader);assertTrue(license);}
}
