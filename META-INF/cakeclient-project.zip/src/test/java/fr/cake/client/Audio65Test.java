package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.google.gson.*;
import java.io.*;
class Audio65Test {
 private JsonObject read(String p)throws Exception{try(var in=getClass().getResourceAsStream(p)){assertNotNull(in,p);return JsonParser.parseReader(new InputStreamReader(in)).getAsJsonObject();}}
 @Test void originalCuesResolveToPackagedSounds()throws Exception{var cues=read("/assets/cakeclient/knives/audio-cues.json");var sounds=read("/assets/cakeclient/sounds.json");assertEquals(22,cues.size());int count=0;for(var model:cues.entrySet())for(var clip:model.getValue().getAsJsonObject().entrySet()){double last=-1;for(var e:clip.getValue().getAsJsonArray()){var cue=e.getAsJsonObject();double at=cue.get("at").getAsDouble();assertTrue(at>=last);last=at;String name=cue.get("sound").getAsString();assertTrue(sounds.has(name),name);for(var sound:sounds.getAsJsonObject(name).getAsJsonArray("sounds")){String path="/assets/cakeclient/sounds/"+sound.getAsString().replace("cakeclient:","")+".ogg";try(var in=getClass().getResourceAsStream(path)){assertNotNull(in,path);assertArrayEquals(new byte[]{79,103,103,83},in.readNBytes(4));}}count++;}}assertTrue(count>100);}
}
