package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.image.*;
import javax.imageio.ImageIO;

class ImagePixelsTest {
 @Test void theShippedPngAtlasReproducesTheByteRasterAndConvertsWithoutACast()throws Exception{
  try(var in=getClass().getResourceAsStream("/assets/cakeclient/fx/atlas.png")){
   assertNotNull(in);var image=ImageIO.read(in);
   assertInstanceOf(DataBufferByte.class,image.getRaster().getDataBuffer());
   assertNull(ImagePixels.packedArgb(image,image.getWidth(),image.getHeight()));
   var actual=new int[image.getWidth()*image.getHeight()];
   ImagePixels.copyArgb(image,image.getWidth(),image.getHeight(),actual);
   assertArrayEquals(image.getRGB(0,0,image.getWidth(),image.getHeight(),null,0,image.getWidth()),actual);
   assertTrue(java.util.Arrays.stream(actual).anyMatch(p->(p>>>24)>0));
  }
 }
 @Test void byteRgbAndIndexedImagesPreserveColorAndAlpha(){
  for(int type:new int[]{BufferedImage.TYPE_4BYTE_ABGR,BufferedImage.TYPE_3BYTE_BGR,BufferedImage.TYPE_BYTE_INDEXED,BufferedImage.TYPE_INT_ARGB_PRE}){
   var image=new BufferedImage(3,2,type);
   image.setRGB(0,0,0x80c04020);image.setRGB(1,0,0xff123456);image.setRGB(2,1,0);
   var actual=new int[6];ImagePixels.copyArgb(image,3,2,actual);
   assertArrayEquals(image.getRGB(0,0,3,2,null,0,3),actual);
   assertNull(ImagePixels.packedArgb(image,3,2));
  }
 }
 @Test void subimagesUseTheirOwnRowsAndOffset(){
  var parent=new BufferedImage(8,6,BufferedImage.TYPE_INT_ARGB);
  for(int y=0;y<6;y++)for(int x=0;x<8;x++)parent.setRGB(x,y,0xff000000|x*0x110000|y*0x1100);
  var child=parent.getSubimage(2,1,3,2);assertNull(ImagePixels.packedArgb(child,3,2));
  var actual=new int[6];ImagePixels.copyArgb(child,3,2,actual);
  assertArrayEquals(parent.getRGB(2,1,3,2,null,0,3),actual);
 }
 @Test void canvasArgbKeepsTheExistingZeroCopyPath(){
  var image=new BufferedImage(4,3,BufferedImage.TYPE_INT_ARGB);
  assertSame(((DataBufferInt)image.getRaster().getDataBuffer()).getData(),ImagePixels.packedArgb(image,4,3));
 }
 @Test void mismatchedDimensionsAreRejectedBeforeUpload(){
  var image=new BufferedImage(4,3,BufferedImage.TYPE_INT_ARGB);
  assertThrows(IllegalArgumentException.class,()->ImagePixels.packedArgb(image,3,3));
  assertThrows(IllegalArgumentException.class,()->ImagePixels.copyArgb(image,4,3,new int[2]));
 }
}
