package fr.cake.client;
import org.junit.jupiter.api.Test;
import net.minecraft.world.phys.Vec3;
import static org.junit.jupiter.api.Assertions.*;
class VisualLogicTest {
 @Test void lrcFractionsOffsetsAndMultipleTimestamps(){
  var timeline=LrcTimeline.parse("[ar:Example]\n[offset:100]\n[00:03.50][00:01.5]An original test sentence\n[00:05.125]Second sentence\n");
  assertEquals(3,timeline.lines.size());assertEquals(1400,timeline.lines.get(0).start());assertEquals(3400,timeline.lines.get(1).start());assertEquals(5025,timeline.lines.get(2).start());
  assertEquals(-1,timeline.index(1399));assertEquals(0,timeline.index(1400));assertEquals(1,timeline.index(3500));
  assertEquals(.5,timeline.progress(0,2400,6000),1e-6);
 }
 @Test void malformedAndEmptyLyricsAreHarmless(){
  assertTrue(LrcTimeline.parse("[artist:No timestamps]\nplain words\n[00:75]invalid").lines.isEmpty());
  var timeline=LrcTimeline.parse("[00:00]Start\n[00:04]\n[00:07]End");
  assertEquals("",timeline.lines.get(1).text());assertEquals(1,timeline.progress(2,10000,9000),1e-6);
 }
 @Test void spatialRayFindsTheActualRectangle(){
  Vec3 center=new Vec3(0,0,5),normal=new Vec3(0,0,-1),right=new Vec3(-1,0,0);
  var centerHit=SpatialPanel.intersect(Vec3.ZERO,new Vec3(0,0,1),center,right,normal,2,1);
  assertNotNull(centerHit);assertEquals(960,centerHit.x(),1e-6);assertEquals(540,centerHit.y(),1e-6);assertEquals(5,centerHit.distance(),1e-6);
  assertNull(SpatialPanel.intersect(Vec3.ZERO,new Vec3(1,0,0),center,right,normal,2,1));
  assertNull(SpatialPanel.intersect(Vec3.ZERO,new Vec3(0,0,-1),center,right,normal,2,1));
  assertNull(SpatialPanel.intersect(Vec3.ZERO,new Vec3(3,0,5).normalize(),center,right,normal,2,1));
 }
 @Test void reverseSideKeepsTextAndHitboxesAligned(){
  Vec3 center=new Vec3(0,0,5),normal=new Vec3(0,0,-1),right=new Vec3(-1,0,0);
  var front=SpatialPanel.intersect(Vec3.ZERO,new Vec3(-.5,0,5).normalize(),center,right,normal,2,1);
  var back=SpatialPanel.intersect(new Vec3(0,0,10),new Vec3(-.5,0,-5).normalize(),center,right,normal,2,1);
  assertNotNull(front);assertNotNull(back);assertEquals(1440,front.x(),1e-6);assertEquals(480,back.x(),1e-6);
 }
 @Test void tiltedPanelsUseTheirOwnVerticalAxis(){
  Vec3 center=new Vec3(0,2,5),normal=new Vec3(0,-1,-1).normalize(),right=new Vec3(-1,0,0);
  Vec3 up=normal.cross(right).normalize();Vec3 target=center.add(up.scale(.25));
  var hit=SpatialPanel.intersect(Vec3.ZERO,target.normalize(),center,right,normal,2,1);
  assertNotNull(hit);assertEquals(960,hit.x(),1e-6);assertEquals(270,hit.y(),1e-6);
 }
 @Test void pausedMediaDoesNotAdvanceAndPlayingMediaUsesMonotonicTime(){
  long sampled=System.nanoTime()-2_000_000_000L;
  var paused=new LyricsService.Media("key","title","artist",1000,10000,false,sampled);
  var playing=new LyricsService.Media("key","title","artist",1000,10000,true,sampled);
  assertEquals(1000,paused.currentPosition());assertTrue(playing.currentPosition()>=3000);assertTrue(playing.currentPosition()<3500);
 }
}
