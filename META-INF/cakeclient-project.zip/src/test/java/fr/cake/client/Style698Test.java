package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;import fr.cake.protocol.CosmeticState;import java.util.*;
class Style698Test{
 @Test void normalWingPivotStaysOnTheUpperTorso(){assertEquals(.14,WingFit.shoulderY(.5),.0001);for(double lift:new double[]{0,.25,.5,.75,1}){assertTrue(WingFit.shoulderY(lift)>=0);assertTrue(WingFit.shoulderY(lift)<=.28f);}assertTrue(WingFit.shoulderY(.5,28,true)>WingFit.shoulderY(.5));assertTrue(WingFit.FEATHER_OPENING>.4f);}
 @Test void wingPreviewsRenderImportedGeometry()throws Exception{for(int id=0;id<6;id++)try(var in=getClass().getResourceAsStream("/assets/cakeclient/back/preview-"+id+".png")){assertNotNull(in);var image=javax.imageio.ImageIO.read(in);assertEquals(1024,image.getWidth());assertEquals(576,image.getHeight());}}
 @Test void sonicAndOtherKnownAvatarsHaveAssetsAndBoundedPackets()throws Exception{for(int id:new int[]{28,30,31,32}){assertTrue(SkinCatalog.available(id));var s=new CosmeticState(8,0,0,0,0,id,0,0,0,0,0,0,0,.5f);assertEquals(s,CosmeticState.decode(s.packet(UUID.randomUUID())).state());try(var in=getClass().getResourceAsStream("/assets/cakeclient/avatars/"+AvatarSkins.IDS[id-1]+"-CREDITS.txt")){assertTrue(new String(in.readAllBytes()).contains("CC-BY-4.0"));}}assertFalse(SkinCatalog.available(29));}
}
