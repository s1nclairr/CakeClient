package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;import java.io.*;
class HdWingsTest{
 @Test void genuineImportedMeshIsCompleteAndMirroredAtTheShoulders()throws Exception{var p=HdWings.read(getClass().getResourceAsStream("/assets/cakeclient/back/hd/angel.cwd"));assertEquals(4,p.length);int triangles=0;for(var part:p){triangles+=part.indices().length/3;assertEquals(part.material(),part.side()==0?java.util.Arrays.asList(p).indexOf(part):java.util.Arrays.asList(p).indexOf(part)-2);}assertEquals(27896,triangles);}
 @Test void truncatedImportFailsCleanly(){assertThrows(IOException.class,()->HdWings.read(new ByteArrayInputStream(new byte[]{1,2,3})));}
 @Test void freeCannotKeepPremiumEffectsThroughAnOldConfiguration(){for(int tab:new int[]{1,2,4,5,7,10,11,12,13,14,15,16,17,18,19,20,21,23,24})assertFalse(Edition.module(Edition.Plan.FREE,tab));}
}
