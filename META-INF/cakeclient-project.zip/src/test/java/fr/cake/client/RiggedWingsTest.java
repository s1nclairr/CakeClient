package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class RiggedWingsTest {
 @Test void eachImportedSourceRetainsItsWingSkinningAndFlightClip()throws Exception{for(String model:new String[]{"dragon","dragon_evolved","alpaking"})try(var in=getClass().getResourceAsStream("/assets/cakeclient/back/hd/"+model+".avm")){var m=AvatarMesh.read(in);assertTrue(m.bones>8);assertTrue(m.indices.length>=1500);boolean changed=false;var a=m.pose(0,0,0);var b=m.pose(.31,0,0);for(int i=0;i<a.length;i++)changed|=!a[i].equals(b[i],.00001f);assertTrue(changed,model+" author animation");}}
}
