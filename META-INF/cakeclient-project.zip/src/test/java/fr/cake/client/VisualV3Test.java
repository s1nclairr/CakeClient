package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
class VisualV3Test {
 @Test void requestedLyricExampleBecomesTwoSeparateGroups(){var groups=LyricChunks.split("let it happen");assertEquals(2,groups.size());assertEquals("let it",groups.get(0).text());assertEquals("happen",groups.get(1).text());}
 @Test void lyricGroupingKeepsWordOrderAndHasNoEmptyGroups(){
  for(int n=1;n<=30;n++){String text=String.join(" ",Collections.nCopies(n,"word"));var parts=LyricChunks.split(text);assertFalse(parts.isEmpty());assertTrue(parts.size()<=6);assertEquals(text,String.join(" ",parts.stream().map(LyricChunks.Chunk::text).toList()));assertTrue(parts.stream().allMatch(p->!p.text().isBlank()));}
  assertTrue(LyricChunks.split("   ").isEmpty());
 }
 @Test void concaveBladeTriangulationPreservesAreaForBothWindings(){
  float[][] shape={{0,0},{2,0},{2,1},{1,1},{1,2},{0,2}};
  for(int winding=0;winding<2;winding++){
   var triangles=KnifeMesh.triangulate(shape);assertEquals(4,triangles.size());double area=0;
   for(int[] t:triangles){float[] a=shape[t[0]],b=shape[t[1]],c=shape[t[2]];area+=Math.abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))/2.;}
   assertEquals(3,area,1e-6);Collections.reverse(Arrays.asList(shape));
  }
 }
 @Test void allKnifeModelsAndTheHandHaveFiniteThreeDimensionalGeometry(){
  for(int i=0;i<4;i++){var m=KnifeModels.build(i);assertFalse(m.blade().vertices.isEmpty());assertFalse(m.grip().vertices.isEmpty());for(var mesh:List.of(m.grip(),m.blade(),m.left(),m.right())){
   assertEquals(0,mesh.vertices.size()%3);assertEquals(mesh.vertices.size()*20,mesh.bytes().remaining());
   for(var v:mesh.vertices)assertTrue(Float.isFinite(v.x())&&Float.isFinite(v.y())&&Float.isFinite(v.z())&&Float.isFinite(v.nx())&&Float.isFinite(v.ny())&&Float.isFinite(v.nz()));
  }if(i==1){assertFalse(m.left().vertices.isEmpty());assertFalse(m.right().vertices.isEmpty());}}
  assertTrue(KnifeModels.hand().vertices.size()>100);
 }
 @Test void butterflyInspectionArticulatesBothHandlesAndEndsAtRest(){
  var active=KnifeAnimation.sample(1,2,.3);assertTrue(Math.abs(active.left())>10);assertTrue(Math.abs(active.right())>10);
  for(int model=0;model<4;model++){var end=KnifeAnimation.sample(model,2,1);assertEquals(0,end.x(),1e-5);assertEquals(0,end.y(),1e-5);assertEquals(0,end.z(),1e-5);assertEquals(0,end.spin()%360,1e-4);assertEquals(0,end.blade()%360,1e-4);assertEquals(0,end.left()%360,1e-4);assertEquals(0,end.right()%360,1e-4);}
 }
}
