package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;import net.minecraft.world.phys.Vec3;
class SilentAuraTest{
 @Test void aimMatchesCardinalDirectionsAndElevation(){assertEquals(0,SilentAimMath.rotation(Vec3.ZERO,new Vec3(0,0,1)).yaw(),.001);assertEquals(-90,SilentAimMath.rotation(Vec3.ZERO,new Vec3(1,0,0)).yaw(),.001);assertEquals(90,SilentAimMath.rotation(Vec3.ZERO,new Vec3(-1,0,0)).yaw(),.001);assertEquals(-45,SilentAimMath.rotation(Vec3.ZERO,new Vec3(0,1,1)).pitch(),.001);}
 @Test void rangeNeverExceedsVanillaAndMovementStaysUnchanged(){assertEquals(3,SilentAimMath.range(1,6));assertEquals(2.35,SilentAimMath.range(.35,3),.001);assertEquals(1.5,SilentAimMath.range(1,1.5));var input=new Vec3(.2,0,.8);assertSame(input,PlayerFollow.direction(null,input));}
}
