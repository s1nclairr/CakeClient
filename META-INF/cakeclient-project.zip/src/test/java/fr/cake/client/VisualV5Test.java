package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;import org.joml.Matrix4f;import org.joml.Quaternionf;
class VisualV5Test {
 @Test void repeatedSpotifyPositionsKeepAdvancingInsteadOfRestartingTheClock(){
  var c=new PlaybackClock();long n=10_000_000_000L;
  assertEquals(12000,c.update(10000,1,2000,n,true,1,200000,true));
  assertEquals(13000,c.update(10000,2,0,n+1_000_000_000L,true,1,200000,false));
  assertEquals(14000,c.update(10000,3,0,n+2_000_000_000L,true,1,200000,false));
  assertEquals(80000,c.update(80000,4,0,n+3_000_000_000L,true,1,200000,false));
 }
 @Test void pauseResumeAndStaleTimestampsPreservePlayback(){
  var c=new PlaybackClock();long n=1_000_000_000L;
  c.update(10000,1,0,n,true,1,100000,true);
  assertEquals(11000,c.update(10000,1,0,n+1_000_000_000L,false,1,100000,false));
  assertEquals(11000,c.update(10000,1,0,n+9_000_000_000L,true,1,100000,false));
  assertEquals(12000,c.update(12000,1,999999,n+10_000_000_000L,true,1,100000,false));
 }
 @Test void cutsAlternateAndFastClicksQueueWithoutResettingTheCurrentCut(){
  var p=new KnifePlayback();double[] d={2,4,1,1,1,1};long n=10_000_000_000L;
  p.attack(false,n,d);assertEquals(3,p.mode());
  p.attack(false,n+200_000_000L,d);assertEquals(3,p.mode());assertEquals(.2,p.progress(n+200_000_000L,d),.0001);
  p.advance(n+1_100_000_000L,d);assertEquals(4,p.mode());p.advance(n+2_200_000_000L,d);assertEquals(0,p.mode());
  p.attack(true,n+3_000_000_000L,d);assertEquals(5,p.mode());
 }
 @Test void genuineCsActionClipsRotateTheHandAndHaveDistinctSlashPaths()throws Exception{
  for(String name:new String[]{"karambit","butterfly","bayonet","bowie"}){
   var model=CsKnifeAsset.load(name);assertTrue(model.clips.length>=6);var origin=model.clips[0].hand(0);assertTrue(origin.x>.05&&origin.x<.3&&origin.y<0&&origin.z<-.3&&origin.z>-.8);assertTrue(model.clips[1].hasLeftArm());
   for(int clip:new int[]{1,2,3,4,5}){var c=model.clips[clip];assertTrue(c.frames>=60);var a=c.handMatrix(0);boolean rotates=false;for(int i=0;i<=30;i++){var m=c.handMatrix(c.duration*i/30.);assertTrue(m.isFinite());Quaternionf q=m.getUnnormalizedRotation(new Quaternionf()),q0=a.getUnnormalizedRotation(new Quaternionf());if(Math.abs(q.dot(q0))<.98)rotates=true;}assertTrue(rotates,name+" clip "+clip+" must carry a full wrist rotation");}
   assertFalse(model.clips[3].handMatrix(.25).equals(model.clips[4].handMatrix(.25),.01f));
  }
 }
 @Test void severalLyricGroupsRemainVisibleTogetherAndThenRetire(){
  assertTrue(LyricSequence.layered(.7,0,.8,.1)>.99);assertTrue(LyricSequence.layered(.7,.3,1,.1)>.99);assertTrue(LyricSequence.layered(.7,.6,1,.1)>.99);assertEquals(0,LyricSequence.layered(.95,0,.8,.1));assertEquals(0,LyricSequence.layered(.2,.3,1,.1));
 }
}
