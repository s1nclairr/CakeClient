package fr.cake.client;
import org.junit.jupiter.api.Test;
import org.joml.Quaternionf;
import static org.junit.jupiter.api.Assertions.*;
class KnifeCollectionTest {
 @Test void allTwentyTwoEntriesHaveTheirOwnCompleteAnimatedAsset()throws Exception{
  assertEquals(22,KnifeCatalog.COUNT);java.util.Set<String> hashes=new java.util.HashSet<>();
  for(String name:KnifeCatalog.IDS){
   var model=CsKnifeAsset.load(name);assertTrue(model.parts.size()>=1,name);
   for(String alias:new String[]{"idle","deploy","inspect","slash1","slash2","stab"}){
    int index=model.find(alias);assertTrue(index>=0,name+" "+alias);var clip=model.clips[index];assertTrue(clip.hasLeftArm(),name);
    for(double time:new double[]{0,.071,clip.duration*.47,clip.duration}){
     assertTrue(clip.handMatrix(time).isFinite());assertTrue(clip.leftArmMatrix(time).isFinite());
     for(int part=0;part<model.parts.size();part++){var m=clip.matrix(part,time);assertTrue(m.isFinite());assertEquals(1,m.determinant3x3(),.002,name+" rigid interpolation");}
    }
   }
   try(var in=getClass().getResourceAsStream("/assets/cakeclient/knives/"+name+".ckm")){assertTrue(hashes.add(java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(in.readAllBytes()))),name+" must not reuse another asset");}
  }
 }
 @Test void allModelsHaveMatchingSourceMaterialMaps()throws Exception{
  for(String name:KnifeCatalog.IDS){try(var a=getClass().getResourceAsStream("/assets/cakeclient/knives/"+name+"-color.png");var b=getClass().getResourceAsStream("/assets/cakeclient/knives/"+name+"-surface.png")){
   assertNotNull(a,name);assertNotNull(b,name);var color=javax.imageio.ImageIO.read(a);var surface=javax.imageio.ImageIO.read(b);assertEquals(color.getWidth(),surface.getWidth(),name);assertEquals(color.getHeight(),surface.getHeight(),name);assertTrue(color.getWidth()>=1024,name);
  }}
 }
 @Test void butterflyUsesTheSourceInspectionMarkersAndShadowHasBothDaggers()throws Exception{
  var butterfly=CsKnifeAsset.load("butterfly");for(String alias:new String[]{"inspect","inspect2","inspect3"}){var c=butterfly.clips[butterfly.find(alias)];assertTrue(c.holdStart>0);assertTrue(c.holdEnd>c.holdStart);assertTrue(c.holdEnd<c.duration);}
  var shadow=CsKnifeAsset.load("shadow");assertTrue(shadow.parts.size()>=2);assertFalse(shadow.clips[0].matrix(0,0).equals(shadow.clips[0].matrix(1,0),.001f));
 }
 @Test void karambitSupportHandStaysInTheGuardDuringTheRingSpin()throws Exception{
  var c=CsKnifeAsset.load("karambit").clips[1];
  for(double time:new double[]{.5,1.4,2.4,3.4}){
   var p=c.leftArmMatrix(time).getTranslation(new org.joml.Vector3f());
   assertTrue(p.z<-.25&&p.z>-.9,"Support palm depth");
   assertTrue(p.y/(-p.z)>-.45&&p.y/(-p.z)<.45,"Support palm remains in view");
  }
 }
 @Test void bothShadowBladesExtendBeyondTheNativeCubeFists()throws Exception{
  var model=CsKnifeAsset.load("shadow");var clip=model.clips[0];
  for(int i=0;i<model.parts.size();i++){
   var hand=i==0?clip.leftArmMatrix(0):clip.handMatrix(0);
   var local=new org.joml.Matrix4f(hand).invert().mul(clip.matrix(i,0));
   var part=model.parts.get(i);var b=part.vertices().duplicate().order(java.nio.ByteOrder.nativeOrder());
   float forward=Float.NEGATIVE_INFINITY,sideways=0;
   for(int v=0;v<part.count();v++){
    var p=local.transformPosition(b.getFloat(),b.getFloat(),b.getFloat(),new org.joml.Vector3f());b.position(b.position()+16);
    forward=Math.max(forward,p.y);sideways=Math.max(sideways,Math.abs(p.z));
   }
   assertTrue(forward>.08||sideways>.10,"A real blade must protrude beyond each cubic fist, part "+i);
  }
 }
}
