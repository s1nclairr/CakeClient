package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class KnifeHoldTest {
 private final double[] durations={2,4.1,1,1.1666,1.1666,1.1666,4.5,4.8666};
 @Test void holdingSkipsOnlyTheOriginalStationaryInspectionWindow(){
  var p=new KnifePlayback();p.play(1,0);
  assertFalse(p.skipInspectionHold(900_000_000L,1.033333,2.7));
  assertTrue(p.skipInspectionHold(1_040_000_000L,1.033333,2.7));
  assertEquals(2.706667,p.seconds(1_040_000_000L,durations,1),.000001);
  assertFalse(p.skipInspectionHold(1_050_000_000L,1.033333,2.7));
 }
 @Test void releasingFinishesTheCurrentOutroAndReturnsToIdle(){
  var p=new KnifePlayback();p.play(1,0);p.skipInspectionHold(1_040_000_000L,1.033333,2.7);
  p.advance(2_000_000_000L,durations);assertEquals(1,p.mode());
  p.advance(2_500_000_000L,durations);assertEquals(0,p.mode());
 }
 @Test void sourceVariantsChainWithoutRestartingOnEveryFrame(){
  var p=new KnifePlayback();p.play(1,0);assertFalse(p.loopIfFinished(6,1_000_000_000L,durations));
  assertTrue(p.loopIfFinished(6,4_125_000_000L,durations));assertEquals(6,p.mode());
  assertEquals(.025,p.seconds(4_125_000_000L,durations,1),.000001);
  assertFalse(p.loopIfFinished(7,4_130_000_000L,durations));
 }
 @Test void aQuickTapRetainsTheCompleteOriginalInspection(){
  var p=new KnifePlayback();p.play(1,0);p.advance(3_000_000_000L,durations);
  assertEquals(1,p.mode());assertEquals(3,p.seconds(3_000_000_000L,durations,1),.000001);
  p.advance(4_200_000_000L,durations);assertEquals(0,p.mode());
 }
}
