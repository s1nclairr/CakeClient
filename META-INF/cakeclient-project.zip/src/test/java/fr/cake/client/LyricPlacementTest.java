package fr.cake.client;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LyricPlacementTest {
 @Test void longLinesFitTheForwardViewEvenAtNarrowFovAndMaximumSize(){
  for(int count=1;count<=6;count++)for(int line=0;line<15;line++)for(double distance:new double[]{5.5,13.5})for(double aspect:new double[]{.5625,1,16./9,21./9})for(double height:new double[]{0,.5,1}){
   var cards=LyricPlacement.arrange(count,line,distance,1,1,height,30,aspect);
   double halfY=distance*Math.tan(Math.toRadians(15))*.64,halfX=halfY*aspect;
   assertEquals(count,cards.size());
   for(var card:cards){
    assertTrue(card.width()>0&&card.height()>0);
    assertTrue(Math.abs(card.x())+card.width()/2<=halfX+1e-9);
    assertTrue(Math.abs(card.y())+card.height()/2<=halfY+1e-9);
   }
   for(int a=0;a<cards.size();a++)for(int b=a+1;b<cards.size();b++){
    var x=cards.get(a);var y=cards.get(b);
    assertTrue(Math.abs(x.x()-y.x())>=(x.width()+y.width())/2||Math.abs(x.y()-y.y())>=(x.height()+y.height())/2,"Cards must not overlap");
   }
  }
 }
 @Test void exampleRemainsLeftThenRightAndHeightControlMovesBothGroups(){
  var low=LyricPlacement.arrange(2,0,9,.5,.4,0,70,16./9);
  var high=LyricPlacement.arrange(2,0,9,.5,.4,1,70,16./9);
  assertTrue(low.get(0).x()<0);assertTrue(low.get(1).x()>0);
  assertTrue(low.get(0).y()<0);assertTrue(high.get(0).y()>0);
 }
 @Test void emptyLinesCreateNoCardsAndPlaybackStopsAtTrackEnd(){
  assertTrue(LyricPlacement.arrange(0,0,9,.5,.5,.5,70,16./9).isEmpty());
  long oldSample=System.nanoTime()-10_000_000_000L;
  var ended=new LyricsService.Media("key","title","artist",2000,5000,true,oldSample);
  assertEquals(5000,ended.currentPosition());
 }
}
