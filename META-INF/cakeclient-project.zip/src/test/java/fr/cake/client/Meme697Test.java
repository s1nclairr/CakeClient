package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;import fr.cake.protocol.CosmeticState;import java.util.*;
class Meme697Test {
 @Test void onlyKnownCharactersCanBeSelected(){assertArrayEquals(new int[]{28,30,31,32,24,25,26,27,21,22,20,23},SkinCatalog.IDS);for(int old:new int[]{1,2,8,11,15,16,18,19})assertFalse(SkinCatalog.available(old));}
 @Test void fourNewCharactersHaveTexturesPreviewsAndSourceCredits()throws Exception{for(String n:new String[]{"neighbor","shrek","knuckles","donkey"}){try(var in=getClass().getResourceAsStream("/assets/cakeclient/avatars/"+n+"-atlas.png")){assertNotNull(in);var image=javax.imageio.ImageIO.read(in);assertTrue(image.getWidth()>=512);}try(var in=getClass().getResourceAsStream("/assets/cakeclient/avatars/"+n+"-CREDITS.txt")){assertTrue(new String(in.readAllBytes()).contains("CC-BY-4.0"));}}for(int i=23;i<27;i++)assertNotNull(getClass().getResourceAsStream("/assets/cakeclient/avatars/preview-"+i+".png"));}
 @Test void newIdsRoundTripWithoutReusingOldIds()throws Exception{for(int id=24;id<=27;id++){var s=new CosmeticState(8,0,0,0,0,id,0,0,0,0,0,0,0,.5f);assertEquals(s,CosmeticState.decode(s.packet(UUID.randomUUID())).state());}assertThrows(IllegalArgumentException.class,()->new CosmeticState(8,0,0,0,0,33,0,0,0,0,0,0,0,.5f));}
}
