package fr.cake.client;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;import java.nio.*;import org.joml.Vector3f;
class VisualV4Test {
 @Test void sourceMaterialMapsDecodeWithMatchingDimensions()throws Exception{
  for(String name:new String[]{"karambit","butterfly","bayonet","bowie"}){
   try(var a=CsKnifeAsset.class.getResourceAsStream("/assets/cakeclient/knives/"+name+"-color.png");var b=CsKnifeAsset.class.getResourceAsStream("/assets/cakeclient/knives/"+name+"-surface.png")){
    assertNotNull(a);assertNotNull(b);var color=javax.imageio.ImageIO.read(a);var surface=javax.imageio.ImageIO.read(b);assertNotNull(color);assertNotNull(surface);assertEquals(color.getWidth(),surface.getWidth());assertEquals(color.getHeight(),surface.getHeight());assertTrue(color.getWidth()>=1024);
   }
  }
 }
 @Test void wordsArriveSequentiallyAndFirstDissolvesAfterSecondArrives(){
  assertEquals(0,LyricSequence.opacity(.1,.5,1));assertTrue(LyricSequence.opacity(.25,0,.5)>.99);
  assertTrue(LyricSequence.opacity(.53,0,.5)>0);assertTrue(LyricSequence.opacity(.53,.5,1)>0);
  assertEquals(0,LyricSequence.opacity(.7,0,.5));assertTrue(LyricSequence.opacity(.7,.5,1)>.99);
 }
 @Test void everySourceMeshHasFiniteTexturedVertices()throws Exception{
  for(String name:new String[]{"karambit","butterfly","bayonet","bowie"}){
   var model=CsKnifeAsset.load(name);assertFalse(model.parts.isEmpty());int triangles=0;
   for(var part:model.parts){assertEquals(0,part.count()%3);assertEquals(part.count()*28,part.vertices().remaining());triangles+=part.count()/3;var b=part.vertices().duplicate().order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<part.count();i++){for(int c=0;c<5;c++)assertTrue(Float.isFinite(b.getFloat()));b.position(b.position()+8);}}
   assertTrue(triangles>500);
  }
 }
 @Test void originalInspectionHasFiniteArticulatedPartsAndHandTrajectory()throws Exception{
  for(String name:new String[]{"karambit","butterfly"}){
   var model=CsKnifeAsset.load(name);assertTrue(model.clips.length>=6);var clip=model.clips[1];assertTrue(clip.frames>60);assertTrue(clip.duration>1);
   var first=clip.hand(0);double travel=0;
   for(int frame=0;frame<=60;frame++){double time=clip.duration*frame/60.;Vector3f hand=clip.hand(time);assertTrue(hand.isFinite());travel=Math.max(travel,hand.distance(first));for(int p=0;p<model.parts.size();p++)assertTrue(clip.matrix(p,time).isFinite());}
   assertTrue(travel>.03,"Inspection must move the hand rather than only wobble the model");
   if(name.equals("butterfly"))assertTrue(model.parts.size()>=3);
  }
 }
}
