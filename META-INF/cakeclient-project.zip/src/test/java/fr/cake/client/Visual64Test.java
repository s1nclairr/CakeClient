package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class Visual64Test {
 @Test void presetsNeverIncreaseLegalExistingDistances(){
  for(int v:new int[]{2,4,8,12,24})for(int sim:new int[]{5,8,12})for(double e:new double[]{.5,.75,1,2})for(int level=1;level<=3;level++){
   var p=FpsPlan.preset(level,v,sim,e);assertTrue(p.view()<=v);assertTrue(p.simulation()<=sim);assertTrue(p.entities()<=e);assertTrue(p.simulation()>=5);assertTrue(p.entities()>=.5);assertFalse(p.ao());assertFalse(p.improvedTransparency());
  }
 }
 @Test void maximumActuallyReducesRenderingWork(){var p=FpsPlan.preset(3,12,12,1);assertEquals(3,p.view());assertEquals(5,p.simulation());assertEquals(.5,p.entities());assertEquals(2,p.particles());assertEquals(3,p.weather());}
 @Test void fogStaysWithinTheActualLoadedDistance(){
  var r=FogMath.range(300,.2,.7,96);assertEquals(96,r.end());assertTrue(r.start()>=0&&r.start()<r.end());assertEquals(6,FogMath.chunksFor(r.end()));
 }
 @Test void densityBroadensTheNativeFogTransition(){var low=FogMath.range(128,.25,0,256);var high=FogMath.range(128,.25,1,256);assertTrue(high.start()<low.start());assertEquals(low.end(),high.end());assertEquals(32,FogMath.distance(0));assertEquals(384,FogMath.distance(1));}
}
