package fr.cake.client;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import net.minecraft.world.phys.Vec3;
class Follow65Test {
 @Test void forwardPointsToTargetRegardlessOfViewYaw(){for(int yaw=-180;yaw<180;yaw+=30){var local=PlayerFollow.redirect(new Vec3(0,0,1),yaw,3,4);var world=local.yRot((float)-Math.toRadians(yaw));/* Vanilla Vec3 rotation uses the quantized Mth sine table. */assertEquals(.6,world.x,2.5e-4);assertEquals(.8,world.z,2.5e-4);}}
 @Test void noInputNeverCreatesMovement(){assertEquals(Vec3.ZERO,PlayerFollow.redirect(Vec3.ZERO,30,3,-8));}
 @Test void strafeAndVerticalSpeedArePreserved(){var input=new Vec3(.4,.6,.8);var result=PlayerFollow.redirect(input,75,-5,3);assertEquals(input.length(),result.length(),1e-6);assertEquals(.6,result.y,1e-6);}
}
