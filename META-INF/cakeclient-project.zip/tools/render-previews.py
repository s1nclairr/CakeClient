"""Render genuine source geometry/material previews at 1060x566, with 2x AA.
Requires numpy, moderngl (EGL) and Pillow. No generated silhouettes.
"""
from pathlib import Path
import sys,struct,json,io,os,numpy as np,moderngl
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent;DEST=ROOT/'src/main/resources/assets/cakeclient/knives'
ctx=moderngl.create_standalone_context(backend='egl')
vertex='''#version 330
uniform mat4 VP;in vec3 inPosition;in vec3 inNormal;in vec2 inUv;
out vec3 position;out vec3 normal;out vec2 uv;
void main(){position=inPosition;normal=inNormal;uv=inUv;gl_Position=VP*vec4(position,1.);}
'''
fragment=(ROOT/'src/main/resources/assets/cakeclient/shaders/core/knife_native.fsh').read_text().replace('#version 330','#version 330\n#define CAKE_FINISH 0')
program=ctx.program(vertex_shader=vertex,fragment_shader=fragment);program['AlbedoSampler']=0;program['SurfaceSampler']=1
fbo=ctx.simple_framebuffer((2120,1132),components=4);fbo.use();ctx.enable(moderngl.DEPTH_TEST)
def render(name,index):
 data=(DEST/(name+'.ckm')).read_bytes();magic,parts=struct.unpack_from('<II',data);assert magic==0x374d4b43;offset=8;geometry=[]
 dtype=np.dtype({'names':['pos','uv','normal'],'formats':[('<f4',3),('<f4',2),('i1',3)],'offsets':[0,12,24],'itemsize':28})
 for i in range(parts):
  joint,count=struct.unpack_from('<II',data,offset);offset+=8;geometry.append(np.frombuffer(data,dtype=dtype,count=count,offset=offset));offset+=count*28
 clips=struct.unpack_from('<I',data,offset)[0];offset+=4;l=struct.unpack_from('<H',data,offset)[0];offset+=2+l+16
 matrices=np.frombuffer(data,dtype='<f4',count=(parts+2)*16,offset=offset).reshape(parts+2,4,4).transpose(0,2,1)
 vertices=[];normals=[];uvs=[]
 for mesh,m in zip(geometry,matrices):vertices.append((m@np.column_stack([mesh['pos'],np.ones(len(mesh))]).T).T[:,:3]);normals.append(mesh['normal']/127.@m[:3,:3].T);uvs.append(mesh['uv'])
 p=np.concatenate(vertices);n=np.concatenate(normals);uv=np.concatenate(uvs);center=p.mean(0);values,vectors=np.linalg.eigh(np.cov(p.T));major=vectors[:,2];minor=vectors[:,0]
 palm=matrices[-2,:3,3];tip=p[np.argmax(np.linalg.norm(p-palm,axis=1))]
 if (tip-center)@major>0:major=-major
 vertical=np.cross(minor,major);basis=np.stack([major,vertical,minor]);p=(p-center)@basis.T;n=n@basis.T;p-=(p.min(axis=0)+p.max(axis=0))*.5
 extent=np.ptp(p,axis=0);scale=min(1.8/max(extent[0],1e-6),.80/max(extent[1],1e-6));p*=scale;p[:,2]-=2
 interleaved=np.column_stack([p,n,uv]).astype('f4');vbo=ctx.buffer(interleaved.tobytes());vao=ctx.vertex_array(program,[(vbo,'3f 3f 2f','inPosition','inNormal','inUv')])
 texture=[]
 for unit,suffix in enumerate(['color','surface']):
  im=Image.open(DEST/(name+'-'+suffix+'.png')).convert('RGB');t=ctx.texture(im.size,3,im.tobytes());t.build_mipmaps();t.filter=(moderngl.LINEAR_MIPMAP_LINEAR,moderngl.LINEAR);t.use(unit);texture.append(t)
 vp=np.diag([1.,2120/1132.,-.2,1.]).astype('f4');program['VP'].write(vp.T.tobytes());fbo.clear(0,0,0,0,depth=1);vao.render(moderngl.TRIANGLES)
 image=Image.frombytes('RGBA',fbo.size,fbo.read(components=4)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).resize((1060,566),Image.Resampling.LANCZOS);out=io.BytesIO();image.save(out,format='PNG');path=DEST/f'preview-{index}.png';tmp=path.with_suffix('.tmp');tmp.write_bytes(out.getvalue());os.replace(tmp,path)
 vao.release();vbo.release()
 for t in texture:t.release()
 print(name,'preview rendered',flush=True)
records=json.loads((DEST/'animation-provenance-v7.json').read_text())
for index,record in enumerate(records):
 if len(sys.argv)==1 or record['model'] in sys.argv[1:]:render(record['model'],index)
