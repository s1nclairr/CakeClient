"""Convert attributed public GLBs. Simplify dense source meshes, transfer source UVs, keep original artwork."""
from pathlib import Path
import sys,struct,json,io,base64,math,os
sys.path.insert(0,'/tmp/cake-mesh-python')
import numpy as np
import fast_simplification
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from PIL import Image
import importlib.util
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent/'src/main/resources/assets/cakeclient/avatars';SRC=ROOT/'imported-avatars/brainrot'
spec=importlib.util.spec_from_file_location('avatars',ROOT/'import-avatars.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def convert(name,label,index):
 b=(SRC/(name+'.glb')).read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);binary=b[28+n:];g=object.__new__(module.Gltf);g.j=j;g.buf=[binary]
 world={}
 def visit(i,parent):
  nd=j['nodes'][i];m=np.eye(4)
  if 'matrix'in nd:m=np.array(nd['matrix']).reshape(4,4).T
  else:m[:3,:3]=Rotation.from_quat(nd.get('rotation',[0,0,0,1])).as_matrix()*np.array(nd.get('scale',[1,1,1]))[None,:];m[:3,3]=nd.get('translation',[0,0,0])
  world[i]=parent@m
  for c in nd.get('children',[]):visit(c,world[i])
 for i in j['scenes'][j.get('scene',0)]['nodes']:visit(i,np.eye(4))
 positions=[];normals=[];uvs=[];colors=[];faces=[];offset=0
 for i,nd in enumerate(j['nodes']):
  if 'mesh'not in nd or i not in world:continue
  for p in j['meshes'][nd['mesh']]['primitives']:
   a=p['attributes'];pos=g.arr(a['POSITION']);norm=g.arr(a['NORMAL']);uv=g.arr(a['TEXCOORD_0']);M=world[i];pos=(M@np.column_stack([pos,np.ones(len(pos))]).T).T[:,:3];norm=(np.linalg.inv(M[:3,:3]).T@norm.T).T
   if 'COLOR_0'in a:
    col=g.arr(a['COLOR_0']).astype(float)
    if j['accessors'][a['COLOR_0']].get('normalized'):col/=255 if j['accessors'][a['COLOR_0']]['componentType']==5121 else 65535
   else:col=np.ones((len(pos),4))
   factor=j['materials'][p.get('material',0)].get('pbrMetallicRoughness',{}).get('baseColorFactor',[1,1,1,1]);col=col[:,:3]*factor[:3]
   positions.append(pos);normals.append(norm);uvs.append(uv);colors.append(col);faces.append(g.arr(p['indices']).ravel().reshape(-1,3)+offset);offset+=len(pos)
 pos=np.concatenate(positions);normal=np.concatenate(normals);uv=np.concatenate(uvs);color=np.concatenate(colors);faces=np.concatenate(faces).astype(np.int32)
 # Mesh decimation, then closest-surface UV transfer at each new triangle corner keeps seams independent.
 welded,inverse=np.unique(np.round(pos,6),axis=0,return_inverse=True);welded_faces=inverse[faces].astype(np.int32);points,tri=fast_simplification.simplify(welded,welded_faces,target_count=8000,agg=7);new=points[tri].reshape(-1,3);centers=pos[faces].mean(1);tree=cKDTree(centers);_,near=tree.query(new,k=12,workers=2)
 candidates=pos[faces[near]];A=candidates[:,:,0];v0=candidates[:,:,1]-A;v1=candidates[:,:,2]-A;v2=new[:,None,:]-A;d00=(v0*v0).sum(2);d01=(v0*v1).sum(2);d11=(v1*v1).sum(2);d20=(v2*v0).sum(2);d21=(v2*v1).sum(2);den=d00*d11-d01*d01;den=np.where(abs(den)<1e-20,1e-20,den);v=(d11*d20-d01*d21)/den;w=(d00*d21-d01*d20)/den;weights=np.stack([1-v-w,v,w],2);weights=np.maximum(weights,0);weights/=weights.sum(2,keepdims=True);projected=(candidates*weights[:,:,:,None]).sum(2);distance=((projected-new[:,None,:])**2).sum(2);which=np.argmin(distance,axis=1);sourcefaces=faces[near[np.arange(len(new)),which]];weights=weights[np.arange(len(new)),which];newuv=(uv[sourcefaces]*weights[:,:,None]).sum(1);newnorm=(normal[sourcefaces]*weights[:,:,None]).sum(1);newnorm/=np.maximum(np.linalg.norm(newnorm,axis=1,keepdims=True),1e-8)
 material=j['materials'][0].get('pbrMetallicRoughness',{})
 source_image=None
 if 'baseColorTexture'in material:
  image=j['images'][j['textures'][material['baseColorTexture']['index']]['source']];view=j['bufferViews'][image['bufferView']];source_image=np.array(Image.open(io.BytesIO(binary[view.get('byteOffset',0):view.get('byteOffset',0)+view['byteLength']])).convert('RGB'))
 # Bake the original surface onto independent triangle charts. Interpolating a new
 # triangle across the source UV islands would produce streaks, so resample its surface.
 patch=20;pad=2;span=15;columns=math.ceil(math.sqrt(len(tri)));atlas=np.zeros((columns*patch,columns*patch,4),np.uint8);atlas[:,:,3]=255
 yy,xx=np.mgrid[:patch,:patch];v=(xx.ravel()-pad)/span;w=(yy.ravel()-pad)/span;bw=np.stack([1-v-w,v,w],1);bw=np.maximum(bw,0);bw/=bw.sum(1,keepdims=True)
 for first in range(0,len(tri),64):
  last=min(len(tri),first+64);tris=points[tri[first:last]];samples=np.einsum('pk,nkj->npj',bw,tris).reshape(-1,3);_,near=tree.query(samples,k=8,workers=2);cand=pos[faces[near]];A=cand[:,:,0];v0=cand[:,:,1]-A;v1=cand[:,:,2]-A;v2=samples[:,None,:]-A
  d00=(v0*v0).sum(2);d01=(v0*v1).sum(2);d11=(v1*v1).sum(2);d20=(v2*v0).sum(2);d21=(v2*v1).sum(2);den=d00*d11-d01*d01;den=np.where(abs(den)<1e-20,1e-20,den);v=(d11*d20-d01*d21)/den;w=(d00*d21-d01*d20)/den;weights=np.maximum(np.stack([1-v-w,v,w],2),0);weights/=weights.sum(2,keepdims=True);projected=(cand*weights[:,:,:,None]).sum(2);which=np.argmin(((projected-samples[:,None,:])**2).sum(2),axis=1);sourcefaces=faces[near[np.arange(len(samples)),which]];weights=weights[np.arange(len(samples)),which]
  if source_image is not None:
   st=(uv[sourcefaces]*weights[:,:,None]).sum(1);tx=np.clip((st[:,0]*source_image.shape[1]).astype(int),0,source_image.shape[1]-1);ty=np.clip((st[:,1]*source_image.shape[0]).astype(int),0,source_image.shape[0]-1);rgb=source_image[ty,tx]
  else:rgb=np.clip((color[sourcefaces]*weights[:,:,None]).sum(1)*255,0,255).astype('uint8')
  rgb=rgb.reshape(last-first,patch,patch,3)
  for i in range(first,last):
   row,col=divmod(i,columns);atlas[row*patch:(row+1)*patch,col*patch:(col+1)*patch,:3]=rgb[i-first]
 newuv=[]
 for i in range(len(tri)):
  row,col=divmod(i,columns);newuv.extend([((col*patch+pad+.5)/(columns*patch),(row*patch+pad+.5)/(columns*patch)),((col*patch+pad+span+.5)/(columns*patch),(row*patch+pad+.5)/(columns*patch)),((col*patch+pad+.5)/(columns*patch),(row*patch+pad+span+.5)/(columns*patch))])
 newuv=np.array(newuv);im=Image.fromarray(atlas)
 lo=new.min(0);hi=new.max(0);scale=1.8/(hi[1]-lo[1]);new=(new-np.array([(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]))*scale;new[:,[0,2]]*=-1;newnorm[:,[0,2]]*=-1
 if name in ['sahur','amogus']:
  rot=Rotation.from_euler('y',-90 if name=='sahur' else 180,degrees=True).as_matrix();new=new@rot.T;newnorm=newnorm@rot.T
 count=len(new);data=np.column_stack([new,newnorm,newuv,np.ones(count),np.zeros((count,3))]).astype('<f4');o=io.BytesIO();o.write(struct.pack('<5I',0x324d5641,count,count,1,2));o.write(data.tobytes());o.write(np.zeros((count,4),'<u2').tobytes());o.write(np.arange(count,dtype='<u4').tobytes())
 for _ in range(2):o.write(struct.pack('<fI',1.,2));o.write(np.tile(np.eye(4).T,(2,1,1)).astype('<f4').tobytes())
 module.atomic(OUT/(name+'.avm'),o.getvalue());buf=io.BytesIO();im.save(buf,format='PNG');module.atomic(OUT/(name+'-atlas.png'),buf.getvalue());module.render_preview(new,np.arange(count),newuv,OUT/(name+'-atlas.png'),OUT/f'preview-{index}.png')
 info=j['asset']['extras'];(OUT/(name+'-CREDITS.txt')).write_text(info['title']+'\n'+info['author']+'\n'+info['source']+'\n'+info['license']+'\nChanges: geometry decimated to 8000 triangles, source UV/material transferred; scaled for Cake. Source GLB bundled.\n')
 print(name,count//3,'triangles',info,flush=True)
 return {'id':name,'name':label,'source':info['source'],'vertices':count,'triangles':count//3,'joints':1,'clips':['Static','Static'],'author':info['author'],'license':info['license']}
if __name__=='__main__':
 records=json.loads((OUT/'catalog.json').read_text())[:20];records.extend([convert('sahur','Tung Tung Sahur',20),convert('amogus','Amogus',21)]);module.atomic(OUT/'catalog.json',json.dumps(records,indent=2,ensure_ascii=False).encode())
