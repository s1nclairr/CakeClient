from PIL import Image,ImageDraw,ImageFilter
import numpy as np,random,math
from pathlib import Path
root=Path('/mnt/data/cake-big/title');r=random.Random(20261027)
for face in range(6):
 n=1024
 arr=np.zeros((n,n,3),dtype=np.uint8)
 for y in range(n):
  u=y/n
  for k,c in enumerate((17,10,38)):
   arr[y,:,k]=np.clip(c+int(24*(1-u))+int([13,2,17][k]*math.sin(face*2.3+u*5.2)),0,255)
 im=Image.fromarray(arr,'RGB').convert('RGBA');layer=Image.new('RGBA',im.size,(0,0,0,0));d=ImageDraw.Draw(layer)
 for i in range(220):
  x=r.randrange(n);y=r.randrange(n);s=r.choice([1,1,1,2,2,3]);col=r.choice([(172,135,235,145),(215,211,245,160),(124,98,206,150),(228,231,255,255)])
  d.ellipse((x-s,y-s,x+s,y+s),fill=col)
 glow=layer.filter(ImageFilter.GaussianBlur(4));im=Image.alpha_composite(im,glow);im=Image.alpha_composite(im,layer)
 ImageDraw.Draw(im).line((0,850,1024,840),fill=(83,54,138,74),width=2)
 im.convert('RGB').save(root/f'panorama_{face}.png',optimize=True)
print('Main menu panorama',sum(x.stat().st_size for x in root.iterdir()),'bytes')
