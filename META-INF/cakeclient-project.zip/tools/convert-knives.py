"""Original CS2 meshes/clips; only the native Minecraft cube arms are retargeted.
Dependencies: numpy, scipy, Pillow. Independent parser, no upstream code.
"""
from pathlib import Path
import struct,json,math,io,os,hashlib
import numpy as np
from scipy.spatial.transform import Rotation
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'tools/original-cs';DEST=ROOT/'src/main/resources/assets/cakeclient/knives'
SCALE=.0254
CAM=np.array([[0.,-1.,0.,0.],[0.,0.,1.,0.],[-1.,0.,0.,0.],[0.,0.,0.,1.]])
CATALOG=[('karambit','karambit'),('butterfly','butterfly'),('bayonet','bayonet'),('bowie','bowie'),('classic','css'),('m9','m9'),('flip','flip'),('gut','gut'),('huntsman','tactical'),('falchion','falchion'),('shadow','push'),('navaja','navaja'),('stiletto','stiletto'),('ursus','ursus'),('talon','talon'),('skeleton','skeleton'),('nomad','canis'),('paracord','cord'),('survival','outdoor'),('kukri','kukri'),('default_ct','default_ct'),('default_t','default_t')]
BASE=['idle','inspect','deploy','slash1','slash2','stab']
JOINT_ALIASES={'ag1_hand_r':'econ','weapon_l':'econ_l','weapon_r':'econ'}
def interpolate(curve,times,default,rotation=False):
 if not curve:return np.broadcast_to(np.asarray(default),(len(times),len(default))).copy()
 key=np.asarray(curve['Times']);values=np.asarray(curve['Values']);a=np.clip(np.searchsorted(key,times,side='right')-1,0,len(key)-1);b=np.minimum(a+1,len(key)-1)
 p=np.clip((times-key[a])/np.maximum(key[b]-key[a],1e-15),0,1)[:,None];x=values[a];y=values[b].copy()
 if not rotation:return x*(1-p)+y*p
 dot=np.sum(x*y,axis=1);y[dot<0]*=-1;dot=np.clip(np.abs(dot),0,1);angle=np.arccos(dot)[:,None];den=np.maximum(np.sin(angle),1e-12)
 q=(x*np.sin((1-p)*angle)+y*np.sin(p*angle))/den;linear=dot>.9995;q[linear]=(x*(1-p)+y*p)[linear]
 return q/np.linalg.norm(q,axis=1)[:,None]
class Skin:
 def __init__(self,path):
  data=path.read_bytes();assert data[:8]==b'SCK2SKIN';offset=12;self.joints=[];self.bind=[];count=struct.unpack_from('<H',data,offset)[0];offset+=2
  for _ in range(count):
   size=struct.unpack_from('<H',data,offset)[0];offset+=2;name=data[offset:offset+size].decode();offset+=size;m=np.frombuffer(data,dtype='<f4',count=16,offset=offset).reshape(4,4).T.copy();offset+=64;m[:3,3]*=SCALE;self.joints.append(name);self.bind.append(m)
  count=struct.unpack_from('<I',data,offset)[0];offset+=4
  dtype=np.dtype({'names':['pos','normal','uv','joints','weights'],'formats':[('<f4',3),('<f4',3),('<f4',2),('u1',4),('<f4',4)],'itemsize':52})
  self.vertices=np.frombuffer(data,dtype=dtype,count=count,offset=offset).copy();self.vertices['pos']*=SCALE;offset+=count*52
  groups=struct.unpack_from('<H',data,offset)[0];offset+=2;indices=[]
  for _ in range(groups):
   size=struct.unpack_from('<H',data,offset)[0];offset+=2+size;n=struct.unpack_from('<I',data,offset)[0];offset+=4;indices.extend(np.frombuffer(data,dtype='<u4',count=n,offset=offset));offset+=n*4
  assert offset==len(data);self.indices=np.array(indices,dtype=np.int32)
class Rig:
 def __init__(self,path):
  self.j=json.loads(path.read_text());self.nodes=self.j['Skeleton'];self.names={b['Name']:b['Index'] for b in self.nodes};self.clips={c['Alias']:c for c in self.j['Clips'].values()}
 def sample(self,alias,times):
  times=np.atleast_1d(times);clip=self.clips[alias];world=np.broadcast_to(np.eye(4),(len(times),len(self.nodes),4,4)).copy()
  for b in self.nodes:
   curves=clip['Bones'].get(b['Name'],{});position=interpolate(curves.get('Translation'),times,b['Translation']);rotation=interpolate(curves.get('Rotation'),times,b['Rotation'],True)
   m=np.broadcast_to(np.eye(4),(len(times),4,4)).copy();m[:,:3,:3]=Rotation.from_quat(rotation).as_matrix();m[:,:3,3]=position*SCALE
   world[:,b['Index']]=world[:,b['Parent']]@m if b['Parent']>=0 else m
  return world
def normalize(a):return a/np.maximum(np.linalg.norm(a,axis=-1,keepdims=True),1e-10)
def arm_frames(world,names,side,center):
 hand=CAM@world[:,names['hand_'+side]];elbow=(CAM@world[:,names['arm_lower_'+side]])[:,:3,3]
 y=normalize(center-elbow);z=hand[:,:3,2].copy();z-=y*np.sum(y*z,axis=1)[:,None];z=normalize(z);x=np.cross(y,z)
 m=np.broadcast_to(np.eye(4),(len(world),4,4)).copy();m[:,:3,:3]=np.stack([x,y,z],axis=2);m[:,:3,3]=center;return m
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def checksum(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save_png(image,path):
 out=io.BytesIO();image.save(out,format='PNG');tmp=path.with_suffix('.tmp');tmp.write_bytes(out.getvalue());os.replace(tmp,path)
def convert(name,source):
 rig=Rig(DATA/(source+'.cs2.animation.json'));skin=Skin(DATA/(source+'.cs2.skin'));names=rig.names
 v=skin.vertices[skin.indices];dominant=np.argmax(v['weights'],axis=1);joints=v['joints'][np.arange(len(v)),dominant];parts=[]
 assert np.all(np.max(v['weights'],axis=1)>.999),'Weighted vertices require full skinning'
 for joint in sorted(set(map(int,joints))):parts.append((joint,v[joints==joint]))
 out=io.BytesIO();out.write(struct.pack('<II',0x374d4b43,len(parts)))
 for joint,subset in parts:
  out.write(struct.pack('<II',joint,len(subset)));result=np.zeros((len(subset),28),dtype=np.uint8);result[:,:12]=subset['pos'].astype('<f4').view('u1').reshape(-1,12);result[:,12:20]=subset['uv'].astype('<f4').view('u1').reshape(-1,8);result[:,20:24]=255;result[:,24:27]=np.clip(np.rint(subset['normal']*127),-127,127).astype('i1').view('u1');out.write(result.tobytes())
 # Source wrist/knuckle positions define the real grip. The econ bone is a weapon
 # pivot (the Butterfly hinge), not the middle of its handle.
 handle_axis=np.zeros(3);left_handle_axis=np.zeros(3)
 aliases=BASE+[a for a in ['inspect2','inspect3','deploy2','idle2','stabHit','slashHit1','slashHit2'] if a in rig.clips];assert all(a in rig.clips for a in BASE),(name,rig.clips.keys())
 out.write(struct.pack('<I',len(aliases)));loops={}
 for alias in aliases:
  clip=rig.clips[alias];duration=clip['Duration'];frames=int(math.ceil(duration*60))+1;times=np.linspace(0,duration,frames);label=alias.encode()
  marker=next((e for e in clip.get('Events',[]) if e.get('Name')=='WPN_INSPECT_LOOP'),None);start=float(marker['At']) if marker else -1.;end=start+float(marker['Duration']) if marker else -1.
  out.write(struct.pack('<H',len(label))+label+struct.pack('<fffI',duration,start,end,frames));loops[alias]=[start,end]
  world=rig.sample(alias,times);poses=[]
  for joint,verts in parts:
   node=JOINT_ALIASES.get(skin.joints[joint],skin.joints[joint]);assert node in names,(name,node)
   correction=np.eye(4)
   if name=='shadow' and node=='econ':
    local=(skin.bind[joint]@np.column_stack([verts['pos'],np.ones(len(verts))]).T).T[:,:3]
    _,axes=np.linalg.eigh(np.cov(local.T));normal=axes[:,0]
    correction[:3,:3]=Rotation.from_rotvec(normal*math.pi).as_matrix()
   poses.append(CAM@world[:,names[node]]@correction@skin.bind[joint])
  hand_r=CAM@world[:,names['hand_R']];hand_l=CAM@world[:,names['hand_L']]
  center_r=(hand_r[:,:3,3]+(CAM@world[:,names['finger_middle_0_R']])[:,:3,3])*.5
  center_l=(hand_l[:,:3,3]+(CAM@world[:,names['finger_middle_0_L']])[:,:3,3])*.5
  if name!='shadow':
   distance=np.linalg.norm(center_l-center_r,axis=1);weight=smooth((distance-.14)/.18);center_l=center_l*(1-weight[:,None])+np.array([-.135,-.20,-.50])*weight[:,None]
  # Keep the support fist inside a comfortable 1080p first-person frame.
  # The left Shadow Dagger gets the identical camera correction to retain grip.
  before=center_l.copy();frame_y=-.055 if name=='bowie' else -.045;frame_z=-.16 if name=='bowie' else -.10 if name=='karambit' else -.13
  view=center_l+np.array([.015,frame_y,frame_z]);view[:,2]=np.minimum(view[:,2],-.30);depth=-view[:,2]
  view[:,0]=np.clip(view[:,0],-.85*depth,.65*depth);view[:,1]=np.clip(view[:,1],-.40*depth,.45*depth)
  center_l=view-np.array([.015,frame_y,frame_z])
  if name=='shadow':
   correction=center_l-before
   for part,(joint,_) in enumerate(parts):
    if JOINT_ALIASES.get(skin.joints[joint],skin.joints[joint])=='econ_l':poses[part][:,:3,3]+=correction
  poses.extend([arm_frames(world,names,'R',center_r),arm_frames(world,names,'L',center_l)])
  packed=np.stack(poses,axis=1);assert np.all(np.isfinite(packed));out.write(np.asarray(packed.transpose(0,1,3,2),dtype='<f4').tobytes())
 path=DEST/(name+'.ckm');tmp=path.with_suffix('.tmp');tmp.write_bytes(out.getvalue());os.replace(tmp,path)
 if name not in ['karambit','butterfly','bayonet','bowie']:
  save_png(Image.open(DATA/(source+'_cs2.png')),DEST/(name+'-color.png'))
  orm=Image.open(DATA/(source+'_cs2_orm.png')).convert('RGB');a,r,m=orm.split();save_png(Image.merge('RGB',(r,m,a)),DEST/(name+'-surface.png'))
 record={'model':name,'source_id':source,'repository':'https://github.com/zh667/ScCsgoKnives','commit':(DATA/'upstream-commit.txt').read_text().strip(),'animation_source':f'src/ScCsgoKnives/AnimationData/{source}.cs2.animation.json','source_sha256':checksum(DATA/(source+'.cs2.animation.json')),'geometry_source':f'src/ScCsgoKnives/AnimationData/{source}.cs2.skin','geometry_sha256':checksum(DATA/(source+'.cs2.skin')),'aliases':aliases,'source_clips':{a:rig.clips[a]['SourceName'] for a in aliases},'inspect_windows':loops,'camera_space':'Source inches -> Minecraft camera metres','trajectory_compression':False,'format':'CKM7','sha256':checksum(path),'parts':len(parts),'triangles':len(v)//3,'minecraft_hand_retarget':{'karambit':'inspection palm towards source index knuckle / ring' if name=='karambit' else None,'grip_reference':'source wrist and middle knuckle, per animation frame','pommel_offset_metres':handle_axis.tolist(),'left_pommel_offset_metres':left_handle_axis.tolist(),'right_shadow_grip_correction_degrees':180 if name=='shadow' else 0,'shadow_palm':'wrist to middle knuckle, per frame' if name=='shadow' else None,'support_hand':'source near contact; fixed guard otherwise; camera framing keeps support fist visible','left_shadow_framing':'identical support fist/left dagger view translation at frame edges' if name=='shadow' else None}}
 print(name,'parts',len(parts),'triangles',len(v)//3,'clips',len(aliases),'bytes',path.stat().st_size,flush=True);return record
def main():
 DEST.mkdir(parents=True,exist_ok=True);records=[convert(name,source) for name,source in CATALOG]
 (DEST/'animation-provenance-v7.json').write_text(json.dumps(records,indent=2));(DEST/'provenance.json').write_text(json.dumps(records,indent=2))
 (DEST/'knife-manifest.json').write_text(json.dumps([{'id':x['model'],'source_id':x['source_id'],'type':'original CS2 source geometry and per-knife clips'} for x in records],indent=2))
if __name__=='__main__':main()
