from pathlib import Path
import importlib.util,struct,json,io,numpy as np,math
from PIL import Image
from scipy.spatial.transform import Rotation
ROOT=Path(__file__).resolve().parent.parent;S=ROOT/'tools/imported-avatars/known';O=ROOT/'src/main/resources/assets/cakeclient/avatars';O.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('avatar',ROOT/'tools/import-avatars.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def load(name):
 b=(S/(name+'.glb')).read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);g=object.__new__(m.Gltf);g.j=j;g.buf=[b[28+n:]]
 for node in j['nodes']:
  if 'matrix'in node:
   matrix=np.array(node.pop('matrix')).reshape(4,4).T;scale=np.linalg.norm(matrix[:3,:3],axis=0);rot=matrix[:3,:3]/np.maximum(scale,1e-20)
   if np.linalg.det(rot)<0:scale[0]*=-1;rot[:,0]*=-1
   node['translation']=matrix[:3,3].tolist();node['scale']=scale.tolist();node['rotation']=Rotation.from_matrix(rot).as_quat().tolist()
 return g

def image_for(g,material):
 mat=g.j['materials'][material];pbr=mat.get('pbrMetallicRoughness',{});ext=mat.get('extensions',{}).get('KHR_materials_pbrSpecularGlossiness',{});tex=pbr.get('baseColorTexture',ext.get('diffuseTexture'));factor=pbr.get('baseColorFactor',ext.get('diffuseFactor',[1,1,1,1]));im=Image.new('RGBA',(16,16),'white')
 if tex:
  t=g.j['textures'][tex['index']];image=g.j['images'][t.get('source',t.get('extensions',{}).get('EXT_texture_webp',{}).get('source',0))];v=g.j['bufferViews'][image['bufferView']];im=Image.open(io.BytesIO(g.buf[v.get('buffer',0)][v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']])).convert('RGBA')
 # Keep source artwork and material factors; no recoloured replacement art.
 a=np.asarray(im).copy();rgb=a[:,:,:3].astype(float)/255.;rgb=np.power(np.power(rgb,2.2)*np.array(factor[:3]),1/2.2);a[:,:,:3]=np.clip(rgb*255,0,255);a[:,:,3]=(a[:,:,3].astype(float)*factor[3]).astype('u1');return Image.fromarray(a)

def convert(name,file=None):
 g=load(file or name);j=g.j;nodes=j['nodes'];clips=j.get('animations',[])
 # Gltf.sample reads TRS animation. These source exporters use TRS nodes.
 blank={'channels':[],'samplers':[]};clip=next((c for c in clips if any(v in c.get('name','').lower() for v in ['walk','idle'])),clips[0] if clips else blank)
 rest=g.sample(clip,[0])[0];bonekeys=[];bonekeymap={};parts=[]
 def bone(key):
  if key not in bonekeymap:bonekeymap[key]=len(bonekeys);bonekeys.append(key)
  return bonekeymap[key]
 for ni,node in enumerate(nodes):
  if 'mesh' not in node:continue
  for prim in j['meshes'][node['mesh']]['primitives']:
   mat=prim.get('material',0)
   if j['materials'][mat].get('pbrMetallicRoughness',{}).get('baseColorFactor',[1,1,1,1])[3]<.5:continue
   a=prim['attributes'];p=g.arr(a['POSITION']);n=g.arr(a['NORMAL']);uv=g.arr(a['TEXCOORD_0']) if 'TEXCOORD_0'in a else np.zeros((len(p),2));idx=g.arr(prim['indices']).ravel();weights=np.zeros((len(p),4));joint=np.zeros((len(p),4),dtype='<u2')
   if 'skin'in node and 'JOINTS_0'in a:
    si=node['skin'];weights=g.arr(a['WEIGHTS_0']).astype(float);sourcejoints=g.arr(a['JOINTS_0']);
    if j['accessors'][a['WEIGHTS_0']].get('normalized'):weights/=255 if j['accessors'][a['WEIGHTS_0']]['componentType']==5121 else 65535
    weights/=np.maximum(weights.sum(1,keepdims=True),1e-10)
    for k in range(4):
     for local in np.unique(sourcejoints[:,k][weights[:,k]>.00001]):joint[(sourcejoints[:,k]==local)&(weights[:,k]>.00001),k]=bone(('skin',si,int(local)))
   else:weights[:,0]=1;joint[:,0]=bone(('node',ni,0))
   parts.append((p,n,uv,weights,joint,idx,mat))
 print(name,'bones',len(bonekeys),'vertices',sum(len(p[0]) for p in parts),flush=True);assert len(bonekeys)<=128
 def poses(times,clip):
  world=g.sample(clip,times);r=[]
  for typ,index,local in bonekeys:
   if typ=='node':r.append(world[:,index])
   else:
    skin=j['skins'][index];ib=g.arr(skin['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);r.append(world[:,skin['joints'][local]]@ib[local])
  return np.stack(r,axis=1)
 # Atlas each original material separately; source UV islands retained exactly.
 textures={mat:image_for(g,mat) for mat in set(p[6] for p in parts)}
 if name=='neighbor':
  tg=load('neighbor_textured');mapping={0:5,1:0,2:2,3:1};textures={mat:image_for(tg,mapping[mat]) for mat in textures}
 mats=sorted(textures);cell=min(2048,max(max(im.size) for im in textures.values()));cols=math.ceil(math.sqrt(len(mats)));rows=math.ceil(len(mats)/cols);atlas=Image.new('RGBA',(cols*cell,rows*cell),(255,255,255,255));rects={}
 for i,mat in enumerate(mats):
  im=textures[mat];im.thumbnail((cell-4,cell-4),Image.Resampling.LANCZOS);x=i%cols*cell+2;y=i//cols*cell+2;atlas.paste(im,(x,y));rects[mat]=(x,y,im.width,im.height)
 arrays=[];ids=[];offset=0
 for p,n,uv,w,b,idx,mat in parts:
  x,y,tw,th=rects[mat];uv=uv.copy()
  for axis in range(2):
   if uv[:,axis].max()<.05 and uv[:,axis].min()<-.5:uv[:,axis]+=1
  st=np.column_stack([(x+np.clip(uv[:,0],0,1)*tw)/atlas.width,(y+np.clip(uv[:,1],0,1)*th)/atlas.height]);arrays.append(np.column_stack([p,n,st,w,b]));ids.append(idx+offset);offset+=len(p)
 if name in {'mario','luigi','patrick'}:
  # Bake repeating source UVs into independent triangle charts. Clamping source
  # UVs changes tiled face/hand materials and produces false colour patches.
  count=sum(len(part[5])//3 for part in parts);patch=24;pad=2;span=19;columns=math.ceil(math.sqrt(count));atlas=Image.new('RGBA',(columns*patch,columns*patch),(255,255,255,255));yy,xx=np.mgrid[:patch,:patch];bv=(xx.ravel()-pad-.5)/span;bw=(yy.ravel()-pad-.5)/span;weights=np.maximum(np.column_stack([1-bv-bw,bv,bw]),0);weights/=weights.sum(1,keepdims=True);arrays=[];ids=[];counter=0;offset=0
  for pos,norm,uv,ww,joints,indices0,material in parts:
   image=np.array(textures[material]);height,width=image.shape[:2];faces=indices0.reshape(-1,3);newuv=[]
   for face in faces:
    coords=weights@uv[face];coords-=np.floor(coords);tx=coords[:,0]*width-.5;ty=coords[:,1]*height-.5;ix=np.floor(tx).astype(int);iy=np.floor(ty).astype(int);fx=(tx-ix)[:,None];fy=(ty-iy)[:,None];rgb=(image[iy%height,ix%width]*(1-fx)+image[iy%height,(ix+1)%width]*fx)*(1-fy)+(image[(iy+1)%height,ix%width]*(1-fx)+image[(iy+1)%height,(ix+1)%width]*fx)*fy;row,col=divmod(counter,columns);atlas.paste(Image.fromarray(np.clip(rgb,0,255).astype('u1').reshape(patch,patch,4)),(col*patch,row*patch));newuv.extend([((col*patch+pad+.5)/atlas.width,(row*patch+pad+.5)/atlas.height),((col*patch+pad+span+.5)/atlas.width,(row*patch+pad+.5)/atlas.height),((col*patch+pad+.5)/atlas.width,(row*patch+pad+span+.5)/atlas.height)]);counter+=1
   flat=faces.ravel();arrays.append(np.column_stack([pos[flat],norm[flat],np.array(newuv),ww[flat],joints[flat]]));ids.append(np.arange(len(flat))+offset);offset+=len(flat)
 data=np.concatenate(arrays);indices=np.concatenate(ids).astype('<u4');
 # Exact deduplication of identical corners, retaining all seams and weights.
 data,inv=np.unique(data,axis=0,return_inverse=True);indices=inv[indices].astype('<u4');p=data[:,:3];n=data[:,3:6];uv=data[:,6:8];w=data[:,8:12];bones=data[:,12:16].astype('<u2')
 raw=poses([0],clip)[0];v=np.column_stack([p,np.ones(len(p))]);points=sum(np.einsum('nij,nj->ni',raw[bones[:,k]],v)*w[:,k,None] for k in range(4))[:,:3]
 lo=points.min(0);hi=points.max(0);scale=1.8/(hi[1]-lo[1]);C=np.eye(4);C[:3,:3]=np.diag([-scale,scale,-scale]);C[:3,3]=[(lo[0]+hi[0])*.5*scale,-lo[1]*scale,(lo[2]+hi[2])*.5*scale]
 # Idle holds an authored frame; moving uses the author's available clip.
 duration=max((float(g.arr(s['input'])[-1,0]) for s in clip['samplers']),default=1.);frames=max(2,min(181,math.ceil(duration*30)+1));moving=poses(np.linspace(0,duration,frames),clip);idle=np.repeat(moving[:1],2,axis=0)
 out=io.BytesIO();out.write(struct.pack('<5I',0x324d5641,len(data),len(indices),len(bonekeys),2));out.write(data[:,:12].astype('<f4').tobytes());out.write(bones.tobytes());out.write(indices.tobytes())
 for seconds,mat in [(1.,idle),(duration,moving)]:out.write(struct.pack('<fI',seconds,len(mat)));out.write((C@mat).transpose(0,1,3,2).astype('<f4').tobytes())
 (O/(name+'.avm')).write_bytes(out.getvalue());atlas.save(O/(name+'-atlas.png'));normal=C@raw;preview=sum(np.einsum('nij,nj->ni',normal[bones[:,k]],v)*w[:,k,None] for k in range(4))[:,:3];m.render_preview(preview,indices,uv,O/(name+'-atlas.png'),O/(name+'-preview.png'))
 extras=j['asset']['extras'];(O/(name+'-CREDITS.txt')).write_text(json.dumps(extras,indent=2)+'\nChanges: converted with original mesh, UV, material artwork and skinning; normalized for Cake. Idle freezes an author frame; available motion retains original clip.\n'+('Neighbor textures from BillCipher987654321: https://sketchfab.com/3d-models/hello-neighbor-model-06d357fa696e4e968f0c1d9ff321bbfc (CC BY 4.0).\n' if name=='neighbor' else ''));print('DONE',name,len(data),len(indices)//3,atlas.size,flush=True)
if __name__=='__main__':
 for name,file in [('neighbor',None),('knuckles',None),('shrek','shrek_textured'),('donkey',None),('sonic','sonic_alt'),('patrick',None),('mario',None),('luigi',None)]:convert(name,file)
