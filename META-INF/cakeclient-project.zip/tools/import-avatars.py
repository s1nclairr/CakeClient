"""Import Quaternius' original meshes, textures, skin weights and Idle/Walk clips; no shape generation."""
from pathlib import Path
import json,base64,struct,io,os,numpy as np,math
from scipy.spatial.transform import Rotation,Slerp
from PIL import Image
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT/'imported-avatars/original';OUT=ROOT.parent/'src/main/resources/assets/cakeclient/avatars'
CAT=[('frog','Big','Frog','Grenouille'),('chicken','Blob','Chicken','Poulet'),('pigeon','Blob','Pigeon','Pigeon'),('alpaking','Flying','Alpaking','Alpaking'),('fish','Blob','Fish','Poisson pattes'),('glub','Flying','Glub','Glub'),('mushnub','Blob','Mushnub','Mini champignon'),('mushroom_king','Big','MushroomKing','Roi champignon'),('cactoro','Blob','Cactoro','Cactus'),('ghost','Flying','Ghost','Fantôme'),('yeti','Big','Yeti','Yéti'),('green_blob','Blob','GreenBlob','Blob vert'),('pink_blob','Blob','PinkBlob','Slime rose'),('squidle','Flying','Squidle','Pieuvre'),('birb','Blob','Birb','Birb'),('dino','Big','Dino','Dinosaure'),('bunny','Big','Bunny','Lapin costaud'),('cat','Blob','Cat','Chat'),('alien','Blob','Alien','Alien'),('ninja','Big','Ninja','Ninja')]
def atomic(p,b):t=p.with_suffix('.tmp');t.write_bytes(b);os.replace(t,p)
class Gltf:
 def __init__(self,path):
  self.j=json.loads(path.read_text());self.buf=[base64.b64decode(b['uri'].split(',')[1]) for b in self.j['buffers']]
 def arr(self,id):
  a=self.j['accessors'][id];v=self.j['bufferViews'][a['bufferView']];dt={5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.ndarray((a['count'],n),dtype=dt,buffer=self.buf[v['buffer']],offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',np.dtype(dt).itemsize*n),np.dtype(dt).itemsize)).copy()
 def sample(self,clip,times):
  nodes=self.j['nodes'];n=len(nodes);f=len(times);t=np.tile(np.array([x.get('translation',[0,0,0]) for x in nodes]),(f,1,1));s=np.tile(np.array([x.get('scale',[1,1,1]) for x in nodes]),(f,1,1));q=np.tile(np.array([x.get('rotation',[0,0,0,1]) for x in nodes]),(f,1,1))
  for c in clip['channels']:
   sam=clip['samplers'][c['sampler']];ts=self.arr(sam['input']).ravel();v=self.arr(sam['output']);i=c['target']['node'];typ=c['target']['path'];tt=np.clip(times,ts[0],ts[-1]);
   if len(ts)==1:r=np.tile(v[0],(f,1))
   elif typ=='rotation':r=Slerp(ts,Rotation.from_quat(v))(tt).as_quat()
   else:r=np.column_stack([np.interp(tt,ts,v[:,k]) for k in range(v.shape[1])])
   if typ=='translation':t[:,i]=r
   elif typ=='rotation':q[:,i]=r
   elif typ=='scale':s[:,i]=r
  local=np.tile(np.eye(4),(f,n,1,1));local[:,:,:3,:3]=Rotation.from_quat(q.reshape(-1,4)).as_matrix().reshape(f,n,3,3)*s[:,:,None,:];local[:,:,:3,3]=t
  world=local.copy();children={c for x in nodes for c in x.get('children',[])}
  def visit(i,parent):
   world[:,i]=parent@local[:,i]
   for c in nodes[i].get('children',[]):visit(c,world[:,i])
  for i in range(n):
   if i not in children:visit(i,np.eye(4))
  return world

def convert(entry,index):
 id,group,file,label=entry;g=Gltf(SOURCE/group/'glTF'/(file+'.gltf'));j=g.j;node=next(x for x in j['nodes'] if 'mesh'in x);skin=j['skins'][node['skin']];joints=skin['joints'];ib=g.arr(skin['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);prim=j['meshes'][node['mesh']]['primitives'][0];a=prim['attributes'];p=g.arr(a['POSITION']);normal=g.arr(a['NORMAL']);uv=g.arr(a['TEXCOORD_0']);weights=g.arr(a['WEIGHTS_0']);weights/=np.maximum(weights.sum(1,keepdims=True),1e-8);bones=g.arr(a['JOINTS_0']);indices=g.arr(prim['indices']).ravel()
 clips={x['name'].lower():x for x in j['animations']};idle=clips.get('idle',clips.get('flying_idle',clips.get('fly_idle',next((v for k,v in clips.items() if 'idle' in k),next(iter(clips.values()))))));walk=clips.get('walk',clips.get('fly',next((v for k,v in clips.items() if any(x in k for x in ['flying','fly','run'])),idle)));raw=g.sample(idle,[0])[0,joints]@ib
 v=np.column_stack([p,np.ones(len(p))]);trans=sum((np.einsum('nij,nj->ni',raw[bones[:,k]],v)*weights[:,k,None] for k in range(4)))[:,:3];lo=trans.min(0);hi=trans.max(0);scale=1.8/(hi[1]-lo[1]);C=np.eye(4);C[:3,:3]=np.diag([-scale,scale,-scale]);C[:3,3]=[(lo[0]+hi[0])*.5*scale,-lo[1]*scale,(lo[2]+hi[2])*.5*scale]
 # Keep original weights, vertex normals and UV; one shared source atlas.
 out=io.BytesIO();out.write(struct.pack('<5I',0x324d5641,len(p),len(indices),len(joints),2));data=np.column_stack([p,normal,uv,weights]).astype('<f4');out.write(data.tobytes());out.write(bones.astype('<u2').tobytes());out.write(indices.astype('<u4').tobytes())
 previews=None
 for clip in [idle,walk]:
  duration=max(float(g.arr(s['input'])[-1,0]) for s in clip['samplers']);frames=max(2,int(math.ceil(duration*30))+1);times=np.linspace(0,duration,frames);world=g.sample(clip,times);m=C@world[:,joints]@ib
  out.write(struct.pack('<fI',duration,frames));out.write(m.transpose(0,1,3,2).astype('<f4').tobytes())
  if previews is None:previews=sum(np.einsum('nij,nj->ni',m[0,bones[:,k]],v)*weights[:,k,None] for k in range(4))[:,:3]
 atomic(OUT/(id+'.avm'),out.getvalue());render_preview(previews,indices,uv,SOURCE/'Atlas_Monsters.png',OUT/f'preview-{index}.png')
 print(id,len(p),len(indices)//3,len(joints),'clips',idle['name'],walk['name'],flush=True)
 return {'id':id,'name':label,'source':f'{group}/glTF/{file}.gltf','vertices':len(p),'triangles':len(indices)//3,'joints':len(joints),'clips':[idle['name'],walk['name']]}

def render_preview(p,indices,uv,texture,dest):
 size=720;canvas=np.zeros((size,size,4),np.uint8);canvas[:]=[19,16,28,255];depth=np.full((size,size),np.inf);tex=np.array(Image.open(texture).convert('RGB'));yaw=-.4;pitch=.12;R=Rotation.from_euler('yx',[yaw,pitch]).as_matrix();rp=(R@(p-np.array([0,.9,0])).T).T;factor=610/max(np.ptp(rp[:,0]),np.ptp(rp[:,1]));screen=rp[:,:2]*factor;screen[:,1]*=-1;screen+=size/2
 for tri in indices.reshape(-1,3):
  xy=screen[tri];z=rp[tri,2];xmin=max(0,int(xy[:,0].min()));xmax=min(size-1,int(xy[:,0].max())+1);ymin=max(0,int(xy[:,1].min()));ymax=min(size-1,int(xy[:,1].max())+1)
  if xmin>=xmax or ymin>=ymax:continue
  x,y=np.meshgrid(np.arange(xmin,xmax+1)+.5,np.arange(ymin,ymax+1)+.5);a,b,c=xy;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);
  if abs(den)<1e-9:continue
  w0=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/den;w1=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/den;w2=1-w0-w1;zz=w0*z[0]+w1*z[1]+w2*z[2];d=depth[ymin:ymax+1,xmin:xmax+1];mask=(w0>=0)&(w1>=0)&(w2>=0)&(zz<d)
  if not mask.any():continue
  st=w0[...,None]*uv[tri[0]]+w1[...,None]*uv[tri[1]]+w2[...,None]*uv[tri[2]];tx=np.clip((st[:,:,0]*tex.shape[1]).astype(int),0,tex.shape[1]-1);ty=np.clip((st[:,:,1]*tex.shape[0]).astype(int),0,tex.shape[0]-1);n=np.cross(p[tri[1]]-p[tri[0]],p[tri[2]]-p[tri[0]]);n/=max(np.linalg.norm(n),1e-9);shade=.55+.45*max(0,np.dot(n,[-.4,.8,-.6]));rgb=(tex[ty,tx]*shade).astype(np.uint8);canvas[ymin:ymax+1,xmin:xmax+1,:3][mask]=rgb[mask];d[mask]=zz[mask]
 im=Image.fromarray(canvas).resize((1080,1080),Image.Resampling.LANCZOS);b=io.BytesIO();im.save(b,format='PNG');atomic(dest,b.getvalue())
if __name__=='__main__':
 OUT.mkdir(exist_ok=True);records=[convert(e,i) for i,e in enumerate(CAT)];atomic(OUT/'catalog.json',json.dumps(records,indent=2,ensure_ascii=False).encode());atomic(OUT/'atlas.png',(SOURCE/'Atlas_Monsters.png').read_bytes());atomic(OUT/'CREDITS.txt',b'Quaternius - Ultimate Monsters - CC0 1.0\nhttps://quaternius.com/packs/ultimatemonsters.html\nOriginal meshes, UVs, textures and animation clips retained. Converted to AVM2 for Cake.\nArchive mirror: https://herni-studio-tokoupim.cz/asset-knihovna/balik/quaternius-ultimatemonsters/\n')
