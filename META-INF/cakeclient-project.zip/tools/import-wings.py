import re,json,pathlib,shutil
root=next(pathlib.Path('project/tools/imported-wings').glob('Wings-*'));out=pathlib.Path('project/src/main/resources/assets/cakeclient/back');out.mkdir(parents=True,exist_ok=True)
num=lambda s:[float(x.strip().rstrip('FfDd')) for x in s.split(',')]
for name in ['Avian','Insectoid']:
 s=(root/f'src/main/java/me/paulf/wings/client/model/ModelWings{name}.java').read_text();bones={}
 for m in re.finditer(r'(?:this\.)?(\w+) = new ModelRenderer\(this(?:, (\d+), (\d+))?\)',s):bones[m[1]]={'name':m[1],'parent':'','pivot':[0,0,0],'uv':[int(m[2] or 0),int(m[3] or 0)],'shapes':[]}
 for n,args in re.findall(r'(?:this\.)?(\w+)\.setPos\(([^;]+)\)',s):bones[n]['pivot']=num(args)
 for n,args in re.findall(r'(?:this\.)?(\w+)\.addBox\(([^;]+)\)',s):bones[n]['shapes'].append({'box':num(args)[:6],'uv':bones[n]['uv'],'plane':False})
 for n,args in re.findall(r'add3DTexture\((\w+), ([^;]+)\)',s):
  a=num(args);bones[n]['shapes'].append({'box':a[2:5]+a[5:7]+[1],'uv':a[:2],'plane':True})
 for a,b in re.findall(r'(?:this\.)?(\w+)\.addChild\((?:this\.)?(\w+)\)',s):bones[b]['parent']=a
 ordered=[]
 def visit(n):
  ordered.append(bones[n]);[visit(k) for k,v in bones.items() if v['parent']==n]
 visit('root');(out/(name.lower()+'.json')).write_text(json.dumps(ordered))
for p in (root/'src/main/resources/assets/wings/textures/entity').glob('*.png'):shutil.copy(p,out/p.name)
shutil.copy(root/'LICENSE.md',out/'WINGS-LICENSE.txt')
(out/'CREDITS.txt').write_text('Wings models and textures by Paul Fulham (pau101), MIT. https://github.com/pau101/Wings commit 174929878d09490b012dbfa4e8d23d56f02b5add. Geometry and original UV imported from ModelWingsAvian / Insectoid. Cake port adds cosmetic animation.\n')
print([(p.name,p.stat().st_size) for p in out.glob('*.json')])
