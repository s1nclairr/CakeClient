from PIL import Image,ImageDraw
import io,zipfile,json,random,math
from pathlib import Path
out=Path('/mnt/data/cake-big/CakeClient-Potato-1.21.11.zip')
blocks='stone cobblestone mossy_cobblestone deepslate cobbled_deepslate tuff granite polished_granite diorite polished_diorite andesite polished_andesite dirt grass_block_top grass_block_side grass_block_snow grass_block_side_overlay podzol_top podzol_side mycelium_top mycelium_side coarse_dirt rooted_dirt mud packed_mud clay sand sandstone_top sandstone sand_stone red_sand red_sandstone red_sandstone_top gravel obsidian netherrack soul_sand soul_soil basalt basalt_side blackstone gilded_blackstone bedrock end_stone end_stone_bricks purpur_block purpur_pillar stone_bricks mossy_stone_bricks cracked_stone_bricks chiseled_stone_bricks bricks mud_bricks oak_planks spruce_planks birch_planks jungle_planks acacia_planks dark_oak_planks mangrove_planks cherry_planks bamboo_planks crimson_planks warped_planks pale_oak_planks oak_log oak_log_top spruce_log spruce_log_top birch_log birch_log_top jungle_log jungle_log_top acacia_log acacia_log_top dark_oak_log dark_oak_log_top mangrove_log mangrove_log_top cherry_log cherry_log_top oak_leaves spruce_leaves birch_leaves jungle_leaves acacia_leaves dark_oak_leaves mangrove_leaves cherry_leaves azalea_leaves flowering_azalea_leaves pale_oak_leaves oak_sapling short_grass tall_grass grass fern large_fern grass_block dirt_path farmland farmland_moist iron_block gold_block diamond_block emerald_block lapis_block redstone_block netherite_block copper_block exposed_copper weathered_copper oxidized_copper iron_ore gold_ore copper_ore diamond_ore emerald_ore lapis_ore coal_ore redstone_ore nether_quartz_ore nether_gold_ore ancient_debris deepslate_iron_ore deepslate_gold_ore deepslate_diamond_ore deepslate_redstone_ore deepslate_coal_ore deepslate_copper_ore deepslate_emerald_ore deepslate_lapis_ore glass glass_pane_top white_wool black_wool gray_wool light_gray_wool red_wool orange_wool yellow_wool green_wool blue_wool purple_wool cyan_wool pink_wool white_concrete black_concrete gray_concrete red_concrete blue_concrete purple_concrete white_terracotta orange_terracotta red_terracotta blue_terracotta stone_slab_top oak_trapdoor furnace_front crafting_table_front crafting_table_top bookshelf hay_block_side hay_block_top glowstone sea_lantern shroomlight magma water_still lava_still snow ice packed_ice blue_ice moss_block sculk sculk_catalyst sculk_sensor_top dripstone_block calcite amethyst_block budding_amethyst smooth_stone smooth_sandstone smooth_quartz stone_brick_slab_top'.split()
def color_for(n):
 palette={'stone':(112,117,122),'slate':(65,70,84),'tuff':(106,115,107),'dirt':(104,71,48),'grass':(82,132,48),'sand':(220,200,144),'wood':(146,106,67),'planks':(140,104,65),'log':(100,70,50),'leaves':(67,111,59),'ore':(114,117,122),'deepslate':(72,76,85),'nether':(115,53,57),'snow':(223,226,233),'ice':(133,182,210),'water':(40,99,169),'lava':(237,111,34),'black':(36,37,44),'white':(215,215,218),'diamond':(62,193,208),'emerald':(46,195,113),'gold':(227,173,51),'iron':(177,183,190),'purple':(144,77,169),'blue':(50,91,169),'red':(164,51,55)}
 if n.endswith('wool') or 'concrete' in n or 'terracotta' in n:
  for c in ['black','white','purple','blue','red','orange','yellow','pink','green','cyan','gray']: 
   if n.startswith(c):return {'orange':(206,107,40),'yellow':(213,169,46),'pink':(221,124,163),'green':(89,138,62),'cyan':(62,141,145),'gray':(121,119,124)}.get(c,palette.get(c,(125,111,133)))
 for kw in ['grass','diamond','emerald','gold','iron','purple','deepslate','nether','leaves','planks','log','sand','ice','water','lava','snow','black','white','slate','dirt','tuff','stone']:
  if kw in n:return palette.get(kw,(114,106,100))
 return (131,114,109)
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('pack.mcmeta',json.dumps({'pack':{'description':'Cake Client / Potato - low-detail 8x textures for 1.21.11','min_format':[75,0],'max_format':[75,0]}},indent=2))
 for n in sorted(set(blocks)):
  seed=sum((i+1)*ord(c) for i,c in enumerate(n));r=random.Random(seed);base=color_for(n);transparent=n in ('glass','glass_pane_top','short_grass','fern','grass','tall_grass','large_fern','oak_sapling')
  im=Image.new('RGBA',(8,8));p=im.load()
  for y in range(8):
   for x in range(8):
    d=r.randint(-12,12);rgb=tuple(max(0,min(255,i+d)) for i in base)
    a=255
    if transparent and (x==0 or y==0 or (x+y)%7==0):a=0
    p[x,y]=(*rgb,a)
  b=io.BytesIO();im.save(b,format='PNG',optimize=True)
  z.writestr('assets/minecraft/textures/block/'+n+'.png',b.getvalue())
 print('Resource pack created',len(set(blocks)),'block textures',out.stat().st_size,'bytes')
