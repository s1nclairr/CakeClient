from pathlib import Path
from PIL import Image
import zipfile,json,io,shutil,re
out=Path('project/src/main/resources/assets/cakeclient/realism');out.mkdir(parents=True,exist_ok=True)
root=next(Path('/tmp/xs').glob('*'));tex=root
if not (tex/'assets').exists():tex=root
count=0
with zipfile.ZipFile(out/'Cake-Realism-256x.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('pack.mcmeta',json.dumps({'pack':{'description':'XsRealism photographic textures · darkyboys / MIT · adapted to 256px','min_format':[75,0],'max_format':[75,0],'pack_format':75}}));z.write(root/'LICENSE','LICENSE-XsRealism.txt');z.writestr('CREDITS.txt','XsRealism-256x by darkyboys, MIT. https://github.com/darkyboys/XsRealism-256x commit f6568ec6722fe8f0b0f21cf3179a31fc0fea9b69. Images above 256px resampled with Lanczos, animation frames retained.\n')
 for p in (tex/'assets').rglob('*'):
  if not p.is_file():continue
  path=str(p.relative_to(tex));
  if not re.fullmatch('[a-z0-9_./-]+',path):continue
  if p.suffix=='.png':
   im=Image.open(p);w,h=im.size
   if w>256:im=im.resize((256,max(1,round(h*256/w))),Image.Resampling.LANCZOS)
   b=io.BytesIO();im.save(b,format='PNG');z.writestr(path,b.getvalue());count+=1
  elif p.suffix in ['.mcmeta','.json']:z.write(p,path)
print('textures',count)
with zipfile.ZipFile('project/tools/imported-realism/Realis_v1.2.zip') as src,zipfile.ZipFile(out/'Cake-Realis.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in src.namelist():
  b=src.read(name)
  if name.endswith(('.vsh','.fsh','.glsl')):b=b.decode().replace('#version 330 compatibility','#version 130').replace('ftransform()','(gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex)').encode()
  z.writestr(name,b)
 z.writestr('CAKE-CHANGES.txt','Realis v1.2 by fr1ks (MIT), https://modrinth.com/shader/realis. Cake adaptation: legacy GLSL version 130 for Iris core translation, ftransform expanded. Original license retained.\n')
shutil.copy('project/tools/imported-realism/realis.json',out/'UPSTREAM-Realis.json')
p=Path('project/src/main/resources/META-INF/jars');p.mkdir(parents=True,exist_ok=True)
for f in ['iris-fabric-1.10.8+mc1.21.11.jar','sodium-fabric-0.8.14+mc1.21.11.jar']:shutil.copy('project/tools/imported-realism/'+f,p/f)
f=Path('project/src/main/resources/fabric.mod.json');j=json.loads(f.read_text());j['jars']=[{'file':'META-INF/jars/'+x.name} for x in p.glob('*.jar')];f.write_text(json.dumps(j,indent=2))
