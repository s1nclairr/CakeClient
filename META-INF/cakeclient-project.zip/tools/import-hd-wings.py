"""Preserve Nobby76/Boooooop's CC-BY mesh, normals and original UV/texture art."""
from pathlib import Path
import struct,json,numpy as np
from PIL import Image
P=Path(__file__).resolve().parent;S=P/'imported-wing-hd';O=P.parent/'src/main/resources/assets/cakeclient/back/hd';O.mkdir(parents=True,exist_ok=True)
b=(S/'angel.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);buf=b[28+n:]
def arr(i):
 a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];dim={'SCALAR':1,'VEC2':2,'VEC3':3}[a['type']];return np.frombuffer(buf,dtype=dt,count=a['count']*dim,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,dim)
out=bytearray(struct.pack('<II',0x31445743,4));stats=[]
for side,mesh in enumerate(j['meshes']):
 for p in mesh['primitives']:
  a=p['attributes'];pos=arr(a['POSITION']);normal=arr(a['NORMAL']);uv=arr(a['TEXCOORD_0']);idx=arr(p['indices']).ravel();data=np.column_stack([pos,normal,uv]).astype('<f4')
  out+=struct.pack('<4I',side,p['material'],len(pos),len(idx))+data.tobytes()+idx.astype('<u4').tobytes();stats.append({'side':side,'material':p['material'],'vertices':len(pos),'triangles':len(idx)//3})
(O/'angel.cwd').write_bytes(out)
# Extract GLB KTX2 images with the official KTX-Software CLI, then preserve native resolution.
import subprocess,tempfile,os
ktx=os.environ.get('KTX_BIN','ktx')
for image_index,name in [(1,'feather'),(3,'wing')]:
 im=j['images'][image_index];v=j['bufferViews'][im['bufferView']]
 with tempfile.TemporaryDirectory() as tmp:
  f=Path(tmp)/'input.ktx2';f.write_bytes(buf[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]);subprocess.run([ktx,'extract','--transcode','rgba8',str(f),str(O/(name+'.png'))],check=True)
(O/'provenance.json').write_text(json.dumps({'title':'Angel-wings','author':'Nobby76, based on Boooooop','license':'CC-BY-4.0','source':'https://sketchfab.com/3d-models/angel-wings-33a689cfaf33427286c8f98956f5cd1e','changes':'Split shoulder pivots from credited SkyDOS adaptation; converted indexed mesh; runtime cosmetic hinge animation. Original texture resolution and artwork preserved.','parts':stats,'textures':{'feather':[512,512],'wing':[768,768]}},indent=2))
print(stats)
