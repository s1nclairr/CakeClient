from pathlib import Path
import json,zipfile,io,math,os,numpy as np
from PIL import Image
from scipy.spatial.transform import Rotation
ROOT=Path(__file__).resolve().parent.parent/'src/main/resources/assets/cakeclient/pvp';catalog=json.loads((ROOT/'catalog.json').read_text())
N=1080
FACES={'north':[0,1,2,3],'south':[5,4,7,6],'west':[4,0,3,7],'east':[1,5,6,2],'up':[3,2,6,7],'down':[4,5,1,0]}
def box(lo,hi,faces,rotation=None):
 x,y,z=lo;X,Y,Z=hi;p=np.array([[x,y,z],[X,y,z],[X,Y,z],[x,Y,z],[x,y,Z],[X,y,Z],[X,Y,Z],[x,Y,Z]],float)
 if rotation is not None:p=rotation(p)
 return [(p[ids],tex,uv) for side,ids in FACES.items() if side in faces for tex,uv in [faces[side]]]
def texture(data):
 im=Image.open(io.BytesIO(data)).convert('RGBA');return im.crop((0,0,im.width,im.width)) if im.height>im.width else im

def model_mesh(entries,path):
 j=json.loads(entries[path]);textures=j.get('textures',{});mesh=[]
 for e in j.get('elements',[]):
  faces={}
  for side,f in e['faces'].items():
   t=f['texture'];seen=set()
   while t.startswith('#') and t not in seen:seen.add(t);t=textures.get(t[1:],'minecraft:item/mace')
   ns,rel=t.split(':',1) if ':'in t else ('minecraft',t);key=f'assets/{ns}/textures/{rel}.png'
   if key not in entries:continue
   im=texture(entries[key]);uv=np.array(f.get('uv',[0,0,16,16]),float)/16
   faces[side]=(im,uv)
  rot=None
  if 'rotation'in e:
   r=e['rotation'];axis='xyz'.index(r['axis']);origin=np.array(r['origin']);R=Rotation.from_rotvec(np.eye(3)[axis]*math.radians(r['angle'])).as_matrix();scale=1/math.cos(math.radians(r['angle'])) if r.get('rescale')else 1;sc=np.ones(3)*scale;sc[axis]=1
   rot=lambda p,R=R,origin=origin,sc=sc:((p-origin)*sc)@R.T+origin
  mesh+=box(e['from'],e['to'],faces,rot)
 return mesh

def crystal(im):
 result=[]
 def part(dim,uv,scale,center,rotation):
  x,y,z=dim;u,v=uv;map={'west':[u,v+z,u+z,v+z+y],'east':[u+z+x,v+z,u+2*z+x,v+z+y],'north':[u+z,v+z,u+z+x,v+z+y],'south':[u+2*z+x,v+z,u+2*z+2*x,v+z+y],'up':[u+z,v,u+z+x,v+z],'down':[u+z+x,v,u+z+2*x,v+z]}
  faces={k:(im,np.array(val)/[64,32,64,32]) for k,val in map.items()};lo=-np.array(dim)/2;hi=np.array(dim)/2;R=rotation
  return box(lo,hi,faces,lambda p:(p*scale)@R.T+center)
 R=Rotation.from_rotvec(np.array([1,0,1])/math.sqrt(2)*math.pi/3).as_matrix();I=np.eye(3)
 result+=part((12,4,12),(0,16),1,[0,-11,0],I)
 result+=part((8,8,8),(32,0),.875*.765625,[0,1,0],R@R@R)
 result+=part((8,8,8),(0,0),.875,[0,1,0],R@R)
 result+=part((8,8,8),(0,0),1,[0,1,0],R)
 return result

def render(mesh,angle,path):
 R=Rotation.from_euler('yx',[math.radians(-35+angle*90),math.radians(20)]).as_matrix();points=np.concatenate([m[0] for m in mesh]);center=(points.min(0)+points.max(0))/2;rp=(points-center)@R.T;scale=850/max(np.ptp(rp[:,0]),np.ptp(rp[:,1]));canvas=np.zeros((N,N,4),np.uint8);canvas[:]=[18,16,25,255]
 tris=[]
 for p,im,rect in mesh:
  r=(p-center)@R.T;xy=r[:,:2]*scale;xy[:,1]*=-1;xy+=N/2;u0,v0,u1,v1=rect;uv=np.array([[u0,v1],[u1,v1],[u1,v0],[u0,v0]])
  normal=np.cross(p[1]-p[0],p[2]-p[0]);normal/=max(np.linalg.norm(normal),1e-9);shade=.60+.4*abs(np.dot(normal,[-.4,.8,-.6]));tex=np.array(im)
  for ids in [[0,1,2],[0,2,3]]:tris.append((r[ids,2].mean(),xy[ids],uv[ids],tex,shade))
 for _,xy,uv,tex,shade in sorted(tris,reverse=True,key=lambda x:x[0]):
  xmin=max(0,int(xy[:,0].min()));xmax=min(N-1,int(xy[:,0].max())+1);ymin=max(0,int(xy[:,1].min()));ymax=min(N-1,int(xy[:,1].max())+1)
  if xmin>=xmax or ymin>=ymax:continue
  x,y=np.meshgrid(np.arange(xmin,xmax+1)+.5,np.arange(ymin,ymax+1)+.5);a,b,c=xy;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);
  if abs(den)<1e-9:continue
  w0=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/den;w1=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/den;w2=1-w0-w1;mask=(w0>=0)&(w1>=0)&(w2>=0)
  st=w0[...,None]*uv[0]+w1[...,None]*uv[1]+w2[...,None]*uv[2];tx=np.clip((st[:,:,0]*tex.shape[1]).astype(int),0,tex.shape[1]-1);ty=np.clip((st[:,:,1]*tex.shape[0]).astype(int),0,tex.shape[0]-1);rgba=tex[ty,tx].copy();alpha=rgba[:,:,3:4]/255.;dst=canvas[ymin:ymax+1,xmin:xmax+1,:3];rgb=np.clip(rgba[:,:,:3]*shade,0,255);dst[mask]=(rgb*alpha+dst*(1-alpha))[mask].astype(np.uint8)
 im=Image.fromarray(canvas);buf=io.BytesIO();im.save(buf,format='PNG');path.parent.mkdir(exist_ok=True);tmp=path.with_suffix('.tmp');tmp.write_bytes(buf.getvalue());os.replace(tmp,path)
for choice in [c for c in catalog[1:] if not (ROOT/"previews"/f"{c['id']}-{c['items'][0]}-0.png").exists()]:
 v=choice['id']
 for item in choice['items']:
  p=ROOT/(f'{v}.zip' if v<=8 else f'{v}-{item}.zip');z=zipfile.ZipFile(p);entries={k:z.read(k) for k in z.namelist()};mesh=[]
  if item in [1,2]:
   key='assets/minecraft/models/item/mace.json'
   if item==1 and key not in entries:
    if 'assets/minecraft/models/item/mace_in_hand.json'in entries:key='assets/minecraft/models/item/mace_in_hand.json'
   if item==1 and key in entries:mesh=model_mesh(entries,key)
   if not mesh:
    path='assets/minecraft/textures/item/'+('mace' if item==1 else 'totem_of_undying')+'.png';im=texture(entries[path]);bg=Image.new('RGBA',(N,N),(18,16,25,255));im.thumbnail((850,850),Image.Resampling.NEAREST);# scale up with no smoothing
    s=850/max(im.size);im=im.resize((round(im.width*s),round(im.height*s)),Image.Resampling.NEAREST);bg.alpha_composite(im,((N-im.width)//2,(N-im.height)//2));d=ROOT/'previews';d.mkdir(exist_ok=True);bg.save(d/f'{v}-{item}-0.png');continue
  elif item==0:mesh=crystal(Image.open(io.BytesIO(entries['assets/minecraft/textures/entity/end_crystal/end_crystal.png'])).convert('RGBA'))
  else:
   if item==3:
    im=texture(entries['assets/minecraft/textures/block/obsidian.png']);faces={k:(im,[0,0,1,1]) for k in FACES}
   else:
    models=[k for k in entries if '/models/block/respawn_anchor'in k]
    if models:
     j=json.loads(entries[next((k for k in models if 'charge4'in k),next((k for k in models if 'welt.json'in k),models[-1]))]);faces={};texmap=j['textures']
     for side in FACES:
      name=texmap.get('top' if side=='up' else 'bottom' if side=='down' else 'side');ns,rel=name.split(':',1)if ':'in name else ('minecraft',name);faces[side]=(texture(entries[f'assets/{ns}/textures/{rel}.png']),[0,0,1,1])
    else:faces={side:(texture(entries['assets/minecraft/textures/block/respawn_anchor_'+('top'if side=='up'else'bottom'if side=='down'else'side4')+'.png']),[0,0,1,1]) for side in FACES}
   mesh=box([0,0,0],[16,16,16],faces)
  for angle in range(4):render(mesh,angle,ROOT/'previews'/f'{v}-{item}-{angle}.png')
 print('preview',v,choice['name'],flush=True)
