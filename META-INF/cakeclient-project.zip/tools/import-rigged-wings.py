from pathlib import Path
import importlib.util,zipfile,json,io,struct,numpy as np,math
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('source',ROOT/'import-avatars.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
S=ROOT/'imported-avatars/original';O=ROOT.parent/'src/main/resources/assets/cakeclient/back/hd';O.mkdir(exist_ok=True)
for name in ['Dragon','Dragon_Evolved','Alpaking']:
 f='Flying/glTF/'+name+'.gltf';g=m.Gltf(S/f);j=g.j;node=next(n for n in j['nodes'] if 'mesh' in n);skin=j['skins'][node['skin']];joints=skin['joints'];print(name,'joints',[(i,j['nodes'][b].get('name')) for i,b in enumerate(joints)],flush=True)
 ib=g.arr(skin['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1);p=j['meshes'][node['mesh']]['primitives'][0];a=p['attributes'];pos=g.arr(a['POSITION']);norm=g.arr(a['NORMAL']);uv=g.arr(a['TEXCOORD_0']);w=g.arr(a['WEIGHTS_0']);bones=g.arr(a['JOINTS_0']);idx=g.arr(p['indices']).ravel().reshape(-1,3)
 wb=np.array([i for i,b in enumerate(joints) if j['nodes'][b].get('name','').startswith('Wing')]);amount=(w*np.isin(bones,wb)).sum(1);idx=idx[np.all(amount[idx]>.65,axis=1)];unique=np.unique(idx);lookup=np.zeros(len(pos),dtype='u4');lookup[unique]=np.arange(len(unique));idx=lookup[idx].ravel();pos=pos[unique];norm=norm[unique];uv=uv[unique];w=w[unique];bones=bones[unique]
 clip=next(c for c in j['animations'] if c['name']=='Flying_Idle');world=g.sample(clip,[0])[0];root=(world[joints[wb[0]],:3,3]+world[joints[wb[4]],:3,3])*.5;raw=world[joints]@ib;v=np.column_stack([pos,np.ones(len(pos))]);points=sum(np.einsum('nij,nj->ni',raw[bones[:,k]],v)*w[:,k,None] for k in range(4))[:,:3];scale=2.8/np.ptp(points[:,0]);C=np.eye(4);C[:3,:3]*=scale;C[:3,3]=-root*scale
 data=np.column_stack([pos,norm,uv,w]).astype('<f4');out=io.BytesIO();out.write(struct.pack('<5I',0x324d5641,len(pos),len(idx),len(joints),2));out.write(data.tobytes());out.write(bones.astype('<u2').tobytes());out.write(idx.astype('<u4').tobytes())
 duration=max(float(g.arr(c['input'])[-1,0]) for c in clip['samplers']);frames=max(2,math.ceil(duration*30)+1);world=g.sample(clip,np.linspace(0,duration,frames));mat=C@world[:,joints]@ib
 for _ in range(2):out.write(struct.pack('<fI',duration,frames));out.write(mat.transpose(0,1,3,2).astype('<f4').tobytes())
 (O/(name.lower()+'.avm')).write_bytes(out.getvalue());print('Wing-only mesh',name,len(pos),len(idx)//3,'span',np.ptp(points[:,0])*scale,'height',np.ptp(points[:,1])*scale,flush=True)
