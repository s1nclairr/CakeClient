from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import math,io,os
out=Path(__file__).resolve().parent.parent/'src/main/resources/assets/cakeclient/fx';out.mkdir(parents=True,exist_ok=True)
N=1080;cells=[]
def points(n,r,phase=-math.pi/2):return [(540+math.cos(phase+i*math.tau/n)*r,540+math.sin(phase+i*math.tau/n)*r) for i in range(n)]
def star(d,n,r1,r2,w=5):
 p=[(540+math.cos(-math.pi/2+i*math.pi/n)*(r1 if i%2==0 else r2),540+math.sin(-math.pi/2+i*math.pi/n)*(r1 if i%2==0 else r2)) for i in range(n*2)];d.line(p+[p[0]],fill='white',width=w,joint='curve')
for idx in range(24):
 core=Image.new('RGBA',(N,N));d=ImageDraw.Draw(core)
 if idx==0:
  for r in range(230,0,-1):d.ellipse((540-r,540-r,540+r,540+r),fill=(255,255,255,int(255*(1-r/231)**1.5)))
 elif idx==1:d.polygon(points(4,240),fill='white');d.line(points(4,340)+[points(4,340)[0]],fill=(255,255,255,140),width=9)
 elif idx in [2,6,21]:
  star(d,4,380,45,11);d.ellipse((500,500,580,580),fill='white')
 elif idx==3:
  for k in range(5):
   a=k*math.tau/5;x=540+math.cos(a)*170;y=540+math.sin(a)*170;d.ellipse((x-130,y-130,x+130,y+130),fill=(255,255,255,210))
 elif idx==4:d.polygon([(540,100),(700,530),(850,700),(660,910),(430,930),(250,750),(375,480),(420,690)],fill='white')
 elif idx==5:
  for i in range(6):
   a=i*math.pi/3;d.line((540,540,540+math.cos(a)*350,540+math.sin(a)*350),fill='white',width=13)
 elif idx==7:
  for x in range(N):
   a=int(255*math.exp(-((x-540)/95)**2));d.line((x,0,x,N),fill=(255,255,255,a))
 elif 8<=idx<20:
  style=idx-8;d.ellipse((105,105,975,975),outline='white',width=9);d.ellipse((125,125,955,955),outline=(255,255,255,100),width=2)
  if style in [1,2,10]:d.ellipse((215,215,865,865),outline=(255,255,255,200),width=4)
  if style==2:d.ellipse((340,340,740,740),outline=(255,255,255,150),width=3)
  if style in [3,4,9]:
   p=points(6 if style==3 else 12 if style==4 else 5,360);d.line(p+[p[0]],fill=(255,255,255,210),width=5)
  if style in [4,5,11]:
   for i in range(24 if style==11 else 12):
    a=i*math.tau/(24 if style==11 else 12);r=395;d.line((540+math.cos(a)*r,540+math.sin(a)*r,540+math.cos(a)*(r+60),540+math.sin(a)*(r+60)),fill='white',width=4)
  if style==4:
   for i in range(8):
    a=i*math.pi/4;x=540+math.cos(a)*280;y=540+math.sin(a)*280;d.line((x-12,y-20,x,y+20,x+12,y-20),fill='white',width=4)
  if style==6:
   for i in range(3):
    p=points(3,365,i*math.tau/9);d.line(p+[p[0]],fill=(255,255,255,190),width=4)
  if style==7:
   for i in range(48):
    a=i*math.tau/48;x=540+math.cos(a)*330;y=540+math.sin(a)*330;d.ellipse((x-7,y-7,x+7,y+7),fill='white')
  if style==8:
   p=[(540+math.cos(i*math.tau/240)*(280+90*math.cos(i*math.tau/240*8)),540+math.sin(i*math.tau/240)*(280+90*math.cos(i*math.tau/240*8))) for i in range(241)];d.line(p,fill='white',width=4)
  if style==9:star(d,5,350,150,5)
  if style==11:
   for a in [0,.18,.36]:d.arc((225,225,855,855),start=30+a*180,end=160+a*180,fill=(255,255,255,170),width=6)
 elif idx==20:
  d.ellipse((240,260,550,570),fill='white');d.ellipse((530,260,840,570),fill='white');d.polygon([(255,480),(825,480),(540,850)],fill='white')
 elif idx==22:d.ellipse((190,190,890,890),outline='white',width=12);d.arc((250,250,830,830),210,270,fill='white',width=22)
 elif idx==23:d.ellipse((320,120,760,960),fill='white');d.line((540,180,540,900),fill=(255,255,255,180),width=14)
 # Thin luminous core, broad soft glow: precomputed, no blur pass while playing.
 halo=core.filter(ImageFilter.GaussianBlur(19));halo.putalpha(halo.getchannel('A').point(lambda a:int(a*.6)));bloom=core.filter(ImageFilter.GaussianBlur(6));tile=Image.alpha_composite(Image.alpha_composite(halo,bloom),core)
 cells.append(tile.resize((320,320),Image.Resampling.LANCZOS))
atlas=Image.new('RGBA',(1280,1920))
for i,tile in enumerate(cells):atlas.alpha_composite(tile,((i%4)*320,(i//4)*320))
b=io.BytesIO();atlas.save(b,format='PNG');temp=out/'atlas.tmp';temp.write_bytes(b.getvalue());os.replace(temp,out/'atlas.png');print('FX atlas ready')
