"""Original Cake 3D caricatures. Meshes, materials and preview rasterizer are authored here."""
from pathlib import Path
import numpy as np, math, struct, io, os
from PIL import Image,ImageDraw,ImageFilter
OUT=Path(__file__).resolve().parent.parent/'src/main/resources/assets/cakeclient/avatars';OUT.mkdir(parents=True,exist_ok=True)
YELLOW=(1,.75,.08);SKIN=(1,.76,.56);BLUE=(.07,.35,.88);WHITE=(.98,.98,.95);BLACK=(.035,.025,.02);WOOD=(.56,.29,.105);RED=(.85,.13,.1)
def unit(v):return v/max(np.linalg.norm(v),1e-12)
class Mesh:
 def __init__(self):self.parts={};self.role=0
 def part(self,role,pivot):self.role=role;self.parts[role]=[pivot,[]]
 def tri(self,p,n,c):
  if np.dot(np.cross(np.array(p[1])-p[0],np.array(p[2])-p[0]),np.mean(n,axis=0))<0:p=p[::-1];n=n[::-1]
  for pos,norm in zip(p,n):
   col=np.array(c)
   if c==WOOD:col=col*(.88+.12*math.sin(pos[1]*24+pos[0]*12)+.04*math.sin(pos[1]*91))
   self.parts[self.role][1].append((*pos,0.,0.,*norm,tuple(np.clip(col*255,0,255).astype(int))))
 def ellipse(self,center,radii,color,seg=24,rings=12):
  center=np.array(center);r=np.array(radii)
  for i in range(rings):
   for j in range(seg):
    pts=[];norm=[]
    for u,v in [(i,j),(i+1,j),(i+1,j+1),(i,j+1)]:
     a=math.pi*u/rings;b=2*math.pi*v/seg;t=np.array([math.sin(a)*math.cos(b),math.cos(a),math.sin(a)*math.sin(b)])
     pts.append(center+t*r);norm.append(unit(t/r))
    for indices in [(0,1,2),(0,2,3)]:self.tri([pts[k] for k in indices],[norm[k] for k in indices],color)
 def rod(self,a,b,r,color,seg=24,r2=None):
  a=np.array(a);b=np.array(b);direction=unit(b-a);u=unit(np.cross(direction,np.array([0.,0.,1.]) if abs(direction[2])<.8 else np.array([1.,0.,0.])));v=np.cross(direction,u);r2=r if r2 is None else r2
  for j in range(seg):
   n1=u*math.cos(j*math.tau/seg)+v*math.sin(j*math.tau/seg);n2=u*math.cos((j+1)*math.tau/seg)+v*math.sin((j+1)*math.tau/seg)
   p=[a+n1*r,b+n1*r2,b+n2*r2,a+n2*r]
   self.tri([p[0],p[1],p[2]],[n1,n1,n2],color);self.tri([p[0],p[2],p[3]],[n1,n2,n2],color)
   self.tri([a,p[3],p[0]],[-direction]*3,color);self.tri([b,p[1],p[2]],[direction]*3,color)
 def box(self,c,size,color):
  c=np.array(c);size=np.array(size)/2;p=np.array([c+size*np.array([x,y,z]) for x,y,z in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]])
  for ids in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:
   n=unit(np.cross(p[ids[1]]-p[ids[0]],p[ids[2]]-p[ids[0]]))
   self.tri([p[ids[k]] for k in [0,1,2]],[n]*3,color);self.tri([p[ids[k]] for k in [0,2,3]],[n]*3,color)
 def fin(self,p,color):
  p=np.array(p,dtype=float);n=unit(np.cross(p[1]-p[0],p[2]-p[0]));self.tri(p,[n]*3,color)
 def arc(self,c,r,start,end,color,tube=.012,seg=24):
  for i in range(seg):
   a=start+(end-start)*i/seg;b=start+(end-start)*(i+1)/seg
   self.rod((c[0]+math.cos(a)*r,c[1]+math.sin(a)*r,c[2]),(c[0]+math.cos(b)*r,c[1]+math.sin(b)*r,c[2]),tube,color,6)
 def save(self,name):
  out=io.BytesIO();out.write(struct.pack('<II',0x314d5641,len(self.parts)))
  for role,(pivot,verts) in self.parts.items():
   out.write(struct.pack('<B3fI',role,*pivot,len(verts)))
   for v in verts:
    c=v[8];argb=0xff000000|(int(c[0])<<16)|(int(c[1])<<8)|int(c[2]);out.write(struct.pack('<8fI',*v[:8],argb))
  atomic(OUT/(name+'.avm'),out.getvalue());print(name,'triangles',sum(len(v[1])//3 for v in self.parts.values()),flush=True)
def atomic(p,b):t=p.with_suffix('.tmp');t.write_bytes(b);os.replace(t,p)
def face(m,y,z,eyeX=.085):
 for x in [-eyeX,eyeX]:
  m.ellipse((x,y,z),(.044,.059,.024),WHITE,16,8);m.ellipse((x,y-.004,z-.022),(.021,.03,.012),BLACK,12,8);m.ellipse((x-.006,y+.009,z-.032),(.006,.009,.006),WHITE,8,6)
 m.ellipse((0,y-.067,z+.004),(.026,.032,.05),SKIN,12,8)
 m.arc((0,y-.092,z-.014),.067,math.pi*1.15,math.pi*1.85,BLACK,.008,12)
def sahur():
 m=Mesh();m.part(0,(0,0,0));m.rod((0,.57,0),(0,1.7,0),.235,WOOD,48,.22)
 for x in [-.10,.10]:
  m.ellipse((x,1.40,-.207),(.087,.107,.047),WHITE,20,10);m.ellipse((x,1.397,-.247),(.038,.052,.017),BLACK,16,8);m.ellipse((x-.01,1.425,-.262),(.012,.018,.009),WHITE,12,6)
  m.rod((x-.055,1.535,-.212),(x+.047,1.548,-.22),.014,BLACK,12)
 m.ellipse((0,1.28,-.237),(.032,.077,.06),WOOD,16,8);m.arc((0,1.23,-.23),.103,math.pi*1.16,math.pi*1.84,BLACK,.012,20)
 for side,role in [(-1,2),(1,3)]:
  x=side*.25;m.part(role,(x,1.16,0));m.rod((x,1.16,0),(side*.37,.78,-.025),.035,WOOD,20);m.ellipse((side*.37,.76,-.025),(.055,.07,.045),WOOD,16,8)
  if side==-1:m.rod((-.40,.74,-.05),(-.64,1.34,-.11),.034,WOOD,24,.065);m.rod((-.397,.73,-.05),(-.37,.66,-.045),.04,(.32,.14,.035),16)
 for side,role in [(-1,4),(1,5)]:
  x=side*.115;m.part(role,(x,.60,0));m.rod((x,.60,0),(x,.14,-.02),.043,WOOD,20);m.ellipse((x,.085,-.075),(.073,.06,.15),WOOD,20,10)
 return m
def shark():
 m=Mesh();m.part(0,(0,0,0));grey=(.27,.44,.54);belly=(.81,.87,.89)
 m.ellipse((0,.96,.05),(.33,.37,.64),grey,32,16);m.ellipse((0,.83,-.04),(.29,.21,.55),belly,28,12);m.ellipse((0,1.02,-.40),(.30,.23,.35),grey,28,14)
 m.ellipse((0,.88,-.61),(.23,.09,.13),BLACK,24,12)
 for i in range(11):
  x=(i-5)*.036;m.fin([(x-.014,.93,-.699),(x+.014,.93,-.699),(x,.882,-.71)],WHITE);m.fin([(x-.014,.83,-.689),(x+.014,.83,-.689),(x,.868,-.70)],WHITE)
 for side in [-1,1]:
  m.ellipse((side*.236,1.14,-.48),(.061,.064,.035),WHITE,16,10);m.ellipse((side*.25,1.14,-.506),(.029,.035,.018),BLACK,12,8)
  for i in range(3):m.rod((side*(.318-i*.004),.95,.00+i*.07),(side*.305,.80,.02+i*.07),.008,(.11,.24,.29),8)
  m.fin([(side*.2,.93,.01),(side*.64,.77,.13),(side*.25,.78,.37)],grey)
 m.fin([(0,1.20,.05),(0,1.61,.22),(0,1.18,.46)],grey)
 m.rod((0,.98,.53),(0,.96,.83),.115,grey,20,.055);m.fin([(0,.96,.77),(-.31,1.19,1.04),(0,.95,.92)],grey);m.fin([(0,.96,.77),(.31,.75,1.04),(0,.95,.92)],grey)
 for side,role,z in [(-1,4,-.17),(1,5,-.17),(0,6,.39)]:
  x=side*.23;m.part(role,(x,.72,z));m.rod((x,.72,z),(x,.25,z),.047,grey,16);m.ellipse((x,.15,z-.09),(.13,.12,.24),BLUE,24,12);m.ellipse((x,.055,z-.09),(.13,.03,.235),WHITE,24,10)
  for i in range(3):m.rod((x-.06,.255-i*.015,z-.18+i*.065),(x+.06,.255-i*.015,z-.18+i*.065),.007,WHITE,8)
 return m
def caillou():
 m=Mesh();m.part(0,(0,0,0));m.ellipse((0,.97,0),(.235,.33,.145),YELLOW,24,14);m.rod((0,1.21,0),(0,1.36,0),.075,SKIN,20);m.arc((0,1.28,-.13),.085,math.pi,math.tau,RED,.012,20)
 for y in [1.10,1.01]:m.ellipse((0,y,-.146),(.013,.013,.009),RED,10,6)
 m.part(1,(0,1.34,0));m.ellipse((0,1.58,-.005),(.215,.245,.205),SKIN,32,20);face(m,1.60,-.198,.074)
 for side in [-1,1]:m.ellipse((side*.21,1.55,0),(.038,.058,.031),SKIN,16,8)
 for side,role in [(-1,2),(1,3)]:
  x=side*.23;m.part(role,(x,1.17,0));m.rod((x,1.17,0),(side*.30,.94,0),.067,YELLOW,20,.06);m.rod((side*.30,.95,0),(side*.30,.75,-.02),.045,SKIN,20);m.ellipse((side*.30,.72,-.03),(.055,.065,.038),SKIN,16,10)
 for side,role in [(-1,4),(1,5)]:
  x=side*.105;m.part(role,(x,.79,0));m.rod((x,.79,0),(x,.20,0),.079,BLUE,20);m.ellipse((x,.12,-.08),(.095,.09,.18),RED,24,12);m.ellipse((x,.052,-.08),(.096,.025,.17),WHITE,24,10)
 return m
def lego():
 m=Mesh();m.part(0,(0,0,0));red=(.84,.12,.11)
 # Tapered toy torso, not a Minecraft skin cube.
 m.rod((0,1.15,0),(0,1.26,0),.068,YELLOW,24)
 m.box((0,.99,0),(.43,.40,.24),red);m.box((0,.76,0),(.38,.08,.22),BLUE)
 m.part(1,(0,1.25,0));m.rod((0,1.29,0),(0,1.65,0),.185,YELLOW,48);m.rod((0,1.65,0),(0,1.72,0),.09,YELLOW,32)
 for x in [-.064,.064]:m.ellipse((x,1.49,-.173),(.022,.031,.011),BLACK,16,8)
 m.arc((0,1.43,-.182),.065,math.pi*1.12,math.pi*1.88,BLACK,.01,20)
 for side,role in [(-1,2),(1,3)]:
  x=side*.245;m.part(role,(x,1.14,0));m.rod((x,1.14,0),(side*.30,.86,-.01),.075,red,24);m.rod((side*.30,.87,-.01),(side*.30,.78,-.01),.05,YELLOW,20);m.arc((side*.30,.73,-.01),.047,math.pi*-.2,math.pi*1.2,YELLOW,.019,20)
 for side,role in [(-1,4),(1,5)]:
  x=side*.11;m.part(role,(x,.73,0));m.rod((x,.70,0),(x,.60,0),.091,BLUE,24);m.box((x,.365,.005),(.19,.51,.21),BLUE);m.box((x,.095,-.045),(.19,.14,.31),BLUE)
 return m
# A simple depth-tested rasterizer previews the exact exported triangles.
def preview(mesh,index):
 size=720;im=np.zeros((size,size,3),dtype=float);yy,xx=np.mgrid[:size,:size];rad=((xx-size*.5)**2+(yy-size*.5)**2)/(size*size);im[:]=np.stack([.11-.04*rad,.09-.035*rad,.17-.045*rad],axis=2);depth=np.full((size,size),np.inf)
 yaw=-.55;pitch=.10;R=np.array([[math.cos(yaw),0,math.sin(yaw)],[0,1,0],[-math.sin(yaw),0,math.cos(yaw)]]);Rx=np.array([[1,0,0],[0,math.cos(pitch),-math.sin(pitch)],[0,math.sin(pitch),math.cos(pitch)]]);R=Rx@R;light=unit(np.array([-.5,.8,-.8]))
 for pivot,verts in mesh.parts.values():
  for a in range(0,len(verts),3):
   tri=verts[a:a+3];points=np.array([v[:3] for v in tri]);rot=(R@(points-np.array([0,.91,0])).T).T;uv=rot[:,:2]*330;uv[:,1]*=-1;uv+=np.array([size/2,size/2]);z=rot[:,2]
   xmin=max(0,int(uv[:,0].min()));xmax=min(size-1,int(uv[:,0].max())+1);ymin=max(0,int(uv[:,1].min()));ymax=min(size-1,int(uv[:,1].max())+1)
   if xmin>=xmax or ymin>=ymax:continue
   x,y=np.meshgrid(np.arange(xmin,xmax+1)+.5,np.arange(ymin,ymax+1)+.5);u=uv
   den=(u[1,1]-u[2,1])*(u[0,0]-u[2,0])+(u[2,0]-u[1,0])*(u[0,1]-u[2,1])
   if abs(den)<1e-9:continue
   w0=((u[1,1]-u[2,1])*(x-u[2,0])+(u[2,0]-u[1,0])*(y-u[2,1]))/den;w1=((u[2,1]-u[0,1])*(x-u[2,0])+(u[0,0]-u[2,0])*(y-u[2,1]))/den;w2=1-w0-w1;zz=w0*z[0]+w1*z[1]+w2*z[2];d=depth[ymin:ymax+1,xmin:xmax+1];mask=(w0>=0)&(w1>=0)&(w2>=0)&(zz<d-1e-6)
   if not mask.any():continue
   n=np.array([v[5:8] for v in tri]);norm=w0[...,None]*n[0]+w1[...,None]*n[1]+w2[...,None]*n[2];shade=.45+.55*np.maximum(0,np.sum(norm*light,axis=2));col=np.array([v[8] for v in tri])/255.;rgb=(w0[...,None]*col[0]+w1[...,None]*col[1]+w2[...,None]*col[2])*shade[...,None];im[ymin:ymax+1,xmin:xmax+1][mask]=rgb[mask];d[mask]=zz[mask]
 image=Image.fromarray(np.clip(im*255,0,255).astype('uint8')).resize((1080,1080),Image.Resampling.LANCZOS);out=io.BytesIO();image.save(out,format='PNG');atomic(OUT/f'preview-{index}.png',out.getvalue())
for index,(name,make) in enumerate([('sahur',sahur),('tralalero',shark),('caillou',caillou),('lego',lego)]):
 mesh=make();mesh.save(name);preview(mesh,index)
