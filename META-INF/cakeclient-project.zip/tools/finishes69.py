from pathlib import Path
import numpy as np
from PIL import Image
root=Path('project/src/main/resources/assets/cakeclient/knives');out=root/'finishes';out.mkdir(exist_ok=True)
y,x=np.mgrid[0:512,0:512]/512
noise=(np.sin(x*31+np.sin(y*19))*np.sin(y*29+x*8)+1)/2
vein=(np.sin(x*85+y*32+noise*10)+1)/2
names=['Factory','Amethyst Marble','Blackout','Solar Fade','Damascus','Carbon Weave','Crimson Web','Aurora','Porcelain','Circuit','Obsidian Gold','Ice Fracture','Bronze Patina','Ember']
for p in root.glob('*-color.png'):
 src=Image.open(p).convert('RGB').resize((512,512),Image.Resampling.LANCZOS);a=np.asarray(src)/255
 surface=root/(p.name.replace('-color','-surface'));orm=np.asarray(Image.open(surface).convert('RGB').resize((512,512)))/255
 mask=np.clip(orm[:,:,1]*1.6-.25,0,1)[:,:,None];detail=.7+.3*np.mean(a,axis=2)[:,:,None]
 for i in range(1,14):
  if i==1:c=np.stack([.35+.45*vein,.08+.12*vein,.5+.45*vein],-1)
  elif i==2:c=np.ones_like(a)*[.055,.065,.085]*(.65+.35*noise[:,:,None])
  elif i==3:c=np.stack([.98-.4*y,.25+.65*y,.10+.65*(1-y)],-1)
  elif i==4:
   q=(np.sin((x+noise*.08)*180+y*70)+1)/2;c=np.repeat((.2+q*.65)[:,:,None],3,2)
  elif i==5:
   q=((np.floor(x*90)+np.floor(y*90))%2);c=np.repeat((.07+.12*q)[:,:,None],3,2)*( .8+.2*np.sin(x*600)[:,:,None])
  elif i==6:
   a0=np.arctan2(y-.5,x-.5);r=np.hypot(x-.5,y-.5);web=(np.abs(np.sin(a0*9))<.045)|(np.abs(np.sin(r*130))<.09);c=np.empty_like(a);c[:]=[.55,.012,.03];c[web]=[.04,.015,.02]
  elif i==7:c=np.stack([.1+.3*noise,.5+.45*np.sin(x*6+y*5)**2,.65+.3*noise],-1)
  elif i==8:c=np.ones_like(a)*[.88,.89,.92];c[vein>.98]=[.12,.3,.58]
  elif i==9:
   circuit=(np.mod(x*28,1)<.06)|(np.mod(y*28+np.floor(x*28)%3*.2,1)<.04);c=np.empty_like(a);c[:]=[.025,.04,.055];c[circuit]=[.1,.85,.6]
  elif i==10:c=np.empty_like(a);c[:]=[.025,.02,.05];c[vein>.95]=[.95,.66,.17]
  elif i==11:c=np.stack([.3+.5*vein,.62+.33*vein,.8+.2*vein],-1)
  elif i==12:c=np.stack([.35+.25*noise,.25+.2*vein,.10+.25*noise],-1)
  else:c=np.stack([.12+.88*vein**8,.025+.4*vein**10,.012+.03*vein],-1)
  result=a*(1-mask)+np.clip(c*detail,0,1)*mask;Image.fromarray((np.clip(result,0,1)*255).astype('uint8')).save(out/(p.stem.replace('-color','')+'-'+str(i)+'.png'))
 print(p.stem,flush=True)
(out/'CREDITS.txt').write_text('13 original Cake material designs, baked over the original CS factory albedo with a metallic surface mask. These are not official Valve skins. Original Valve asset credits: CS_ASSETS_NOTICE.txt.\n')
