"""Import actual LDraw minifigure CAD parts; preserve library authorship and licenses."""
from pathlib import Path
import numpy as np,json,urllib.request,struct,io,os,importlib.util
from PIL import Image
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent/'src/main/resources/assets/cakeclient/avatars';SRC=ROOT/'ldraw';SRC.mkdir(exist_ok=True)
TREE=json.load(open('/tmp/ldraw68tree.json'));SHA=TREE['sha'];paths={x['path'].lower():x['path']for x in TREE['tree']};BASE='complete/ldraw/';cache={};used=set()
def get(name):
 name=name.replace('\\','/').lower();candidates=[BASE+'parts/'+name,BASE+'p/'+name]
 key=next((paths[x.lower()]for x in candidates if x.lower()in paths),None)
 if key is None:raise ValueError(name)
 target=SRC/key.removeprefix(BASE);used.add(key)
 if not target.exists():target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(urllib.request.urlopen('https://raw.githubusercontent.com/gkjohnson/ldraw-parts-library/'+SHA+'/'+key,timeout=30).read())
 return target.read_text(errors='replace')
def parse(name,color=14,depth=0):
 assert depth<30
 key=(name,color)
 if key in cache:return cache[key].copy()
 triangles=[]
 for line in get(name).splitlines():
  a=line.split()
  if not a or a[0]not in ['1','3','4']:continue
  c=int(a[1]);c=color if c==16 else c
  if a[0]=='1':
   t=np.array(list(map(float,a[2:5])));M=np.array(list(map(float,a[5:14]))).reshape(3,3);part=parse(' '.join(a[14:]),c,depth+1);part[:,:,:3]=part[:,:,:3]@M.T+t;triangles.extend(part)
  else:
   p=np.array(list(map(float,a[2:]))).reshape(-1,3)
   for ids in [[0,1,2]]if len(p)==3 else[[0,1,2],[0,2,3]]:
    tri=np.column_stack([p[ids],np.full(3,c)]);triangles.append(tri)
 result=np.array(triangles,float).reshape(-1,3,4);cache[key]=result.copy();return result
if __name__=='__main__':
 parts=[]
 for name,color,y in [('973c01.dat',4,0),('970c00.dat',1,32),('3626bp01.dat',14,-24)]:
  part=parse(name,color);print(name,len(part),'bounds',part[:,:,:3].min((0,1)),part[:,:,:3].max((0,1)),flush=True);part[:,:,1]+=y;parts.extend(part)
 tri=np.array(parts);pos=tri[:,:,:3].reshape(-1,3);pos[:,1]*=-1;low=pos.min(0);high=pos.max(0);pos-=np.array([(low[0]+high[0])/2,low[1],(low[2]+high[2])/2]);pos*=1.8/(high[1]-low[1]);p=pos.reshape(-1,3,3);norm=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);norm/=np.maximum(np.linalg.norm(norm,axis=1,keepdims=True),1e-9);norm=np.repeat(norm,3,0);codes=tri[:,:,3].reshape(-1).astype(int);colors={0:(5,5,7),1:(0,66,150),4:(195,28,30),14:(250,205,45),15:(248,248,245),16:(195,28,30),71:(160,165,169)};palette=np.zeros((32,32,4),np.uint8);palette[:,:,3]=255
 for code,rgb in colors.items():palette[code//32,code%32,:3]=rgb
 uv=np.column_stack([(codes%32+.5)/32,(codes//32+.5)/32]);im=Image.fromarray(palette).resize((512,512),Image.Resampling.NEAREST);buf=io.BytesIO();im.save(buf,format='PNG');(OUT/'lego-atlas.png').write_bytes(buf.getvalue())
 n=len(pos);data=np.column_stack([pos,norm,uv,np.ones(n),np.zeros((n,3))]).astype('<f4');b=io.BytesIO();b.write(struct.pack('<5I',0x324d5641,n,n,1,2));b.write(data.tobytes());b.write(np.zeros((n,4),'<u2').tobytes());b.write(np.arange(n,dtype='<u4').tobytes())
 for _ in range(2):b.write(struct.pack('<fI',1,2));b.write(np.tile(np.eye(4),(2,1,1)).astype('<f4').tobytes())
 (OUT/'lego.avm').write_bytes(b.getvalue());spec=importlib.util.spec_from_file_location('preview',ROOT/'import-avatars.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.render_preview(pos,np.arange(n),uv,OUT/'lego-atlas.png',OUT/'preview-22.png')
 credits='This software uses the LDraw Parts Library — https://www.ldraw.org/\nImported minifigure parts, not generated approximations. CCAL 2.0; original per-part headers retained.\nChanges: assembled, triangulated, scaled and converted to AVM2.\nMirror: https://github.com/gkjohnson/ldraw-parts-library/tree/'+SHA+'\nLEGO is a trademark of the LEGO Group; no affiliation.\n';(OUT/'lego-CREDITS.txt').write_text(credits);(SRC/'provenance.json').write_text(json.dumps({'commit':SHA,'files':sorted(used),'credit':credits},indent=2));j=json.loads((OUT/'catalog.json').read_text());j=[x for x in j if x['id']!='lego'];j.append({'id':'lego','name':'Lego · LDraw','vertices':n,'triangles':n//3,'joints':1,'clips':['Static','Static'],'author':'LDraw Parts Library','source':'https://www.ldraw.org/','license':'CCAL-2.0'});(OUT/'catalog.json').write_text(json.dumps(j,indent=2));print('LEGO READY',n,'vertices',flush=True)
