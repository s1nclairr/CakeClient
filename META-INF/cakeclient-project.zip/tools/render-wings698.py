import pathlib,struct,numpy as np,moderngl
from PIL import Image
R=pathlib.Path('project/src/main/resources/assets/cakeclient');B=R/'back';H=B/'hd';ctx=moderngl.create_standalone_context(backend='egl');size=(1600,900);f=ctx.simple_framebuffer(size,components=4);f.use();ctx.enable(moderngl.DEPTH_TEST)
p=ctx.program(vertex_shader='''#version 330
in vec3 p;in vec3 n;in vec2 uv;out vec3 N;out vec2 UV;uniform mat4 M;void main(){gl_Position=M*vec4(p,1);N=n;UV=uv;}''',fragment_shader='''#version 330
in vec3 N;in vec2 UV;uniform sampler2D T;uniform vec3 Tint;out vec4 c;void main(){vec4 t=texture(T,UV);if(t.a<.28)discard;float l=.6+.3*abs(dot(normalize(N),normalize(vec3(.2,-.6,1))));c=vec4(t.rgb*Tint*l,t.a);}''');p['T']=0
M=np.diag([.43,-.78,-.15,1]).astype('f4');M[1,3]=.05;p['M'].write(M.T.tobytes())
def draw(a,idx,tex,tint):
 p['Tint'].value=tint;im=Image.open(tex).convert('RGBA');t=ctx.texture(im.size,4,im.tobytes());t.build_mipmaps();t.filter=(moderngl.LINEAR_MIPMAP_LINEAR,moderngl.LINEAR);t.use(0);v=ctx.buffer(np.asarray(a,'f4').tobytes());i=ctx.buffer(np.asarray(idx,'u4').tobytes());vao=ctx.vertex_array(p,[(v,'3f 3f 2f','p','n','uv')],index_buffer=i);vao.render(moderngl.TRIANGLES);vao.release();v.release();i.release();t.release()
def output(style):
 im=Image.frombytes('RGBA',size,f.read(components=4)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).resize((1024,576),Image.Resampling.LANCZOS);im.save(B/f'preview-{style}.png')
b=(H/'angel.cwd').read_bytes()
for style,tint in [(0,(1,1,1)),(3,(.28,.25,.42)),(4,(1,.8,.5))]:
 f.clear(0,0,0,0);off=8
 for _ in range(4):
  side,mat,n,ni=struct.unpack_from('<4I',b,off);off+=16;a=np.frombuffer(b,'<f4',n*8,off).copy().reshape(-1,8);off+=n*32;idx=np.frombuffer(b,'<u4',ni,off);off+=ni*4;sign=1 if side==0 else -1
  pos=np.column_stack([a[:,0]*sign*.95,-a[:,2]*.95,a[:,1]*.95]);norm=np.column_stack([a[:,3]*sign,-a[:,5],a[:,4]]);ang=sign*.5;c,s=np.cos(ang),np.sin(ang);z=np.array([[c,-s,0],[s,c,0],[0,0,1]]);pos=pos@z.T;norm=norm@z.T;pos+=np.array([sign*.17,.05,.16]);pos*=.825;pos[:,1]+=.14;pos[:,0]*=-1
  a[:,:3]=pos;a[:,3:6]=norm;draw(a,idx,H/('feather.png' if mat==0 else 'wing.png'),tint)
 output(style)
for style,name in [(1,'dragon'),(2,'dragon_evolved'),(5,'alpaking')]:
 f.clear(0,0,0,0);b=(H/(name+'.avm')).read_bytes();magic,n,ni,nb,nc=struct.unpack_from('<5I',b);off=20;d=np.frombuffer(b,'<f4',n*12,off).reshape(n,12);off+=n*48;j=np.frombuffer(b,'<u2',n*4,off).reshape(n,4);off+=n*8;idx=np.frombuffer(b,'<u4',ni,off);off+=ni*4;dur,frames=struct.unpack_from('<fI',b,off);off+=8;mat=np.frombuffer(b,'<f4',nb*16,off).reshape(nb,4,4).transpose(0,2,1);pv=np.column_stack([d[:,:3],np.ones(n)]);pos=sum(np.einsum('nij,nj->ni',mat[j[:,k]],pv)*d[:,8+k,None] for k in range(4))[:,:3];norm=sum(np.einsum('nij,nj->ni',mat[j[:,k],:3,:3],d[:,3:6])*d[:,8+k,None] for k in range(4));c,s=np.cos(-.6),np.sin(-.6);rot=np.array([[1,0,0],[0,c,-s],[0,s,c]]);pos=pos@rot.T;norm=norm@rot.T;pos[:,1]*=-1;norm[:,1]*=-1;pos+=np.array([0,.15,.17]);pos*=.825;pos[:,1]+=.14;a=np.column_stack([pos,norm,d[:,6:8]]);draw(a,idx,R/'avatars/atlas.png',(1,1,1));output(style)
print('Rendered six genuine wing model previews')
