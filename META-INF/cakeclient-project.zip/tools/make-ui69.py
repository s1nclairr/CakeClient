from pathlib import Path
p=Path('project/src/main/java/fr/cake/client/UiCanvas.java');s=p.read_text();s=s.replace('"Pack Customizer"};','"Pack Customizer","Wings & Capes","Realistic Mode","Crosshair","Combat Effects","Knife Materials"};');s=s.replace('{{0,2,7,8,9,13,14},{3,4,1,18},{5,16},{6,10,11,12,15,17,19}}','{{0,2,7,8,9,13,14,21,22,23},{3,4,1,18},{5,16},{6,24,20,10,11,12,15,17,19}}');s=s.replace('visible.length>5?72:88','visible.length>8?65:visible.length>5?72:88');s=s.replace('  label("PERSONNALISEZ"','  if(visible.length<8)label("PERSONNALISEZ"').replace('label("votre atmosphère.",47,782,22,TEXT,false);','if(visible.length<8)label("votre atmosphère.",47,782,22,TEXT,false);');s=s.replace('sub[tab]','(tab<sub.length?sub[tab]:"Premium visual studio · configure your experience")');s=s.replace('case 19->packCustomizer();','case 19->packCustomizer();case 20->backs();case 21->realism();case 22->crosshairs();case 23->combat();case 24->materials();');s=s.replace('  button(1320,995,225,48,','  button(915,995,380,48,"Language · "+s().language.toUpperCase(),()->s().language=s().language.equals("en")?"fr":s().language.equals("fr")?"ru":"en",false);\n  button(1320,995,225,48,');s=s.replace('private void label(String text,double x,double y,float size,Color color,boolean bold){','private void label(String text,double x,double y,float size,Color color,boolean bold){text=I18n.tr(text);');s=s.replace('private void button(double x,double y,double w,double h,String text,Runnable action,boolean primary){','private void button(double x,double y,double w,double h,String text,Runnable action,boolean primary){text=I18n.tr(text);');s=s.replace('private void wrap(String text,double x,double y,double w,float size,Color color){','private void wrap(String text,double x,double y,double w,float size,Color color){text=I18n.tr(text);');s=s.replace('private void right(String text,double x,double y,float size,Color color){','private void right(String text,double x,double y,float size,Color color){text=I18n.tr(text);');s=s.replace('private void choice(double x,double y,double w,double h,String text,Runnable action,boolean primary,boolean allowed){','private void choice(double x,double y,double w,double h,String text,Runnable action,boolean primary,boolean allowed){text=I18n.tr(text);');idx=s.index(' private void option(')
new=''' private void backs(){
 card(350,282,1524,635);option(390,340,"Back cosmetic",s().backEnabled,()->s().backEnabled=!s().backEnabled);
 for(int i=0;i<BackCosmetics.NAMES.length;i++){final int n=i;button(390+i%3*475,390+i/3*65,450,52,BackCosmetics.NAMES[i],()->s().backStyle=n,s().backStyle==i);}
 rowSlider("Scale",390,780,650,s().backScale,pct(s().backScale),v->s().backScale=v);rowSlider("Animation speed",1110,780,650,s().backSpeed,pct(s().backSpeed),v->s().backSpeed=v);
 label("Wings · Paul Fulham / MIT · 10 imported styles, 2 source meshes",390,895,20,MUTED,false);
 }
 private void realism(){
 card(350,282,1524,635);option(390,340,"Realistic rendering",s().realistic,()->s().realistic=!s().realistic);
 for(int i=0;i<3;i++){final int n=i;button(390+i*475,420,450,65,new String[]{"Balanced","High","Ultra"}[i],()->{s().realismQuality=n;RealisticMode.refresh();},s().realismQuality==i);}
 wrap("Realis lighting, animated water, wet surfaces and rain reflections. XsRealism 256x photographic textures. Requires more GPU power. Reflections depend on what the camera can see.",390,565,1370,27,TEXT);
 wrap(RealisticMode.status,390,790,1360,23,PURPLE);
 }
 private void crosshairs(){
 card(350,282,1524,635);option(390,340,"Custom crosshair",s().crosshairEnabled,()->s().crosshairEnabled=!s().crosshairEnabled);
 for(int i=0;i<8;i++){final int n=i;button(390+i%4*350,400+i/4*65,330,52,CrosshairHud.NAMES[i],()->s().crosshairStyle=n,s().crosshairStyle==i);}
 rowSlider("Size",390,600,640,s().crosshairSize,pct(s().crosshairSize),v->s().crosshairSize=v);rowSlider("Gap",1110,600,640,s().crosshairGap,pct(s().crosshairGap),v->s().crosshairGap=v);rowSlider("Thickness",390,750,640,s().crosshairThickness,pct(s().crosshairThickness),v->s().crosshairThickness=v);hue(1110,800,640,s().crosshairHue,v->s().crosshairHue=v);
 }
 private void combat(){
 card(350,282,1524,635);option(390,340,"Hit color",s().hitColor,()->s().hitColor=!s().hitColor);hue(1110,315,640,s().hitColorHue,v->s().hitColorHue=v);rowSlider("Tint strength",390,425,640,s().hitColorStrength,pct(s().hitColorStrength),v->s().hitColorStrength=v);
 option(390,620,"Death effects",s().deathEffects,()->s().deathEffects=!s().deathEffects);
 for(int i=0;i<5;i++){final int n=i;button(390+i%3*475,680+i/3*78,450,62,CombatEffects.NAMES[i],()->s().deathStyle=n,s().deathStyle==i);}
 }
 private void materials(){
 card(350,282,1524,635);
 for(int i=0;i<KnifeFinishes.NAMES.length;i++){final int n=i;button(390+i%4*350,320+i/4*72,330,58,KnifeFinishes.NAMES[i],()->s().knifeFinish=n,s().knifeFinish==i);}
 option(390,680,"Blade trails",s().knifeTrails,()->s().knifeTrails=!s().knifeTrails);hue(1110,660,640,s().knifeTrailHue,v->s().knifeTrailHue=v);rowSlider("Trail lifetime",390,790,640,s().knifeTrailLife,pct(s().knifeTrailLife),v->s().knifeTrailLife=v);
 wrap("Factory uses the original CS asset. The other materials are original Cake designs, available on every knife.",1110,780,640,22,MUTED);
 }
'''
s=s[:idx]+new+s[idx:];p.write_text(s)
# link the old knife finish controls to the full materials page
s=p.read_text();start=s.find('private void knives()');end=s.find('\n private void ',start+10);print(s[start:end][:5000]);
