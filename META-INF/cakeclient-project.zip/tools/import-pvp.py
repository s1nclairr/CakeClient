"""Package independent public resource-pack designs, keeping models, animation metadata and credits."""
from pathlib import Path
import json,zipfile,io,hashlib,os,shutil,struct
from PIL import Image
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'imported-packs';OUT=ROOT.parent/'src/main/resources/assets/cakeclient/pvp'
FILES=[['entity/end_crystal/end_crystal.png'],['item/mace.png'],['item/totem_of_undying.png'],['block/obsidian.png'],['block/respawn_anchor_'+x+'.png' for x in ['top','bottom','side0','side1','side2','side3','side4']]]
CAT=[(9,'void-crystal',[0,2]),(10,'crystalcore',[0,2,3]),(11,'pvp-texture-pack',[0,1]),(12,'smoother-end-crystals',[0]),(13,'mace_to_windhammer',[1]),(14,'mace-to-greataxe',[1]),(15,'mjlnir-mace',[1]),(16,'windswept-mace',[1]),(17,'real-mace',[1]),(18,'mace-pvp-essence',[1]),(19,'furry-fox-totem',[2]),(20,'majorzweys-better-obsidian',[3]),(21,'simple-bedrock-and-obsidian',[3]),(22,'hopeobsidianoverlay',[3]),(23,'anchor-indicator',[4]),(24,'respawn-anchor-indicator',[4])]
AUTHORS=json.loads((SRC/'authors.json').read_text()) if (SRC/'authors.json').exists() else {}
def clean_png(b):
 # Preserve exact pixels; discard malformed ICC/EXIF metadata found in upstream files.
 if not b.startswith(b'\x89PNG'):return b
 pos=8;parts=[b[:8]]
 while pos<len(b):
  n=struct.unpack_from('>I',b,pos)[0];kind=b[pos+4:pos+8]
  if kind in [b'IHDR',b'PLTE',b'tRNS',b'IDAT',b'IEND']:parts.append(b[pos:pos+n+12])
  pos+=n+12
 result=b''.join(parts);Image.open(io.BytesIO(result)).load();return result
choices=[{'id':0,'name':'Texture actuelle','items':[0,1,2,3,4],'author':'Minecraft / pack actif','license':'','source':''}]
for v,name in enumerate(['Faithful 32x','Faithful 64x','Cake Violet · Faithful','Cake Rouge · Faithful','Cake Azur · Faithful','Cake Menthe · Faithful','Cake Or · Faithful','Cake Rose · Faithful'],1):
 entries={}
 for group in FILES:
  for path in group:entries['assets/minecraft/textures/'+path]=(OUT/str(v)/path.replace('/','_')).read_bytes()
 with zipfile.ZipFile(OUT/(str(v)+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
  for path,b in entries.items():z.writestr(path,b)
 choices.append({'id':v,'name':name,'items':[0,1,2,3,4],'author':'Faithful / Cake','license':'Faithful License v4','source':'https://faithfulpack.net/'})
for v,slug,items in CAT:
 meta=json.loads((SRC/(slug+'.json')).read_text());p=meta['project'];z=zipfile.ZipFile(SRC/(slug+'.zip'));entries={}
 for name in z.namelist():
  if name.startswith('assets/') and not name.endswith('/') and not name.endswith('desktop.ini') and '/lang/' not in name:entries[name]=clean_png(z.read(name)) if name.endswith('.png') else z.read(name)
 if slug=='mjlnir-mace':entries['assets/minecraft/models/item/mace.json']=entries.pop('assets/minecraft/models/item/handheld_mace.json')
 # Entry isolation: do not replace another category's resources merely by selecting this one.
 for item in items:
  selected={}
  if item==1:
   selected={k:b for k,b in entries.items() if (k.endswith('/models/item/mace.json') or '/models/item/mace_'in k or k.endswith('/items/mace.json') or '/textures/item/'in k and 'totem'not in k and 'end_crystal'not in k)}
  elif item==4:selected={k:b for k,b in entries.items() if 'respawn_anchor'in k}
  else:
   for k,b in entries.items():
    if any(k=='assets/minecraft/textures/'+f or k=='assets/minecraft/textures/'+f+'.mcmeta' for f in FILES[item]):selected[k]=b
   if item==0:
    for k,b in entries.items():
     if k.endswith('/item/end_crystal.png') or k.endswith('/item/end_crystal.png.mcmeta'):selected[k]=b
  assert selected,(slug,item)
  credits=f"{p['title']} by {AUTHORS.get(meta['version']['author_id'],meta['version']['author_id'])}\nhttps://modrinth.com/resourcepack/{slug}\nLicense: {p['license']['id']} {p['license'].get('url','')}\nVersion {meta['version']['id']}\nOriginal resources; not palette variants.\n";selected['CREDITS-'+slug+'.txt']=credits.encode()
  for name in z.namelist():
   if any(k in name.lower() for k in ['license','copying','notice']) and not name.endswith('/'):selected['licenses/'+slug+'/'+Path(name).name]=z.read(name)
  license_id=p['license']['id'];lp=SRC/('LICENSE-'+license_id+'.txt')
  if lp.exists():selected['licenses/'+slug+'/LICENSE.txt']=lp.read_bytes()
  with zipfile.ZipFile(OUT/f'{v}-{item}.zip','w',zipfile.ZIP_DEFLATED) as zz:
   for k,b in selected.items():zz.writestr(k,b)
 choices.append({'id':v,'name':p['title'],'items':items,'author':AUTHORS.get(meta['version']['author_id'],meta['version']['author_id']),'license':p['license']['id'],'source':'https://modrinth.com/resourcepack/'+slug})
(OUT/'catalog.json').write_text(json.dumps(choices,ensure_ascii=False,indent=2));print('choices',len(choices),'per item',[sum(i in x['items'] for x in choices) for i in range(5)])
