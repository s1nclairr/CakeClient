#version 130
#define OVERWORLD
#define FSH
#define MISC_DISCARD
#include "/program/gbuffers_misc.glsl"
