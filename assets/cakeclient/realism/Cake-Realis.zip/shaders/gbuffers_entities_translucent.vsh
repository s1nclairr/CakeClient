#version 130
#define OVERWORLD
#define VSH
#define PROGRAM_ENTITIES_TRANSLUCENT
#include "/program/gbuffers_translucent.glsl"
