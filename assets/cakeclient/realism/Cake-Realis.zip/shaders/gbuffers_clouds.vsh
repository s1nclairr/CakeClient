#version 130
#define OVERWORLD
#define VSH
#define MISC_DISCARD
#include "/program/gbuffers_misc.glsl"
