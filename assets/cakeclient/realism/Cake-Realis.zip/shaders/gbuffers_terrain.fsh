#version 130
#define OVERWORLD
#define FSH
#define PROGRAM_TERRAIN
#include "/program/gbuffers_solid.glsl"
