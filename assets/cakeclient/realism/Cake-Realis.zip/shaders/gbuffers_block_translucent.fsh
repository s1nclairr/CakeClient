#version 130
#define OVERWORLD
#define FSH
#define PROGRAM_BLOCK_TRANSLUCENT
#include "/program/gbuffers_translucent.glsl"
