#version 130
#define OVERWORLD
#define FSH
#include "/program/gbuffers_damage.glsl"
