#version 130
#define OVERWORLD
#define VSH
#define PROGRAM_BASIC
#define PROGRAM_LINE
#include "/program/gbuffers_overlay.glsl"
