#version 130
#define END
#define VSH
#include "/program/gbuffers_damage.glsl"
