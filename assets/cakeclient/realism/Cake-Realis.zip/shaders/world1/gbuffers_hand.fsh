#version 130
#define END
#define FSH
#define PROGRAM_HAND
#include "/program/gbuffers_solid.glsl"
