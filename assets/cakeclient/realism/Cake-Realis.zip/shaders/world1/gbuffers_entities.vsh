#version 130
#define END
#define VSH
#define PROGRAM_ENTITIES
#include "/program/gbuffers_solid.glsl"
