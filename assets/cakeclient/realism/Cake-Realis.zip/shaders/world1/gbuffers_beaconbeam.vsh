#version 130
#define END
#define VSH
#define OVERLAY_EMISSIVE
#include "/program/gbuffers_overlay.glsl"
