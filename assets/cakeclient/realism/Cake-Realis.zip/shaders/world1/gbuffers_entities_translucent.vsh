#version 130
#define END
#define VSH
#define PROGRAM_ENTITIES_TRANSLUCENT
#include "/program/gbuffers_translucent.glsl"
