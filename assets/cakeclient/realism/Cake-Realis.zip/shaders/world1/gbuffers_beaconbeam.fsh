#version 130
#define END
#define FSH
#define OVERLAY_EMISSIVE
#include "/program/gbuffers_overlay.glsl"
