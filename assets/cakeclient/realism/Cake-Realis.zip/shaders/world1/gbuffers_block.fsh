#version 130
#define END
#define FSH
#define PROGRAM_BLOCK
#include "/program/gbuffers_solid.glsl"
