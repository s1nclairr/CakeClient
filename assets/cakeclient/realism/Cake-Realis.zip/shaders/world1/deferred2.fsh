#version 130
#define END
#define FSH
#include "/program/deferred_lighting.glsl"
