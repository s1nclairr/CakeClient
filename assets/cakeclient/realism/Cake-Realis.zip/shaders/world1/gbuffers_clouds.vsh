#version 130
#define END
#define VSH
#define MISC_DISCARD
#include "/program/gbuffers_misc.glsl"
