#version 130
#define END
#define FSH
#define PROGRAM_ENTITIES
#include "/program/gbuffers_solid.glsl"
