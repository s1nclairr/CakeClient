#version 130
#define END
#define FSH
#define PROGRAM_TERRAIN
#include "/program/gbuffers_solid.glsl"
