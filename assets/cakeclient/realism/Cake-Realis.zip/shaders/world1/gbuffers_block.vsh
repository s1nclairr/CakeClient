#version 130
#define END
#define VSH
#define PROGRAM_BLOCK
#include "/program/gbuffers_solid.glsl"
