#version 130
#define END
#define FSH
#define MISC_DISCARD
#include "/program/gbuffers_misc.glsl"
