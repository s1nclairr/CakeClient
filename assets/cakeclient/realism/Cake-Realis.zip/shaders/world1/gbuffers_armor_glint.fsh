#version 130
#define END
#define FSH
#define MISC_GLINT
#include "/program/gbuffers_misc.glsl"
