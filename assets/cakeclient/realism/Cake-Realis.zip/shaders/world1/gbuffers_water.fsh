#version 130
#define END
#define FSH
#define PROGRAM_WATER
#include "/program/gbuffers_translucent.glsl"
