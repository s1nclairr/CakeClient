#version 130
#define END
#define FSH
#define PROGRAM_BLOCK_TRANSLUCENT
#include "/program/gbuffers_translucent.glsl"
