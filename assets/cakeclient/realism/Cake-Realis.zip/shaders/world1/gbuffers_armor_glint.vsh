#version 130
#define END
#define VSH
#define MISC_GLINT
#include "/program/gbuffers_misc.glsl"
