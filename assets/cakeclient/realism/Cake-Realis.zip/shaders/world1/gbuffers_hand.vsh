#version 130
#define END
#define VSH
#define PROGRAM_HAND
#include "/program/gbuffers_solid.glsl"
