#ifndef LIB_LIGHTING
#define LIB_LIGHTING

// =============================================================================
//  Surface shading shared by the deferred pass and forward (translucent) passes.
//  Light colors are "radiance of a white diffuse surface" (irradiance / PI).
// =============================================================================

float ggxDistribution(float NoH, float a) {
    float a2 = a * a;
    float d = NoH * NoH * (a2 - 1.0) + 1.0;
    return a2 / (PI * d * d);
}

float smithVisibility(float NoV, float NoL, float a) {
    float k = a * 0.5;
    return 0.25 / ((NoV * (1.0 - k) + k) * (NoL * (1.0 - k) + k));
}

vec3 fresnelSchlick(vec3 f0, float cosTheta) {
    return f0 + (1.0 - f0) * pow5(1.0 - saturate(cosTheta));
}

float fresnelSchlick(float f0, float cosTheta) {
    return f0 + (1.0 - f0) * pow5(1.0 - saturate(cosTheta));
}

// GGX specular lobe times NoL. toView / toLight point away from the surface.
vec3 specularGGX(vec3 normal, vec3 toView, vec3 toLight, float roughness, vec3 f0) {
    vec3 halfway = normalize(toView + toLight);
    float NoL = saturate(dot(normal, toLight));
    float NoV = max(dot(normal, toView), 1e-3);
    float NoH = saturate(dot(normal, halfway));
    float VoH = saturate(dot(toView, halfway));
    float a = max(roughness * roughness, 0.003);
    return fresnelSchlick(f0, VoH) * (ggxDistribution(NoH, a) * smithVisibility(NoV, NoL, a) * NoL);
}

// Block light: Minecraft's linear light level blended with an inverse square law.
float blockLightFalloff(float level) {
    float d = (1.0 - level) * 15.0 + 1.0;
    float inverseSquare = 1.0 / (d * d) - 1.0 / 256.0;
    return mix(level * level * level, inverseSquare, 0.55);
}

vec3 blockLightColor() {
    return blackbody(BLOCKLIGHT_TEMP) * (2.4 * BLOCKLIGHT_STRENGTH);
}

struct Surface {
    vec3 albedo;      // linear
    vec3 normal;      // world space
    vec3 toView;      // world space, towards the camera
    float dist;       // to the camera, blocks
    vec2 lightmap;    // x = block light, y = sky light
    float ao;
    float emission;
    float smoothness;
    float metalness;
    float f0;
    float subsurface; // 0..1, foliage translucency
};

struct LightEnv {
    vec3 directColor; // sun or moon
    vec3 directDir;   // world space, towards the light
    vec3 ambientColor; // average sky light on flat ground
    vec3 skyColor;     // sky light arriving from the side the surface faces
    vec4 blockTint;    // rgb: color of the block light reaching the surface, a: confidence
    vec3 shadow;      // transmission of the direct light
    vec3 indirect;    // screen space GI radiance
};

vec3 shadeSurface(Surface s, LightEnv l) {
    float NoL = dot(s.normal, l.directDir);
    vec3 directLight = l.directColor * l.shadow;

    // ---- Direct diffuse ----
    vec3 diffuse = directLight * saturate(NoL);

#ifdef SUBSURFACE
    // Thin foliage: light wraps around and shines through when backlit.
    if (s.subsurface > 0.0) {
        float wrap = saturate(NoL * 0.5 + 0.5);
        float through = pow4(saturate(dot(-s.toView, l.directDir) * 0.5 + 0.5));
        vec3 sss = directLight * (0.35 * wrap + 0.9 * through) * (1.0 - saturate(NoL));
        diffuse += sss * s.subsurface * (0.6 * s.albedo + 0.4);
    }
#endif

    // ---- Sky ambient ----
#ifdef OVERWORLD
    float skyAccess = s.lightmap.y * s.lightmap.y * s.lightmap.y;
#else
    float skyAccess = 1.0;
#endif
    float hemisphere = 0.45 + 0.55 * (s.normal.y * 0.5 + 0.5);
    // Directional sky light: a wall facing the sunset is lit warm, the opposite one stays
    // blue, instead of every surface receiving the same average sky color.
    vec3 skyLight = mix(l.ambientColor, l.skyColor, 0.45);
    vec3 ambient = skyLight * (hemisphere * skyAccess * AMBIENT_STRENGTH);
    // Sunlight bounced off the ground and nearby walls (stand-in for the first GI bounce):
    // strongest on surfaces that face down or sideways, slightly warm like lit terrain.
    ambient += l.directColor * vec3(1.0, 0.94, 0.82) * (0.075 * skyAccess * (1.0 - 0.6 * s.normal.y));
    ambient += vec3(0.6, 0.7, 1.0) * (5.0 * lightningFlash() * skyAccess);
#if defined END && defined END_VOID_GLOW
    // The void under the islands glows: their undersides and the faces of the cliffs
    // catch a magenta light from below, so the land stands out against the black.
    float fromBelow = saturate(0.5 - 0.5 * s.normal.y);
    ambient += vec3(0.13, 0.035, 0.2) * (fromBelow * fromBelow * (0.5 + 0.5 * fromBelow));
#endif

    // ---- Block light and handheld light ----
    float blockLevel = s.lightmap.x;
#ifdef HANDHELD_LIGHT
    float held = float(max(heldBlockLightValue, heldBlockLightValue2)) / 15.0;
    if (held > 0.0) {
        float handLevel = held * saturate(1.0 - s.dist / (held * 15.0));
        blockLevel = max(blockLevel, handLevel);
    }
#endif
    // Light color: the default lamp color, replaced by the color of the actual emitters
    // nearby where that is known (soul fire blue, redstone red, sea lantern cyan ...).
    vec3 lampColor = blockLightColor();
    // A flame is never a single pure color. With fully saturated light a red lava glow
    // would turn every green or blue surface black, so the emitter hue is pulled towards
    // white and only partly replaces the lamp color.
    vec3 hue = mix(vec3(luma(l.blockTint.rgb)), l.blockTint.rgb, 0.55);
    vec3 emitterColor = hue / max(luma(hue), 0.02) * luma(lampColor);
    vec3 block = mix(lampColor, emitterColor, l.blockTint.a * 0.7) * blockLightFalloff(saturate(blockLevel));

    // ---- Minimum light so caves keep some readable shape ----
    vec3 minimum = vec3(0.010, 0.012, 0.018) * MIN_LIGHT + vec3(0.25) * nightVision;

    // Multi-bounce ambient occlusion (Jimenez et al.): in a bright crevice light keeps
    // bouncing between the walls, so occlusion is weaker and takes the surface color.
    vec3 aoA = 2.0404 * s.albedo - 0.3324;
    vec3 aoB = -4.7951 * s.albedo + 0.6417;
    vec3 aoC = 2.7552 * s.albedo + 0.6903;
    vec3 occlusion = max(vec3(s.ao), ((s.ao * aoA + aoB) * s.ao + aoC) * s.ao);

    vec3 indirectLight = (ambient + block + minimum) * occlusion + l.indirect;
    // Metals keep a quarter of their diffuse response: block textures are not pure metal,
    // and a perfect mirror turns black whenever its surroundings are dark (night, caves).
    vec3 color = s.albedo * (1.0 - 0.75 * s.metalness) * (diffuse + indirectLight);

    // ---- Direct specular ----
    if (s.smoothness > 0.05 && NoL > 0.0) {
        vec3 f0 = mix(vec3(s.f0), s.albedo, s.metalness);
        vec3 spec = specularGGX(s.normal, s.toView, l.directDir, 1.0 - s.smoothness, f0);
        color += min(directLight * PI * spec, vec3(40.0));
    }

    // ---- Emission ----
    color += s.albedo * (s.emission * 9.0 * EMISSIVE_STRENGTH);

    return color;
}

#endif
