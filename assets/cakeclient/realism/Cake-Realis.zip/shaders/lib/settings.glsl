#ifndef LIB_SETTINGS
#define LIB_SETTINGS

// =============================================================================
//  Realis Shaders - user options and pipeline directives.
//  Every tunable value lives here; shaders.properties maps them to the GUI and
//  to the LOW / MEDIUM / HIGH / ULTRA / EXTREME profiles.
// =============================================================================

// ---- Render target layout (read by Iris, intentionally inside a comment) ----
// colortex0  scene color (HDR). Before deferred: premultiplied overlay of unlit geometry.
// colortex1  normal (oct, RG) + material id (B)
// colortex2  block light, sky light, vanilla AO
// colortex3  emission, smoothness, metalness
// colortex4  albedo during gbuffers, then lit opaque scene (refraction / SSR source)
// colortex5  TAA history (RGB) + smoothed average luminance (A)
// colortex6  sky view LUT + light colors
// colortex7  bloom tiles
// colortex8  screen space GI (RGB) + AO (A)
// colortex9  block light color field (kept across frames)
// colortex10 volumetric clouds (kept across frames)
/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16;
const int colortex2Format = RGBA8;
const int colortex3Format = RGBA8;
const int colortex4Format = RGBA16F;
const int colortex5Format = RGBA16F;
const int colortex6Format = RGBA16F;
const int colortex7Format = R11F_G11F_B10F;
const int colortex8Format = RGBA16F;
const int colortex9Format = RGBA16F;
const int colortex10Format = RGBA16F;
const int shadowcolor0Format = RGBA8;
const int shadowcolor1Format = RGBA8;
const vec4 colortex0ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const bool colortex5Clear = false;
const bool colortex8Clear = false;
const bool colortex9Clear = false;
const bool colortex10Clear = false;
*/

// ---- Shadows -----------------------------------------------------------------
#define SHADOWS
const int shadowMapResolution = 2048; // [1024 1536 2048 3072 4096 6144 8192]
const float shadowDistance = 160.0; // [64.0 96.0 128.0 160.0 192.0 256.0 320.0]
const float sunPathRotation = -30.0; // [-50.0 -40.0 -30.0 -20.0 -10.0 0.0 10.0 20.0 30.0 40.0 50.0]
#define SHADOW_SAMPLES 8 // [4 6 8 12 16 24]
#define SHADOW_PCSS
#define SHADOW_SOFTNESS 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define COLORED_SHADOWS
#define CONTACT_SHADOWS
#define CLOUD_SHADOWS

const bool shadowHardwareFiltering = false;
const bool shadowtex0Nearest = true;
const bool shadowtex1Nearest = true;
const bool shadowcolor0Nearest = false;
const bool shadowcolor1Nearest = true;
const float shadowDistanceRenderMul = 1.0;
const float shadowIntervalSize = 2.0;
const float ambientOcclusionLevel = 1.0;
const float eyeBrightnessHalflife = 8.0;
const int noiseTextureResolution = 256;
const float centerDepthHalflife = 1.5;

// ---- Lighting ----------------------------------------------------------------
#define AMBIENT_STRENGTH 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define MIN_LIGHT 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define BLOCKLIGHT_STRENGTH 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define BLOCKLIGHT_TEMP 3000.0 // [1800.0 2200.0 2600.0 3000.0 3500.0 4200.0 5000.0 6500.0]
#define EMISSIVE_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define HANDHELD_LIGHT
#define COLORED_LIGHT
#define COLORED_LIGHT_STRENGTH 1.0 // [0.25 0.5 0.75 1.0]
#define PBR_TEXTURES
#define PARALLAX
#define PARALLAX_DEPTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define PARALLAX_STEPS 16 // [8 16 24 32]
#define SUBSURFACE
#define SSAO
#define AO_STRENGTH 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define SSGI
#define GI_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define RT_RAYS 2 // [1 2 3 4 6 8]
#define RT_STEPS 6 // [4 6 8 12 16]

// ---- Atmosphere ----------------------------------------------------------------
#define ATMOSPHERE_STEPS 16 // [8 12 16 24 32]
#define STARS
#define STAR_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define SUN_SIZE 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define MOON_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define AURORA
#define SHOOTING_STARS
#define END_STAR
#define END_VOID_GLOW
#define END_HAZE
#define END_MOTES
#define AURORA_STEPS 20 // [8 12 20 32]
#define AURORA_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]

// ---- Clouds ----------------------------------------------------------------
#define VOLUMETRIC_CLOUDS
#define CLOUD_STEPS 16 // [6 10 16 24 32 48 64]
#define CLOUD_LIGHT_STEPS 4 // [2 3 4 5 6 8]
#define CLOUD_DETAIL
#define CLOUD_TEMPORAL
#define CIRRUS_CLOUDS
#define CLOUD_ALTITUDE 320.0 // [192.0 256.0 320.0 400.0 500.0 650.0 800.0]
#define CLOUD_THICKNESS 220.0 // [120.0 160.0 220.0 300.0 400.0]
#define CLOUD_COVERAGE 0.45 // [0.2 0.3 0.4 0.45 0.5 0.6 0.7 0.8]
#define CLOUD_DENSITY 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define CLOUD_SPEED 1.0 // [0.0 0.5 1.0 2.0 4.0 8.0]

// ---- Water ----------------------------------------------------------------
#define WATER_WAVE_ITERATIONS 10 // [4 6 8 10 12 16 20]
#define WAVE_HEIGHT 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define WAVE_SPEED 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define WATER_VERTEX_WAVES
#define WATER_REFRACTION
#define REFRACTION_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define WATER_CAUSTICS
#define CAUSTICS_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define WET_SHORE
#define UNDERWATER_BUBBLES
#define WATER_PLAYER_RIPPLES
#define WATER_FOG_DENSITY 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define WATER_VANILLA_TINT 0.5 // [0.0 0.25 0.5 0.75 1.0]

// ---- Reflections ----------------------------------------------------------------
#define SSR
#define SSR_STEPS 20 // [8 12 20 28 40 64]
#define SURFACE_REFLECTIONS
#define CLOUD_REFLECTIONS

// ---- Weather ----------------------------------------------------------------
#define WET_SURFACES
#define RAIN_PUDDLES
#define PUDDLE_AMOUNT 1.0 // [0.5 0.75 1.0 1.25 1.5]
#define RAIN_RIPPLES
#define WALL_DRIPS
#define CAMERA_DROPLETS
#define DROPLET_AMOUNT 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define RAIN_OPACITY 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define RAIN_WIND 0.25 // [0.0 0.1 0.25 0.4 0.6]
#define LIGHTNING_FLASH
#define RAINBOW
#define SNOW_COVER
const float wetnessHalflife = 300.0; // [100.0 200.0 300.0 600.0 1200.0]
const float drynessHalflife = 900.0; // [200.0 400.0 900.0 1800.0 3600.0]

// ---- Fog ----------------------------------------------------------------
#define VOLUMETRIC_FOG
#define VL_STEPS 10 // [4 6 10 16 24 32]
#define VL_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define FOG_DENSITY 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define MORNING_FOG 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define BORDER_FOG

// ---- Post processing ----------------------------------------------------------------
#define TAA
#define FXAA
#define BLOOM
#define BLOOM_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define AUTO_EXPOSURE
#define EXPOSURE 1.0 // [0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.35 1.5 1.75 2.0]
#define TONEMAP 0 // [0 1 2]
#define CONTRAST 1.0 // [0.8 0.9 0.95 1.0 1.05 1.1 1.2]
#define SATURATION 1.0 // [0.0 0.5 0.75 0.9 1.0 1.1 1.2 1.35]
#define VIGNETTE
#define VIGNETTE_STRENGTH 0.25 // [0.1 0.25 0.4 0.6]
#define SHARPENING 0.4 // [0.0 0.2 0.4 0.6 0.8 1.0]
//#define DOF
#define DOF_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
//#define MOTION_BLUR
#define MOTION_BLUR_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define LENS_FLARE
#define LENS_FLARE_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define HEAT_HAZE
#define UNDERWATER_DISTORTION

// ---- Foliage ----------------------------------------------------------------
#define WAVING_PLANTS
#define WAVING_LEAVES
#define WAVING_LANTERNS
#define WIND_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]

// ---- Fixed pipeline constants (not user options) ----------------------------
#define SKY_LUT_W 256
#define SKY_LUT_H 128

#endif
