#ifndef LIB_SHADOWS
#define LIB_SHADOWS

// =============================================================================
//  Shadow mapping. Iris gives one shadow map, so instead of cascades the map is
//  radially distorted: texel density is ~10x higher around the player and falls
//  off with distance (same goal as cascades, one pass). Filtering is PCF on a
//  rotated Vogel disk with an optional PCSS blocker search for contact
//  hardening. Translucent casters tint the light; water adds caustics and
//  depth absorption.
// =============================================================================

uniform sampler2D shadowtex0;    // all casters
uniform sampler2D shadowtex1;    // opaque casters only
uniform sampler2D shadowcolor0;  // translucent tint, or caustics for water
uniform sampler2D shadowcolor1;  // R = caster is water

#define SHADOW_DISTORTION 0.9
#define SHADOW_Z_SCALE 0.2

float shadowDistortFactor(vec2 p) {
    return length(p) * SHADOW_DISTORTION + (1.0 - SHADOW_DISTORTION);
}

vec3 distortShadowClip(vec3 clip) {
    clip.xy /= shadowDistortFactor(clip.xy);
    clip.z *= SHADOW_Z_SCALE;
    return clip;
}

#ifdef FSH

// Scene space -> undistorted shadow clip space (orthographic).
vec3 sceneToShadowClip(vec3 scenePos) {
    vec3 sv = mat3(shadowModelView) * scenePos + shadowModelView[3].xyz;
    return vec3(shadowProjection[0].x * sv.x, shadowProjection[1].y * sv.y, shadowProjection[2].z * sv.z)
         + shadowProjection[3].xyz;
}

// Shadow map depth difference -> blocks along the light direction.
float shadowDepthToWorld() {
    return 2.0 / (SHADOW_Z_SCALE * abs(shadowProjection[2].z));
}

vec2 vogelDisk(int index, int count, float rotation) {
    float r = sqrt((float(index) + 0.5) / float(count));
    float a = float(index) * 2.39996323 + rotation;
    return r * vec2(cos(a), sin(a));
}

// One filtered tap: 1 = lit, 0 = blocked, colored when light passes a translucent caster.
vec3 shadowTap(vec2 uv, float z, float casterIsWater, float depthToWorld) {
    float opaqueDepth = textureLod(shadowtex1, uv, 0.0).r;
#ifdef COLORED_SHADOWS
    float anyDepth = textureLod(shadowtex0, uv, 0.0).r;
    if (z <= anyDepth) return vec3(1.0);
    if (z > opaqueDepth) {
        // Leaves are thin: a little green light makes it through a crown, fading with the
        // amount of foliage the light had to cross. Everything else blocks light completely.
        if (textureLod(shadowcolor1, uv, 0.0).g < 0.5) return vec3(0.0);
        vec3 leaf = textureLod(shadowcolor0, uv, 0.0).rgb;
        leaf *= leaf;
        leaf /= max(maxOf(leaf), 0.05);
        return leaf * (0.3 * exp(-(z - opaqueDepth) * depthToWorld * 0.35));
    }
    vec3 tint = textureLod(shadowcolor0, uv, 0.0).rgb;
    if (casterIsWater > 0.5) {
        float waterDepth = (z - anyDepth) * depthToWorld;
        return vec3(tint.r * 2.0) * exp(-WATER_ABSORPTION * (WATER_FOG_DENSITY * waterDepth));
    }
    return tint * tint;
#else
    return vec3(step(z, opaqueDepth));
#endif
}

// Soft shadow for a scene space point. Returns light transmission (RGB).
vec3 getShadow(vec3 scenePos, vec3 normal, float dither, int samples) {
    vec3 clip0 = sceneToShadowClip(scenePos);
    float edgeFade = smoothstep(0.85, 1.0, max(length(clip0.xy), abs(clip0.z)));
    if (edgeFade >= 1.0) return vec3(1.0);

    float distortion = shadowDistortFactor(clip0.xy);
    // World size of one shadow texel at this distance from the player.
    float texel = 2.0 * shadowDistance / float(shadowMapResolution) * distortion;
    float depthToWorld = shadowDepthToWorld();

    // Normal offset bias: scales with the local texel size, so no acne and no peter panning.
    vec3 biased = scenePos + normal * (texel * 2.0 + 0.02);
    vec3 pos = distortShadowClip(sceneToShadowClip(biased)) * 0.5 + 0.5;
    pos.z -= texel * 0.3 / depthToWorld;

    float worldToUv = 1.0 / (2.0 * shadowDistance * distortion);
    float rotation = dither * TAU;
#ifndef TEMPORAL_AA
    // Without accumulation over frames a per pixel random rotation stays on screen as a
    // stipple pattern in every shadow edge. Use one fixed, denser sample pattern instead:
    // the edge becomes a smooth ramp.
    rotation = 0.0;
    samples = max(samples, 16);
#endif
    float penumbra = 0.05 * SHADOW_SOFTNESS;

#ifdef SHADOW_PCSS
    // Blocker search: average depth of occluders decides the penumbra width.
    float searchRadius = 0.7 * SHADOW_SOFTNESS * worldToUv;
    float blockerSum = 0.0;
    float blockers = 0.0;
    for (int i = 0; i < 5; i++) {
        vec2 uv = pos.xy + vogelDisk(i, 5, rotation) * searchRadius;
#ifdef COLORED_SHADOWS
        float d = textureLod(shadowtex0, uv, 0.0).r;
#else
        float d = textureLod(shadowtex1, uv, 0.0).r;
#endif
        if (d < pos.z) {
            blockerSum += d;
            blockers += 1.0;
        }
    }
    if (blockers < 0.5) return vec3(1.0);
    float blockerDistance = (pos.z - blockerSum / blockers) * depthToWorld;
    // The upper limit keeps the sun flecks under tree crowns from blurring into flat shade.
    penumbra = clamp(blockerDistance * 0.04, 0.025, 0.45) * SHADOW_SOFTNESS;
#endif

    float radius = max(penumbra, texel) * worldToUv;
    float casterIsWater = 0.0;
#ifdef COLORED_SHADOWS
    casterIsWater = textureLod(shadowcolor1, pos.xy, 0.0).r;
#endif

    vec3 light = vec3(0.0);
    for (int i = 0; i < samples; i++) {
        vec2 uv = pos.xy + vogelDisk(i, samples, rotation) * radius;
        light += shadowTap(uv, pos.z, casterIsWater, depthToWorld);
    }
    light /= float(samples);
    return mix(light, vec3(1.0), edgeFade);
}

// Single unfiltered tap, for volumetric light.
vec3 getShadowFast(vec3 scenePos) {
    vec3 clip0 = sceneToShadowClip(scenePos);
    if (max(length(clip0.xy), abs(clip0.z)) >= 1.0) return vec3(1.0);
    vec3 pos = distortShadowClip(clip0) * 0.5 + 0.5;
    float casterIsWater = 0.0;
#ifdef COLORED_SHADOWS
    casterIsWater = textureLod(shadowcolor1, pos.xy, 0.0).r;
#endif
    return shadowTap(pos.xy, pos.z - 0.0002, casterIsWater, shadowDepthToWorld());
}

#endif
#endif
