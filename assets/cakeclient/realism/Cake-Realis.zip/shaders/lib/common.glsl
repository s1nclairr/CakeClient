#ifndef LIB_COMMON
#define LIB_COMMON

// =============================================================================
//  Shared uniforms, math helpers, space conversions and dithering.
// =============================================================================

// Temporal techniques: sub-pixel camera jitter, per frame dither, history blending and
// clouds spread over several frames. They all rely on buffers that keep their contents
// from one frame to the next, and when that does not hold the whole image trembles.
// Iris is known to behave; on OptiFine this is unverified, so there the pack renders
// every frame on its own (steady image, FXAA for the edges, slightly more grain).
#if defined TAA && defined IS_IRIS
#define TEMPORAL_AA
#endif

#define PI 3.14159265359
#define TAU 6.28318530718
#define SEA_LEVEL 63.0

// Iris squeezes hand depth into a small range; these let us detect and undo it.
#ifndef MC_HAND_DEPTH
#define MC_HAND_DEPTH 0.125
#endif
#define HAND_DEPTH_LIMIT 0.56

// Dimensions with a directional light and a shadow map: the Overworld (sun / moon) and
// the End (the dark star). The Nether has neither.
#if defined OVERWORLD || defined END
#define DIRECT_LIGHT
#endif

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowProjectionInverse;

uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;

uniform float viewWidth;
uniform float viewHeight;
uniform float aspectRatio;
uniform float near;
uniform float far;

uniform float frameTimeCounter;
uniform float frameTime;
uniform int frameCounter;
uniform float sunAngle;
uniform int worldTime;
uniform int moonPhase;

uniform float rainStrength;
uniform float wetness;
uniform float thunderStrength;
uniform vec4 lightningBoltPosition;

uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
uniform float eyeAltitude;
uniform vec3 fogColor;
uniform float blindness;
uniform float darknessFactor;
uniform float nightVision;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;

// Custom uniforms (shaders.properties). They default to 0 if unavailable.
uniform float biomeNoRain;
uniform float biomeHumidity;
uniform float biomeSnowy;
uniform float skyFlash;  // OptiFine only: sudden jump of the sky brightness (lightning)
// Built in Iris uniform (0 none, 1 rain, 2 snow); backs up the smoothed custom one.
uniform int biome_precipitation;

// 1 in biomes where it snows instead of raining.
float snowyBiome() {
    return max(biomeSnowy, biome_precipitation == 2 ? 1.0 : 0.0);
}

// ---- Math --------------------------------------------------------------------
float saturate(float x) { return clamp(x, 0.0, 1.0); }
vec2 saturate(vec2 x) { return clamp(x, 0.0, 1.0); }
vec3 saturate(vec3 x) { return clamp(x, 0.0, 1.0); }

float pow2(float x) { return x * x; }
float pow4(float x) { x *= x; return x * x; }
float pow5(float x) { float x2 = x * x; return x2 * x2 * x; }
float maxOf(vec3 v) { return max(v.x, max(v.y, v.z)); }

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 srgbToLinear(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }
vec3 linearToSrgb(vec3 c) { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }

// Ray / sphere intersection. Returns (near, far) distances, or (-1, -1) on miss.
vec2 raySphere(vec3 origin, vec3 dir, float radius) {
    float b = dot(origin, dir);
    float c = dot(origin, origin) - radius * radius;
    float h = b * b - c;
    if (h < 0.0) return vec2(-1.0);
    h = sqrt(h);
    return vec2(-b - h, -b + h);
}

// Henyey-Greenstein phase function multiplied by 4*PI (mean value 1).
float phaseHG(float cosTheta, float g) {
    float g2 = g * g;
    return (1.0 - g2) / pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5);
}

// Approximate black body color (linear RGB) for a temperature in Kelvin.
vec3 blackbody(float kelvin) {
    float t = kelvin / 100.0;
    vec3 c;
    c.r = t <= 66.0 ? 1.0 : saturate(1.292936 * pow(t - 60.0, -0.1332047));
    c.g = t <= 66.0 ? saturate(0.3900816 * log(t) - 0.6318414)
                    : saturate(1.1298909 * pow(t - 60.0, -0.0755148));
    c.b = t >= 66.0 ? 1.0 : (t <= 19.0 ? 0.0 : saturate(0.5432068 * log(t - 10.0) - 1.1962541));
    return srgbToLinear(c);
}

// Octahedral normal encoding (unit vector <-> 2 channels in 0..1).
vec2 encodeNormal(vec3 n) {
    n /= abs(n.x) + abs(n.y) + abs(n.z);
    vec2 wrapped = (1.0 - abs(n.yx)) * vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
    vec2 e = n.z >= 0.0 ? n.xy : wrapped;
    return e * 0.5 + 0.5;
}

vec3 decodeNormal(vec2 e) {
    e = e * 2.0 - 1.0;
    vec3 n = vec3(e, 1.0 - abs(e.x) - abs(e.y));
    float t = max(-n.z, 0.0);
    n.x += n.x >= 0.0 ? -t : t;
    n.y += n.y >= 0.0 ? -t : t;
    return normalize(n);
}

// ---- Water optics (shared by the water surface, shadows and underwater fog) -----
const vec3 WATER_ABSORPTION = vec3(0.30, 0.075, 0.045);
const float WATER_SCATTER = 0.10;
const vec3 WATER_SCATTER_TINT = vec3(0.0875, 0.28, 0.35);

// Fraction of light surviving a path of d blocks through water.
vec3 waterTransmittance(float d) {
    return exp(-(WATER_ABSORPTION + WATER_SCATTER) * (WATER_FOG_DENSITY * d));
}

// Light scattered into a path of d blocks through water lit by "light".
vec3 waterInscatter(float d, vec3 light) {
    vec3 extinction = WATER_ABSORPTION + WATER_SCATTER;
    return WATER_SCATTER_TINT * light * (WATER_SCATTER / extinction) * (1.0 - waterTransmittance(d));
}

// ---- Hashes and dithering ------------------------------------------------------
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

vec3 hash32(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yxz + 33.33);
    return fract((p3.xxy + p3.yzz) * p3.zyx);
}

// Outline of an irregular water drop. n = offset from the drop center in radii, rnd =
// per drop random values. Returns a distance that is 1 on the outline. The shape is a
// lumpy body that sags downwards, merged with a smaller lobe at a random side, the way
// real drops look after two of them have run together.
float dropShape(vec2 n, vec3 rnd) {
    n.y *= n.y > 0.0 ? 1.2 : 0.8;
    float angle = atan(n.y, n.x);
    float lumps = 1.0 + 0.17 * sin(angle * 3.0 + rnd.x * TAU) + 0.09 * sin(angle * 5.0 + rnd.y * TAU);
    float body = length(n) / lumps;
    float side = rnd.z * TAU;
    float lobe = length(n - vec2(cos(side), sin(side) * 0.7) * 0.6) / (0.4 + 0.25 * rnd.x);
    float h = saturate(0.5 + 0.5 * (lobe - body) / 0.4);
    return mix(lobe, body, h) - 0.4 * h * (1.0 - h);
}

// Interleaved gradient noise.
float ign(vec2 p) {
    return fract(52.9829189 * fract(0.06711056 * p.x + 0.00583715 * p.y));
}

// Ordered dither that repeats every 4x4 pixels. Unlike random noise it is removed
// completely by a 4x4 box filter, which is what makes ray traced effects usable without
// any accumulation over time.
float bayer4(vec2 fragCoord) {
    const float pattern[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0,
                                        3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
    ivec2 p = ivec2(fragCoord) & 3;
    return (pattern[p.x + p.y * 4] + 0.5) / 16.0;
}

// Dither that changes every frame when TAA is able to integrate it.
float ditherT(vec2 fragCoord) {
#ifdef TEMPORAL_AA
    fragCoord += 5.588238 * float(frameCounter % 64);
#endif
    return ign(fragCoord);
}

// ---- Temporal jitter -------------------------------------------------------------
const vec2 taaOffsets[8] = vec2[8](
    vec2( 0.125, -0.375), vec2(-0.125,  0.375), vec2( 0.625,  0.125), vec2(-0.375, -0.625),
    vec2(-0.625,  0.625), vec2(-0.875, -0.125), vec2( 0.375, -0.875), vec2( 0.875,  0.875));

// Jitter in NDC units (add to gl_Position.xy * w).
vec2 taaJitter() {
    return taaOffsets[frameCounter % 8] / vec2(viewWidth, viewHeight);
}

// Jitter of the previous frame, for reading buffers that were rendered with it.
vec2 taaJitterPrevious() {
    return taaOffsets[(frameCounter + 7) % 8] / vec2(viewWidth, viewHeight);
}

// ---- Space conversions -------------------------------------------------------------
vec3 screenToView(vec2 uv, float depth) {
    vec3 ndc = vec3(uv, depth) * 2.0 - 1.0;
#ifdef TEMPORAL_AA
    ndc.xy -= taaJitter();
#endif
    vec4 v = gbufferProjectionInverse * vec4(ndc, 1.0);
    return v.xyz / v.w;
}

vec3 viewToScreen(vec3 viewPos) {
    vec4 c = gbufferProjection * vec4(viewPos, 1.0);
    vec3 ndc = c.xyz / c.w;
#ifdef TEMPORAL_AA
    ndc.xy += taaJitter();
#endif
    return ndc * 0.5 + 0.5;
}

// Scene space: world aligned, relative to the camera.
vec3 viewToScene(vec3 viewPos) {
    return mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
}

vec3 sceneToView(vec3 scenePos) {
    return mat3(gbufferModelView) * (scenePos - gbufferModelViewInverse[3].xyz);
}

// Positive view distance along the camera axis for a depth buffer value.
float linearizeDepth(float depth) {
    float z = depth * 2.0 - 1.0;
    float a = gbufferProjectionInverse[2].z * z + gbufferProjectionInverse[3].z;
    float b = gbufferProjectionInverse[2].w * z + gbufferProjectionInverse[3].w;
    return -a / b;
}

// Undo the hand depth squeeze so the hand can be shaded like the world.
float fixHandDepth(float depth) {
    return ((depth * 2.0 - 1.0) / MC_HAND_DEPTH) * 0.5 + 0.5;
}

// Screen position of a scene space point in the previous frame.
vec3 reprojectScene(vec3 scenePos) {
    vec3 prevScene = scenePos + (cameraPosition - previousCameraPosition);
    vec4 prevView = gbufferPreviousModelView * vec4(prevScene, 1.0);
    vec4 prevClip = gbufferPreviousProjection * prevView;
    return prevClip.xyz / prevClip.w * 0.5 + 0.5;
}

// ---- Light directions (world space) -------------------------------------------------
vec3 worldSunDir() { return normalize(mat3(gbufferModelViewInverse) * sunPosition); }
vec3 worldMoonDir() { return normalize(mat3(gbufferModelViewInverse) * moonPosition); }
vec3 worldLightDir() { return normalize(mat3(gbufferModelViewInverse) * shadowLightPosition); }

// 1 while a lightning bolt is on screen.
float lightningFlash() {
#ifdef LIGHTNING_FLASH
    return max(step(0.5, lightningBoltPosition.w), saturate(skyFlash));
#else
    return 0.0;
#endif
}

// How much open sky the camera currently sees (0 in caves, 1 outside).
float eyeSkyExposure() {
    return saturate(float(eyeBrightnessSmooth.y) / 240.0);
}

#endif
