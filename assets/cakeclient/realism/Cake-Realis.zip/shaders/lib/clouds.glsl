#ifndef LIB_CLOUDS
#define LIB_CLOUDS

// =============================================================================
//  Volumetric clouds. A cumulus layer is ray marched through a slab that wraps
//  a (small) planet so clouds sink below the horizon instead of converging on
//  it. Shape = large weather map + 3D value noise + cellular erosion.
//  A second, flat cirrus layer sits high above.
// =============================================================================

#include "/lib/noise.glsl"

const float CLOUD_PLANET_RADIUS = 60000.0;
const float CLOUD_MAX_DISTANCE = 11000.0;
const float CLOUD_EXTINCTION = 0.055;

float cloudCoverage() {
    return mix(CLOUD_COVERAGE, 0.95, rainStrength);
}

vec2 cloudWind() {
    return vec2(4.0, 1.5) * (frameTimeCounter * CLOUD_SPEED);
}

// Density (0..1) at a world position. h is the normalized height in the layer.
// quality 0 = shape only (shadows, light march), 1 = with detail erosion.
float cloudDensity(vec3 p, float h, float coverage, int quality) {
    if (h <= 0.0 || h >= 1.0) return 0.0;
    vec2 wind = cloudWind();
    vec3 q = vec3(p.x + wind.x, p.y, p.z + wind.y);

    // Weather map: where clouds are allowed to form.
    float weather = noise2D(q.xz * 0.0011) * 0.65 + noise2D(q.xz * 0.0037 + 31.7) * 0.35;

    // Flat bases, rounded tops that are taller where the weather map is strong.
    float d = weather - (0.74 - 0.5 * coverage);
    d -= (1.0 - smoothstep(0.0, 0.1, h)) * 0.4;
    d -= smoothstep(0.2, 1.0, h) * 0.32;
    if (d < -0.21) return 0.0;

    // Two octaves of 3D noise sculpt the volume: large heaps plus cauliflower lumps.
    float shape = noise3D(vec3(q.x, q.y * 1.3, q.z) * 0.0085) * 0.65
                + noise3D(q * 0.021 + 13.0) * 0.35;
    d += (shape - 0.5) * 0.42;

#ifdef CLOUD_DETAIL
    if (quality > 0 && d > -0.1) {
        // Erosion eats into the edges; it is stronger near the top, which turns the
        // crowns wispy while the bases stay dense and flat.
        float billows = worley2D(q.xz * 0.0015 + q.y * 0.0011);
        float fine = noise3D(q * 0.055 + vec3(0.0, frameTimeCounter * 0.05, 0.0));
        d -= ((1.0 - billows) * 0.1 + (0.5 - fine) * 0.12) * (0.6 + 0.8 * h);
    }
#endif

    return saturate(d * 5.5);
}

// Optical depth from a point towards the light.
float cloudLightDepth(vec3 p, float alt, vec3 lightDir, float coverage, int steps) {
    float stepLen = 18.0;
    float t = 0.0;
    float depth = 0.0;
    for (int i = 0; i < steps; i++) {
        t += stepLen * 0.5;
        vec3 q = p + lightDir * t;
        float h = (alt + lightDir.y * t - CLOUD_ALTITUDE) / CLOUD_THICKNESS;
        depth += cloudDensity(q, h, coverage, 0) * stepLen;
        t += stepLen * 0.5;
        stepLen *= 1.9;
    }
    return depth * CLOUD_EXTINCTION * CLOUD_DENSITY;
}

// March the cumulus layer. Returns (in-scattered light, transmittance).
vec4 renderClouds(vec3 camWorld, vec3 dir, float maxDist, float dither,
                  vec3 lightColor, vec3 ambientColor, vec3 lightDir, vec3 hazeColor,
                  int steps, int lightSteps) {
    float base = CLOUD_ALTITUDE;
    float top = CLOUD_ALTITUDE + CLOUD_THICKNESS;

    vec3 origin = vec3(0.0, CLOUD_PLANET_RADIUS + camWorld.y, 0.0);
    vec2 hitBase = raySphere(origin, dir, CLOUD_PLANET_RADIUS + base);
    vec2 hitTop = raySphere(origin, dir, CLOUD_PLANET_RADIUS + top);

    float t0;
    float t1;
    if (camWorld.y < base) {
        t0 = hitBase.y;
        t1 = hitTop.y;
    } else if (camWorld.y < top) {
        t0 = 0.0;
        t1 = hitBase.x > 0.0 ? hitBase.x : hitTop.y;
    } else {
        if (hitTop.x < 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
        t0 = hitTop.x;
        t1 = hitBase.x > 0.0 ? hitBase.x : hitTop.y;
    }

    if (t0 >= maxDist || t0 >= CLOUD_MAX_DISTANCE) return vec4(0.0, 0.0, 0.0, 1.0);
    t1 = min(t1, min(maxDist, CLOUD_MAX_DISTANCE));
    if (t1 <= t0) return vec4(0.0, 0.0, 0.0, 1.0);

    float coverage = cloudCoverage();
    float segment = t1 - t0;
    float cosTheta = dot(dir, lightDir);
    // Artistic dual lobe phase: strong forward peak (silver lining) over a bright base
    // that stands in for multiple scattering.
    float phase = 0.5 + 0.4 * phaseHG(cosTheta, 0.55) + 0.1 * min(phaseHG(cosTheta, 0.85), 12.0)
                + 0.12 * phaseHG(cosTheta, -0.3);
    float storm = 1.0 - 0.45 * thunderStrength;
    vec3 flash = vec3(0.6, 0.7, 1.0) * (6.0 * lightningFlash());

    vec3 scatter = vec3(0.0);
    float transmittance = 1.0;
    float meanDist = 0.0;
    float weight = 0.0;

    for (int i = 0; i < steps; i++) {
        // Steps grow with distance: detail where the clouds are close, long strides
        // towards the horizon where they are small on screen anyway.
        float fa = float(i) / float(steps);
        float fb = float(i + 1) / float(steps);
        float ta = segment * fa * (0.45 + 0.55 * fa);
        float tb = segment * fb * (0.45 + 0.55 * fb);
        float stepLen = tb - ta;
        float t = t0 + ta + stepLen * dither;
        vec3 rel = dir * t;
        float alt = length(origin + rel) - CLOUD_PLANET_RADIUS;
        float h = (alt - base) / CLOUD_THICKNESS;
        vec3 p = camWorld + rel;
        float density = cloudDensity(p, h, coverage, 1);
        if (density <= 0.001) continue;

        float od = density * CLOUD_EXTINCTION * CLOUD_DENSITY * stepLen;
        float stepT = exp(-od);

        float lightDepth = cloudLightDepth(p, alt, lightDir, coverage, lightSteps);
        // Beer-Lambert plus two slower decaying octaves: light that has scattered several
        // times inside the cloud still gets through, which keeps the cores from going black.
        float lightEnergy = exp(-lightDepth) * 0.6 + exp(-lightDepth * 0.3) * 0.26 + exp(-lightDepth * 0.08) * 0.14;
        float powder = 1.0 - exp(-density * 4.0 - lightDepth * 2.0);
        lightEnergy *= mix(1.0, powder, 0.35);

        vec3 light = lightColor * (phase * lightEnergy);
        // Sky light from above (bases are darker), plus sunlight bounced off the ground.
        light += (ambientColor + flash) * (0.3 + 0.7 * h) * (1.0 - 0.4 * density);
        light += lightColor * (0.05 * (1.0 - h) * max(lightDir.y, 0.0));
        light *= storm;

        float contribution = transmittance * (1.0 - stepT);
        scatter += light * contribution;
        meanDist += t * contribution;
        weight += contribution;
        transmittance *= stepT;
        if (transmittance < 0.02) {
            transmittance = 0.0;
            break;
        }
    }

    // Aerial perspective: distant clouds melt into the sky haze.
    if (weight > 0.0) {
        float dist = meanDist / weight;
        float haze = 1.0 - exp(-dist * 0.00016);
        haze = max(haze, smoothstep(0.6, 1.0, dist / CLOUD_MAX_DISTANCE));
        float alpha = 1.0 - transmittance;
        scatter = mix(scatter, hazeColor * alpha, haze);
        // Fade the layer itself out at the draw limit.
        float limit = smoothstep(1.0, 0.75, dist / CLOUD_MAX_DISTANCE);
        scatter *= limit;
        transmittance = mix(1.0, transmittance, limit);
    }

    return vec4(scatter, transmittance);
}

// Clouds as seen in a mirror (water, glass). A coarse ray march resolves into blotches
// with hard borders there, so reflections use a smooth estimate instead: the layer is
// sampled at three heights where the reflected ray crosses it, without edge erosion,
// and lit with a simple self shadowing term. Cheaper than marching and free of noise.
vec4 renderCloudsReflection(vec3 camWorld, vec3 dir, vec3 lightColor, vec3 ambientColor,
                            vec3 lightDir, vec3 hazeColor) {
    if (dir.y < 0.02 || camWorld.y > CLOUD_ALTITUDE) return vec4(0.0, 0.0, 0.0, 1.0);
    float tMid = (CLOUD_ALTITUDE + 0.45 * CLOUD_THICKNESS - camWorld.y) / dir.y;
    if (tMid > CLOUD_MAX_DISTANCE) return vec4(0.0, 0.0, 0.0, 1.0);

    float coverage = cloudCoverage();
    float pathPerSample = min(CLOUD_THICKNESS / dir.y, 900.0) / 3.0;
    float depth = 0.0;
    for (int i = 0; i < 3; i++) {
        float h = 0.2 + 0.25 * float(i);
        float t = (CLOUD_ALTITUDE + h * CLOUD_THICKNESS - camWorld.y) / dir.y;
        depth += cloudDensity(camWorld + dir * t, h, coverage, 0) * pathPerSample;
    }
    depth *= CLOUD_EXTINCTION * CLOUD_DENSITY;
    // A gentle opacity curve: in a mirror the cloud edges should fade in, not cut out,
    // and a reflection never reaches the full brightness of the cloud itself.
    float alpha = (1.0 - exp(-depth * 0.1)) * 0.8;
    if (alpha <= 0.001) return vec4(0.0, 0.0, 0.0, 1.0);

    float phase = 0.5 + 0.4 * phaseHG(dot(dir, lightDir), 0.55);
    vec3 light = lightColor * (phase * (0.35 + 0.65 * exp(-depth * 0.6))) + ambientColor * 0.75;
    light *= 1.0 - 0.45 * thunderStrength;

    float haze = max(1.0 - exp(-tMid * 0.00016), smoothstep(0.6, 1.0, tMid / CLOUD_MAX_DISTANCE));
    alpha *= smoothstep(1.0, 0.75, tMid / CLOUD_MAX_DISTANCE);
    return vec4(mix(light, hazeColor, haze) * alpha, 1.0 - alpha);
}

// Thin high altitude ice clouds (2D). Only meaningful for sky pixels.
vec4 renderCirrus(vec3 camWorld, vec3 dir, vec3 lightColor, vec3 ambientColor, vec3 lightDir) {
    float altitude = CLOUD_ALTITUDE + CLOUD_THICKNESS + 900.0;
    if (camWorld.y >= altitude || dir.y <= 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
    vec3 origin = vec3(0.0, CLOUD_PLANET_RADIUS + camWorld.y, 0.0);
    float t = raySphere(origin, dir, CLOUD_PLANET_RADIUS + altitude).y;
    if (t <= 0.0 || t > 30000.0) return vec4(0.0, 0.0, 0.0, 1.0);

    vec2 p = (camWorld.xz + dir.xz * t) * 0.00022 + cloudWind() * 0.00009;
    float streaks = noise2D(p * vec2(1.0, 3.2)) * 0.6 + noise2D(p * vec2(2.3, 7.0) + 9.1) * 0.4;
    float patches = noise2D(p * 0.27 + 3.3);
    float density = saturate((streaks * patches - 0.22 + 0.2 * rainStrength) * 2.2);
    density *= smoothstep(30000.0, 9000.0, t);
    if (density <= 0.0) return vec4(0.0, 0.0, 0.0, 1.0);

    float alpha = density * 0.55;
    float phase = 0.6 + 0.4 * phaseHG(dot(dir, lightDir), 0.7);
    vec3 light = lightColor * phase * 0.55 + ambientColor * 0.8;
    return vec4(light * alpha, 1.0 - alpha);
}

// Sunlight attenuation on the ground below the cloud layer.
float cloudShadow(vec3 worldPos, vec3 lightDir) {
    float mid = CLOUD_ALTITUDE + CLOUD_THICKNESS * 0.3;
    if (worldPos.y >= mid || lightDir.y < 0.04) return 1.0;
    vec3 p = worldPos + lightDir * ((mid - worldPos.y) / lightDir.y);
    float density = cloudDensity(p, 0.3, cloudCoverage(), 0);
    float shadow = exp(-density * CLOUD_THICKNESS * 0.35 * CLOUD_EXTINCTION * CLOUD_DENSITY);
    return mix(1.0, shadow, smoothstep(0.04, 0.2, lightDir.y));
}

#endif
