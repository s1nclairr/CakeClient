#ifndef LIB_RAYTRACE
#define LIB_RAYTRACE

// =============================================================================
//  Screen space ray tracing against a depth buffer.
//  traceReflection: long rays marched in screen space (SSR).
//  traceShort:      short rays marched in view space (AO, GI, contact shadows).
// =============================================================================

// Returns true on a hit; hitPos = (uv, depth) of the hit.
bool traceReflection(sampler2D depthTex, vec3 viewPos, vec3 rayDir, float dither, int steps, out vec3 hitPos) {
    hitPos = vec3(0.0);

    // Keep the end point in front of the near plane.
    float rayLength = max(far, 256.0);
    if (rayDir.z > 0.0) rayLength = min(rayLength, (-near - viewPos.z) / rayDir.z * 0.95);
    if (rayLength <= 0.0) return false;

    vec3 start = viewToScreen(viewPos);
    vec3 end = viewToScreen(viewPos + rayDir * rayLength);
    vec3 delta = end - start;

    // Clip the segment to the screen so every step is spent on visible pixels.
    float tMax = 1.0;
    if (delta.x > 0.0) tMax = min(tMax, (1.0 - start.x) / delta.x);
    else if (delta.x < 0.0) tMax = min(tMax, -start.x / delta.x);
    if (delta.y > 0.0) tMax = min(tMax, (1.0 - start.y) / delta.y);
    else if (delta.y < 0.0) tMax = min(tMax, -start.y / delta.y);
    if (delta.z > 0.0) tMax = min(tMax, (1.0 - start.z) / delta.z);
    delta *= tMax;

    float tPrev = 0.0;
    float zPrev = linearizeDepth(start.z);
    for (int i = 0; i < steps; i++) {
        // Step growth: fine near the surface, coarser far away.
        float f = (float(i) + dither) / float(steps);
        float t = f * (0.3 + 0.7 * f);
        vec3 p = start + delta * t;
        float sceneDepth = textureLod(depthTex, p.xy, 0.0).r;
        float rayZ = linearizeDepth(p.z);

        if (sceneDepth < p.z && sceneDepth > HAND_DEPTH_LIMIT) {
            float sceneZ = linearizeDepth(sceneDepth);
            // The ray may only have entered the surface during this step. Anything deeper
            // means it is passing behind an object, which must not be reflected (that is
            // what smears objects into long streaks).
            if (rayZ - sceneZ < abs(rayZ - zPrev) + 0.2 + 0.02 * rayZ) {
                float lo = tPrev;
                float hi = t;
                for (int j = 0; j < 6; j++) {
                    float mid = 0.5 * (lo + hi);
                    vec3 q = start + delta * mid;
                    if (textureLod(depthTex, q.xy, 0.0).r < q.z) hi = mid;
                    else lo = mid;
                }
                vec3 hit = start + delta * hi;
                float hitDepth = textureLod(depthTex, hit.xy, 0.0).r;
                // Accept only if the refined point really lies on the surface.
                float error = abs(linearizeDepth(hit.z) - linearizeDepth(hitDepth));
                if (hitDepth < 1.0 && error < 0.12 + 0.025 * rayZ) {
                    hitPos = hit;
                    return true;
                }
            }
        }
        tPrev = t;
        zPrev = rayZ;
    }
    return false;
}

// Fade reflections out near the screen border, where the data ends.
float screenEdgeFade(vec2 uv) {
    vec2 d = min(uv, 1.0 - uv);
    return smoothstep(0.0, 0.08, min(d.x, d.y));
}

// Returns the hit distance fraction (0..1), or -1 when nothing was hit.
float traceShort(sampler2D depthTex, vec3 viewPos, vec3 rayDir, float rayLength, float jitter,
                 int steps, float thickness, out vec3 hitScreen) {
    hitScreen = vec3(0.0);
    for (int i = 0; i < steps; i++) {
        float f = (float(i) + jitter) / float(steps);
        vec3 p = viewPos + rayDir * (rayLength * f);
        if (p.z > -near) break;
        vec3 s = viewToScreen(p);
        if (s.x < 0.0 || s.x > 1.0 || s.y < 0.0 || s.y > 1.0) break;
        float sceneDepth = textureLod(depthTex, s.xy, 0.0).r;
        if (sceneDepth < HAND_DEPTH_LIMIT) continue;
        float sceneZ = linearizeDepth(sceneDepth);
        float rayZ = -p.z;
        float behind = rayZ - sceneZ;
        if (behind > 0.02 + 0.004 * rayZ && behind < thickness) {
            hitScreen = vec3(s.xy, sceneDepth);
            return f;
        }
    }
    return -1.0;
}

#endif
