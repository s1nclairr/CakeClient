#ifndef LIB_MATERIAL
#define LIB_MATERIAL

// =============================================================================
//  Material ids. block.properties / item.properties use (10000 + id).
// =============================================================================

#define MAT_DEFAULT       0
#define MAT_WATER         1
#define MAT_PLANT        10
#define MAT_PLANT_LOWER  11
#define MAT_PLANT_UPPER  12
#define MAT_LEAVES       13
#define MAT_VINE         14
#define MAT_EMISSIVE     30
#define MAT_FIRELIGHT    31
#define MAT_LAVA         32
#define MAT_FIRE         33
#define MAT_SOULLIGHT    34
#define MAT_GLOW_PARTIAL 35
#define MAT_PORTAL       36
#define MAT_HANGING_LIGHT 37
#define MAT_HANGING_SOUL 38
#define MAT_METAL        40
#define MAT_POLISHED     41
#define MAT_GEM          42
#define MAT_GLASS        43
#define MAT_GLOSSY       44
#define MAT_POROUS       50
#define MAT_END_PORTAL   61
#define MAT_END_GATEWAY  62
#define MAT_WOOD         51
#define MAT_DYNAMIC     200

// Convert a raw properties id into a material id.
int materialFromId(float rawId) {
    int id = int(rawId + 0.5) - 10000;
    return (id < 0 || id > 255) ? MAT_DEFAULT : id;
}

bool isFoliage(int id) {
    return id >= MAT_PLANT && id <= MAT_VINE;
}

// Lanterns hanging from a ceiling or a chain: they swing like a pendulum.
bool isHangingLight(int id) {
    return id == MAT_HANGING_LIGHT || id == MAT_HANGING_SOUL;
}

// Everything the vertex stage animates with wind.
bool isWaving(int id) {
    return isFoliage(id) || isHangingLight(id);
}

bool isHotMaterial(int id) {
    return id == MAT_LAVA || id == MAT_FIRE;
}

// Derive emission / smoothness / metalness from the id and the (sRGB) texture color.
void getMaterial(int id, vec3 albedo, out float emission, out float smoothness, out float metalness) {
    emission = 0.0;
    smoothness = 0.0;
    metalness = 0.0;

    float lum = dot(albedo, vec3(0.2126, 0.7152, 0.0722));
    float peak = max(albedo.r, max(albedo.g, albedo.b));

    if (id == MAT_EMISSIVE) {
        emission = 0.35 + 0.65 * lum * lum;
    } else if (id == MAT_FIRELIGHT || id == MAT_HANGING_LIGHT) {
        // Only the bright, warm texels glow (flame, lantern glass), not the holder.
        emission = smoothstep(0.5, 0.9, peak) * smoothstep(-0.05, 0.15, albedo.r - albedo.b);
    } else if (id == MAT_LAVA) {
        emission = 0.55 + 0.45 * lum;
    } else if (id == MAT_FIRE) {
        emission = 0.3 + 0.7 * peak;
    } else if (id == MAT_SOULLIGHT || id == MAT_HANGING_SOUL) {
        emission = smoothstep(0.5, 0.9, peak) * smoothstep(-0.05, 0.15, albedo.b - albedo.r);
    } else if (id == MAT_GLOW_PARTIAL) {
        emission = smoothstep(0.55, 0.95, peak) * 0.8;
    } else if (id == MAT_PORTAL) {
        emission = 0.4 + 0.4 * lum;
    } else if (id == MAT_METAL) {
        smoothness = 0.78;
        metalness = 1.0;
    } else if (id == MAT_POLISHED) {
        smoothness = 0.5;
    } else if (id == MAT_GLOSSY) {
        // Obsidian and the like: a soft highlight from the sun or moon, but stays below the
        // smoothness at which a surface starts to mirror its surroundings.
        smoothness = 0.26;
    } else if (id == MAT_GEM) {
        // Diamond, emerald, lapis: glossy but not metallic, so they keep their own color.
        smoothness = 0.68;
    }
}

// How strongly a material soaks up rain (darkens more, shines less).
float materialPorosity(int id) {
    if (id == MAT_POROUS) return 0.9;
    if (id == MAT_WOOD) return 0.7;
    if (id == MAT_METAL || id == MAT_POLISHED || id == MAT_GEM || id == MAT_GLOSSY) return 0.05;
    if (isFoliage(id)) return 0.3;
    if (id >= MAT_DYNAMIC) return 0.2;
    return 0.45;
}

#endif
