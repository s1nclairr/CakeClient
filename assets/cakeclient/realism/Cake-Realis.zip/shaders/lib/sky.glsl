#ifndef LIB_SKY
#define LIB_SKY

// =============================================================================
//  Sky lookup. The prepare pass renders a sky-view LUT (atmospheric scattering)
//  into the lower left corner of colortex6, plus four texels with light colors.
//  Everything else (sky pixels, reflections, fog, clouds) samples it from here.
// =============================================================================

#include "/lib/noise.glsl"

uniform sampler2D colortex6;

// Direction -> LUT coordinate. U is the azimuth relative to the sun (mirrored),
// V is the elevation with extra resolution around the horizon.
vec2 skyLutCoord(vec3 dir, vec3 sunDir) {
    vec2 s = sunDir.xz;
    float sl = length(s);
    s = sl > 1e-4 ? s / sl : vec2(1.0, 0.0);
    vec2 d = dir.xz;
    float dl = length(d);
    d = dl > 1e-5 ? d / dl : s;
    float u = acos(clamp(dot(d, s), -1.0, 1.0)) / PI;
    float el = asin(clamp(dir.y, -1.0, 1.0));
    float v = 0.5 + 0.5 * sign(el) * sqrt(abs(el) / (0.5 * PI));
    return vec2(u, v);
}

// Sky radiance for a world space direction (no sun / moon disk, no stars).
// Bilinear filtering is done by hand so the result does not depend on the
// sampler state of the buffer.
vec3 sampleSky(vec3 dir, vec3 sunDir) {
    vec2 px = skyLutCoord(dir, sunDir) * vec2(float(SKY_LUT_W - 1), float(SKY_LUT_H - 1));
    ivec2 p0 = ivec2(floor(px));
    ivec2 p1 = min(p0 + 1, ivec2(SKY_LUT_W - 1, SKY_LUT_H - 1));
    vec2 f = px - vec2(p0);
    vec3 bottom = mix(texelFetch(colortex6, p0, 0).rgb, texelFetch(colortex6, ivec2(p1.x, p0.y), 0).rgb, f.x);
    vec3 top = mix(texelFetch(colortex6, ivec2(p0.x, p1.y), 0).rgb, texelFetch(colortex6, p1, 0).rgb, f.x);
    return mix(bottom, top, f.y);
}

vec3 lightTexel(int index) {
    return texelFetch(colortex6, ivec2(index, SKY_LUT_H + 2), 0).rgb;
}

// Light colors are stored divided by PI: a white diffuse surface facing the
// light has exactly this radiance.
vec3 getSunColor()     { return lightTexel(0); }
vec3 getMoonColor()    { return lightTexel(1); }
vec3 getDirectColor()  { return lightTexel(2); }  // whichever light casts shadows
vec3 getAmbientColor() { return lightTexel(3); }  // sky irradiance on flat ground

#if defined OVERWORLD && defined AURORA
// Northern lights. The sky is sliced into layers of increasing altitude; every layer
// samples the same horizontal "curtain map" (thin ridges of a slowly warping noise
// field), so a ridge becomes a vertical curtain that converges towards the zenith, with
// fine rays running along it. Color follows altitude: green base, teal, violet crown.
vec3 renderAurora(vec3 dir, float dither) {
    float t = frameTimeCounter;
    vec3 sum = vec3(0.0);
    for (int i = 0; i < AURORA_STEPS; i++) {
        float f = (float(i) + dither) / float(AURORA_STEPS);
        float altitude = 1.0 + 1.7 * f;
        vec2 p = dir.xz * (altitude / dir.y) + cameraPosition.xz * 0.0004;

        // Where the display is active at all: large drifting patches.
        float patches = smoothstep(0.38, 0.72, noise2D(p * 0.8 + vec2(t * 0.006, 3.0)));
        if (patches <= 0.0) continue;

        // Curtains: a warped field whose ridges are the folds of the aurora.
        vec2 q = p * 2.2;
        q += (vec2(noise2D(q * 0.7 + t * 0.02), noise2D(q * 0.7 + 9.0 - t * 0.017)) - 0.5) * 1.7;
        float n = noise2D(vec2(q.x * 2.0, q.y * 0.5) + vec2(t * 0.03, 0.0));
        float ridge = pow(1.0 - abs(n * 2.0 - 1.0), 8.0);

        // Fine rays along the curtain, shimmering.
        float rays = 0.5 + 0.5 * noise2D(vec2(q.x * 26.0 + q.y * 9.0, t * 0.4));

        vec3 tint = mix(vec3(0.12, 1.0, 0.42), vec3(0.1, 0.7, 0.8), smoothstep(0.0, 0.5, f));
        tint = mix(tint, vec3(0.55, 0.18, 0.85), smoothstep(0.45, 1.0, f));
        // Brightest just above the lower edge, fading upwards.
        float profile = smoothstep(0.0, 0.07, f) * exp(-f * 1.8);
        sum += tint * (ridge * patches * rays * profile);
    }
    float aboveHorizon = smoothstep(0.06, 0.3, dir.y);
    return sum * (aboveHorizon * 1.5 * AURORA_BRIGHTNESS / float(AURORA_STEPS));
}
#endif

// Full sky: LUT + sun disk + moon with phases + stars.
vec3 renderSky(vec3 dir, vec3 sunDir, vec3 moonDir) {
    vec3 sky = sampleSky(dir, sunDir);

#ifdef OVERWORLD
    float clearSky = 1.0 - rainStrength;
    float aboveHorizon = smoothstep(-0.01, 0.03, dir.y);
    float day = smoothstep(-0.1, 0.1, sunDir.y);

    // The sun. Seen through air and an eye or a lens, it never has a crisp outline: the
    // disc is burnt out and melts into its own glare. So no hard edge here - a bright
    // core that falls off smoothly, a tight aureole and a wide, faint veil around it.
    float sunRadius = 0.019 * SUN_SIZE;
    float sunAngleTo = acos(clamp(dot(dir, sunDir), -1.0, 1.0));
    float sunT = sunAngleTo / sunRadius;
    if (sunT < 14.0) {
        float core = 1.0 - smoothstep(0.35, 1.25, sunT);
        float aureole = exp(-sunT * sunT * 0.22) * 0.22;
        float veil = exp(-sunT * 0.75) * 0.035;
        sky += getSunColor() * 60.0 * (core + aureole + veil) * aboveHorizon * clearSky;
    }

    // Moon: a shaded sphere so the phase terminator is correct.
    float moonRadius = 0.028;
    float moonAngleTo = acos(clamp(dot(dir, moonDir), -1.0, 1.0));
    if (moonAngleTo < moonRadius) {
        vec3 helper = abs(moonDir.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
        vec3 tx = normalize(cross(helper, moonDir));
        vec3 ty = cross(moonDir, tx);
        vec2 p = vec2(dot(dir, tx), dot(dir, ty)) / moonRadius;
        float r2 = min(dot(p, p), 1.0);
        vec3 n = vec3(p, sqrt(1.0 - r2));
        float phase = float(moonPhase) * (TAU / 8.0);
        vec3 l = vec3(sin(phase), 0.0, cos(phase));
        float lit = smoothstep(-0.05, 0.2, dot(n, l));
        float craters = 0.7 + 0.3 * noise2D(p * 5.0 + 23.0) * noise2D(p * 11.0 + 5.0) * 2.0;
        float edge = 1.0 - smoothstep(0.88, 1.0, r2);
        vec3 moonSurface = vec3(0.86, 0.9, 1.0) * (lit * craters + 0.02);
        sky += moonSurface * 0.4 * edge * aboveHorizon * clearSky * (1.0 - 0.85 * day) * MOON_BRIGHTNESS;
    }

#ifdef STARS
    float night = 1.0 - smoothstep(-0.14, 0.02, sunDir.y);
    if (night > 0.0 && dir.y > 0.0) {
        // Rotate with the celestial sphere so stars travel across the night.
        float a = sunAngle * TAU;
        float ca = cos(a);
        float sa = sin(a);
        vec3 sd = vec3(dir.x * ca + dir.y * sa, dir.y * ca - dir.x * sa, dir.z);
        float visibility = STAR_BRIGHTNESS * night * clearSky * smoothstep(0.0, 0.2, dir.y);

        // Bright stars: few, large, twinkling, slightly colored.
        vec3 p = sd * 160.0;
        float h = hash13(floor(p));
        if (h > 0.9955) {
            float d = length(fract(p) - 0.5);
            float core = smoothstep(0.32, 0.0, d);
            float bright = pow2((h - 0.9955) / 0.0045);
            float twinkle = 0.75 + 0.25 * sin(frameTimeCounter * 4.0 + h * 800.0);
            vec3 tint = mix(vec3(1.0, 0.85, 0.7), vec3(0.75, 0.85, 1.0), fract(h * 91.7));
            sky += tint * core * core * (0.15 + 0.85 * bright) * twinkle * 1.0 * visibility;
        }

        // Faint stars: many small points, concentrated along the band of the Milky Way.
        float band = exp(-pow2(dot(sd, vec3(0.35, 0.3, 0.887)) * 3.2));
        vec3 p2 = sd * 420.0;
        float h2 = hash13(floor(p2));
        if (h2 > 0.985 - 0.02 * band) {
            float d2 = length(fract(p2) - 0.5);
            sky += vec3(0.85, 0.9, 1.0) * pow2(smoothstep(0.4, 0.0, d2)) * fract(h2 * 57.3) * 0.3 * visibility;
        }
        // The unresolved glow of the Milky Way itself.
        float dust = noise2D(sd.xy * 6.0 + sd.z * 3.0) * noise2D(sd.zx * 13.0 + 4.0);
        sky += vec3(0.55, 0.6, 0.8) * (band * (0.25 + dust * 1.5) * 0.006 * visibility);

#ifdef SHOOTING_STARS
        // Shooting stars: time is cut into 5 second slots; in some of them a meteor crosses
        // a random part of the sky in under a second, with a tail that fades behind it.
        float slot = floor(frameTimeCounter / 5.0);
        vec3 meteor = hash32(vec2(slot, 17.0));
        float life = fract(frameTimeCounter / 5.0) / 0.16;
        if (meteor.x < 0.45 && life < 1.0) {
            float azimuth = meteor.y * TAU;
            float elevation = 0.4 + 0.8 * meteor.z;
            vec3 start = vec3(cos(azimuth) * cos(elevation), sin(elevation), sin(azimuth) * cos(elevation));
            vec3 side = normalize(cross(start, vec3(0.0, 1.0, 0.0)));
            vec3 up = normalize(vec3(0.0, 1.0, 0.0) - start * start.y);
            vec3 travel = normalize(side * (meteor.x / 0.45 * 2.0 - 1.0) * 1.2 - up);
            vec3 head = normalize(start + travel * (life * 0.35));
            vec3 v = dir - head;
            float behind = dot(v, -travel);
            float tail = 0.03 + 0.1 * sin(PI * life);
            if (behind > 0.0 && behind < tail) {
                float across = length(v + travel * behind);
                float streak = pow2(1.0 - behind / tail) * (1.0 - smoothstep(0.0, 0.0028, across));
                sky += vec3(0.85, 0.93, 1.0) * (streak * sin(PI * life) * 2.5 * night * clearSky);
            }
        }
#endif
    }

#endif

    // Soft glow around the moon (forward scattering in the night haze).
    sky += getMoonColor() * (min(phaseHG(dot(dir, moonDir), 0.92), 30.0) * 0.006 * aboveHorizon);
#endif

#ifdef END
    // Static star field over the void.
    vec3 p = dir * 120.0;
    float h = hash13(floor(p));
    if (h > 0.993) {
        float d = length(fract(p) - 0.5);
        sky += vec3(0.8, 0.7, 1.0) * pow2(smoothstep(0.3, 0.0, d)) * 0.5;
    }
    // Nebula: slowly drifting clouds of violet and teal gas all around the islands.
    float t = frameTimeCounter * 0.004;
    float gas = noise3D(dir * 2.6 + vec3(t, 0.0, -t)) * 0.6 + noise3D(dir * 6.5 + 7.0 - t) * 0.4;
    float filaments = 1.0 - abs(noise3D(dir * 11.0 + 3.0) * 2.0 - 1.0);
    float nebula = pow2(saturate((gas - 0.38) * 2.2)) * (0.6 + 0.4 * filaments);
    vec3 nebulaColor = mix(vec3(0.42, 0.12, 0.7), vec3(0.06, 0.4, 0.45), noise3D(dir * 1.4 + 11.0));
    // Slow flares deep inside the gas.
    float flare = pow2(noise3D(dir * 3.0 + vec3(0.0, frameTimeCounter * 0.05, 0.0)));
    sky += nebulaColor * (nebula * (0.1 + 0.12 * flare));

#ifdef END_STAR
    // The dark star: a black disc in an eclipse-like corona, hanging where the light of
    // the End comes from (sunDir is the shadow light direction in this dimension).
    float starAngle = acos(clamp(dot(dir, sunDir), -1.0, 1.0));
    const float starRadius = 0.075;
    float outside = max(starAngle - starRadius, 0.0);
    float disc = 1.0 - smoothstep(starRadius * 0.94, starRadius, starAngle);
    // Kept dim on purpose: a thin violet rim and a faint halo, not a sun.
    vec3 corona = vec3(0.5, 0.32, 0.9) * (exp(-outside * 26.0) * 0.32 + exp(-outside * 6.0) * 0.05)
                + vec3(0.8, 0.65, 1.0) * (exp(-pow2((starAngle - starRadius * 1.03) * 220.0)) * 0.5);
    sky = sky * (1.0 - disc) + corona * (1.0 - disc);
#endif
#endif

    return sky;
}

#endif
