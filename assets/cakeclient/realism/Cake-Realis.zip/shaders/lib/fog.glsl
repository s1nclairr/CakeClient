#ifndef LIB_FOG
#define LIB_FOG

// =============================================================================
//  Fog model. Two media are combined:
//    air  - uniform haze (distance fog / aerial perspective)
//    low  - exponential height fog hugging the terrain
//  Their densities react to rain, time of day (morning mist, night haze) and
//  biome humidity. composite.glsl integrates them analytically or ray marches
//  them through the shadow map for volumetric light.
// =============================================================================

const float FOG_HEIGHT_FALLOFF = 22.0;

// x = air density, y = ground fog density at sea level (per block).
vec2 fogDensities() {
    float rain = rainStrength;
    // Mist forms before sunrise and burns off during the morning.
    float morning = max(smoothstep(0.90, 1.0, sunAngle), 1.0 - smoothstep(0.0, 0.10, sunAngle));
    float night = smoothstep(0.52, 0.60, sunAngle) * (1.0 - smoothstep(0.90, 0.98, sunAngle));
    float outdoors = smoothstep(0.0, 0.35, eyeSkyExposure());

    float air = 0.00045 * (1.0 + 2.5 * rain);
    float low = 0.0009
              + 0.0075 * MORNING_FOG * morning
              + 0.0016 * night
              + 0.0045 * rain
              + 0.0025 * biomeHumidity;
    return vec2(air, low) * (FOG_DENSITY * outdoors);
}

float fogDensityAt(float worldY, vec2 densities) {
    float h = max(worldY - SEA_LEVEL, -FOG_HEIGHT_FALLOFF);
    return densities.x + densities.y * exp(-h / FOG_HEIGHT_FALLOFF);
}

// Analytic optical depth along a ray through both media.
float fogOpticalDepth(float startY, float dirY, float dist, vec2 densities) {
    float h = max(startY - SEA_LEVEL, -FOG_HEIGHT_FALLOFF);
    float k = max(dirY * dist / FOG_HEIGHT_FALLOFF, -30.0);
    float integral = abs(k) > 1e-3 ? (1.0 - exp(-k)) / k : 1.0 - 0.5 * k;
    return densities.x * dist + densities.y * exp(-h / FOG_HEIGHT_FALLOFF) * dist * integral;
}

// Fraction of direct light scattered towards the camera (forward peak = god rays).
float fogPhase(float cosTheta) {
    return 0.25 * mix(1.0, phaseHG(cosTheta, 0.72), 0.6) * VL_STRENGTH;
}

#endif
