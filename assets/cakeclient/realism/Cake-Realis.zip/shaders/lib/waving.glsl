#ifndef LIB_WAVING
#define LIB_WAVING

// =============================================================================
//  Wind animation for plants, leaves, hanging plants and hanging lanterns
//  (vertex stage; also used by the shadow pass so shadows move with the geometry).
// =============================================================================

#include "/lib/material.glsl"

// midBlock = vector from the vertex to the center of its block (at_midBlock / 64).
vec3 wavingOffset(vec3 worldPos, int id, bool isTopVertex, float skyLight, vec3 midBlock) {
    float t = frameTimeCounter;
    // Sheltered places (indoors, caves) only get a light draught; storms push harder.
    float shelter = 0.25 + 0.75 * smoothstep(0.1, 0.7, skyLight);
    // Solid shapes (leaf blocks, lanterns) must move as one piece. Their faces carry
    // different light values at the very same corner, so a light dependent strength would
    // pull the faces apart and leave fins sticking out along the edges.
    if (id == MAT_LEAVES) shelter = 1.0;
    else if (isHangingLight(id)) shelter = 0.7;
    float wind = WIND_STRENGTH * (1.0 + 1.2 * rainStrength) * shelter;

#ifdef WAVING_LANTERNS
    if (isHangingLight(id)) {
        // Rigid pendulum: every vertex is rotated around the attachment point at the top
        // of the block, so the lantern keeps its shape instead of being sheared.
        vec3 center = worldPos + midBlock;
        vec3 arm = worldPos - (center + vec3(0.0, 0.5, 0.0));
        float phase = center.x * 1.7 + center.z * 2.3 + center.y * 0.9;
        float strength = min(wind, 2.0);
        // Swing angles (radians) around the two horizontal axes; the slow second term is
        // the wind pushing the lantern off center.
        float a = (sin(t * 2.1 + phase) * 0.06 + sin(t * 0.6 + phase * 0.6) * 0.035) * strength;
        float b = (sin(t * 1.8 + phase * 1.3 + 1.7) * 0.045 + sin(t * 0.5 + phase) * 0.03) * strength;
        float ca = cos(a);
        float sa = sin(a);
        vec3 r = vec3(arm.x * ca - arm.y * sa, arm.x * sa + arm.y * ca, arm.z);
        float cb = cos(b);
        float sb = sin(b);
        r = vec3(r.x, r.y * cb - r.z * sb, r.y * sb + r.z * cb);
        return r - arm;
    }
#endif

    float amount = 0.0;
#ifdef WAVING_PLANTS
    if (id == MAT_PLANT && isTopVertex) amount = 1.0;
    else if (id == MAT_PLANT_LOWER && isTopVertex) amount = 0.6;
    else if (id == MAT_PLANT_UPPER) amount = isTopVertex ? 1.4 : 0.6;
    else if (id == MAT_VINE) amount = 0.9;
#endif
#ifdef WAVING_LEAVES
    if (id == MAT_LEAVES) amount = 0.6;
#endif
    if (amount <= 0.0) return vec3(0.0);

    float gust = 0.5 + 0.5 * sin(t * 0.35 + worldPos.x * 0.04 + worldPos.z * 0.03);

    vec3 offset;
    offset.x = sin(t * 1.7 + worldPos.x * 1.3 + worldPos.z * 0.7 + worldPos.y * 0.5) * 0.05
             + sin(t * 0.8 + worldPos.z * 0.35) * 0.09 * gust;
    offset.z = cos(t * 1.4 + worldPos.z * 1.1 - worldPos.x * 0.6) * 0.05
             + sin(t * 0.65 + worldPos.x * 0.3) * 0.07 * gust;
    offset.y = id == MAT_LEAVES ? sin(t * 1.9 + worldPos.x * 2.0 + worldPos.z * 1.7) * 0.03
                                : -0.3 * length(offset.xz);
    return offset * (amount * wind);
}

#endif
