#ifndef LIB_WETNESS
#define LIB_WETNESS

// =============================================================================
//  Rain wetness, puddles and wall drips, applied to the gbuffer in the deferred
//  passes. Stages as the "wetness" uniform rises:
//    dry -> damp (darker) -> wet (slight gloss) -> standing water (puddles).
//  "wetness" follows the rain with wetnessHalflife / drynessHalflife, so the
//  world soaks gradually and dries slowly after the rain stops.
// =============================================================================

#include "/lib/noise.glsl"
#include "/lib/material.glsl"
#include "/lib/water.glsl"

// How wet the world is at a fragment (0 under a roof, in dry biomes, in caves).
// The rule depends only on the surface itself, never on the camera:
//   level 15 (1.0)   open sky                      -> wet
//   level 14 (0.933) first block under an eave     -> wet (wind carries rain there)
//   level 13 (0.867) second block in               -> patchy, breaks up into blotches
//   level 12 and below                             -> dry
// A world space noise shifts the threshold, so the border is an irregular fringe
// instead of a straight line along block edges.
float surfaceWetness(float skyLight, vec3 worldPos) {
#if defined OVERWORLD && defined WET_SURFACES
    float fringe = noise2D(worldPos.xz * 0.9 + worldPos.y * 0.37) * 0.6 + noise2D(worldPos.xz * 2.7 + 5.0) * 0.4;
    float exposed = smoothstep(0.84, 0.95, skyLight + (fringe - 0.5) * 0.08);
    return wetness * (1.0 - biomeNoRain) * exposed;
#else
    return 0.0;
#endif
}

// One layer of drops running down a wall.
// uv = (distance along the wall, world height), both in blocks.
// Returns x: water coverage, yz: surface slope (along the wall, up).
vec3 wallDripLayer(vec2 uv, float columns, float rate, float seed) {
    const float rows = 1.3;
    float cx = uv.x * columns;
    float column = floor(cx);
    vec2 rnd = hash22(vec2(column, seed));

    // Every column has its own speed; adding time to the height moves the pattern down.
    float y = uv.y * rows + frameTimeCounter * (0.12 + 0.3 * rnd.x) + rnd.y * 31.0;
    float row = floor(y);
    float fy = fract(y);
    vec2 rnd2 = hash22(vec2(column + seed * 7.0, row));
    if (rnd2.x > rate) return vec3(0.0);

    // Offsets in blocks from the drop head, which sits low in its cell.
    float wobble = sin(y * 5.0 + rnd2.y * 20.0) * 0.07;
    float dx = (fract(cx) - 0.5 - (rnd2.y - 0.5) * 0.45 - wobble) / columns;
    float dy = (fy - 0.16) / rows;

    // Teardrop: round and heavy at the bottom, tapering into the trail above.
    float radius = (0.17 + 0.1 * rnd2.x / max(rate, 0.01)) / columns;
    float taper = dy > 0.0 ? 0.55 : 1.0;
    float head = 1.0 - smoothstep(radius * 0.5, radius, length(vec2(dx, dy * taper)));

    // The trail the drop left behind: a thin wet line right above the head that breaks
    // up into separate beads further up, where the film has already pulled apart.
    float trailWidth = radius * 0.42;
    float along = smoothstep(0.16, 0.22, fy) * (1.0 - smoothstep(0.3, 0.95, fy));
    float beads = mix(1.0, smoothstep(0.35, 0.65, fract(fy * 9.0 + rnd2.y * 5.0)), smoothstep(0.3, 0.6, fy));
    float trail = (1.0 - smoothstep(trailWidth * 0.4, trailWidth, abs(dx))) * along * beads;

    vec2 slope = vec2(dx, dy * taper) / radius * head + vec2(dx / trailWidth, 0.0) * trail * 0.4;
    return vec3(max(head, trail * 0.55), slope);
}

// Small drops clinging to the wall: they swell slowly and vanish when a runner takes them.
vec3 wallBeads(vec2 uv, float rate) {
    vec2 g = uv * 24.0;
    vec3 rnd = hash32(floor(g));
    if (rnd.x > rate) return vec3(0.0);
    float life = fract(frameTimeCounter * 0.035 + rnd.z);
    float radius = 0.08 + 0.15 * life;
    vec2 n = (fract(g) - 0.5 - (rnd.yz - 0.5) * 0.35) / radius;
    float m = 1.0 - smoothstep(0.6, 1.0, dropShape(n, rnd));
    return vec3(m * 0.8, n * m);
}

// All drops on a vertical surface: runners of two sizes plus resting beads, the strongest
// one wins per pixel. Returns x: coverage, yz: slope (along the wall, up).
vec3 wallDrips(vec3 worldPos, vec3 geoNormal, float rate, float dist) {
    vec2 uv = vec2(abs(geoNormal.x) > 0.5 ? worldPos.z : worldPos.x, worldPos.y);
    vec3 drips = wallDripLayer(uv, 10.0, rate, 1.0);
    vec3 fine = wallDripLayer(uv + 3.7, 17.0, rate * 0.9, 2.0);
    if (fine.x > drips.x) drips = fine;
    vec3 resting = wallBeads(uv, rate * 0.7);
    if (resting.x > drips.x) drips = resting;
    return drips * (1.0 - smoothstep(12.0, 22.0, dist));
}

// The small highlight every drop carries near its top.
float dropGlint(vec3 drips) {
    return 1.0 - smoothstep(0.0, 0.3, length(drips.yz - vec2(-0.35, 0.4)));
}

// Modifies the surface in place. Returns the puddle coverage (0..1).
float applyWetness(vec3 worldPos, vec3 geoNormal, float wet, float skyLight, int matId,
                   inout vec3 albedo, inout vec3 normal, inout float smoothness, inout float f0) {
    if (wet < 0.003) return 0.0;

    // Standing water and running drops need rain falling straight onto the surface:
    // open sky only. Dampness alone reaches a little further (see surfaceWetness).
    float openSky = smoothstep(0.945, 0.99, skyLight);

    float porosity = materialPorosity(matId);
    float facingUp = saturate(geoNormal.y);
    bool isStatic = matId < MAT_DYNAMIC;

    float damp = smoothstep(0.0, 0.35, wet);
    float sheen = smoothstep(0.15, 0.7, wet);

    // ---- Puddles ----
    // "region" is a large scale mask: whole areas stay free of standing water.
    // Inside the wet regions a finer noise is compared against a threshold that drops
    // as rain accumulates; the wide smoothstep gives a soft shore instead of a hard edge.
    float puddle = 0.0;
#ifdef RAIN_PUDDLES
    if (isStatic && facingUp > 0.9) {
        float region = smoothstep(0.38, 0.62, noise2D(worldPos.xz * 0.023 + 7.0));
        float n = noise2D(worldPos.xz * 0.11) * 0.65 + noise2D(worldPos.xz * 0.37 + 17.0) * 0.35;
        float level = saturate(wet * PUDDLE_AMOUNT) * region;
        float threshold = mix(0.86, 0.42, level) + porosity * 0.08;
        puddle = smoothstep(threshold, threshold + 0.28, n) * smoothstep(0.3, 0.85, wet) * openSky;
    }
#endif
    // Open water only where the puddle is deep enough; the rim is just soaked ground.
    float water = smoothstep(0.25, 0.75, puddle);

    // ---- Darkening: porous materials soak up water and get darker / more saturated ----
    // Kept moderate: the wet / dry border follows the game's per-block sky light, and a
    // strong contrast would draw ruler-straight edges under eaves and tree crowns.
    float darken = mix(1.0, mix(0.86, 0.66, porosity), max(damp, puddle));
    albedo = pow(albedo, vec3(1.0 + 0.3 * damp * porosity)) * mix(darken, 0.7, water);

    // ---- Thin water film: only a slight gloss outside the puddles ----
    float film = sheen * (0.55 - 0.4 * porosity) * (0.6 + 0.4 * facingUp);
    smoothness = max(smoothness, mix(film, 0.96, water));
    f0 = max(f0, 0.02);

    // ---- Puddle surface: flat water with rain drop rings ----
    if (water > 0.0) {
        vec3 puddleNormal = vec3(0.0, 1.0, 0.0);
#ifdef RAIN_RIPPLES
        vec2 rings = rainRipples(worldPos.xz, rainStrength * 0.3);
        puddleNormal = normalize(vec3(rings.x, 1.0, rings.y));
#endif
        normal = normalize(mix(normal, puddleNormal, water));
    }

    // ---- Rain hitting the top faces: splash dots opening into small rings ----
#ifdef RAIN_RIPPLES
    if (isStatic && facingUp > 0.9 && rainStrength > 0.01 && openSky > 0.0) {
        float range = length(worldPos - cameraPosition);
        if (range < 28.0) {
            vec3 impact = rainImpacts(worldPos.xz)
                        * (rainStrength * openSky * (1.0 - smoothstep(16.0, 28.0, range)) * (1.0 - water));
            normal = normalize(normal + vec3(impact.x, 0.0, impact.y) * 0.6);
            smoothness = max(smoothness, impact.z * 0.9);
            // Splash water catches the sky light and reads as a pale mark on the block.
            albedo *= 1.0 + 0.5 * impact.z;
        }
    }
#endif

    // ---- Walls: drops that run down and leave wet trails ----
#ifdef WALL_DRIPS
    float dist = length(worldPos - cameraPosition);
    float dripRate = 0.5 * max(rainStrength, wet * 0.25) * openSky;
    if (isStatic && abs(geoNormal.y) < 0.5 && dist < 22.0 && dripRate > 0.01) {
        vec3 drips = wallDrips(worldPos, geoNormal, dripRate, dist);

        if (drips.x > 0.0) {
            vec3 tangent = abs(geoNormal.x) > 0.5 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
            normal = normalize(normal + (tangent * drips.y + vec3(0.0, 1.0, 0.0) * drips.z) * 0.7);
            smoothness = max(smoothness, drips.x * 0.95);
            f0 = max(f0, 0.06 * drips.x);
            // Clear water, not a stain: the surface underneath stays visible, only slightly
            // darker (wet), a little brighter at the bottom where the drop gathers light,
            // with one small glint near the top.
            float lens = clamp(drips.z, -1.0, 1.0);
            float glint = dropGlint(drips);
            albedo *= (1.0 - 0.14 * drips.x) * (1.0 - 0.2 * lens * drips.x) * (1.0 + 0.9 * glint);
        }
    }
#endif

    return puddle;
}

// Snowfall slowly dusts everything that faces the sky: first single texels, then patches,
// finally a closed white layer. It melts away the same way after the snow stops (the
// "wetness" uniform does the timing). The pattern is snapped to the 16x16 texel grid of
// the blocks so it reads as part of the textures.
void applySnowCover(vec3 worldPos, vec3 geoNormal, float skyLight, int matId, float emission,
                    inout vec3 albedo, inout float smoothness) {
#if defined OVERWORLD && defined SNOW_COVER
    float amount = wetness * snowyBiome() * smoothstep(0.9, 0.97, skyLight);
    // Plants catch snow whatever way their quads face; leaf blocks mostly on top.
    float facingUp = saturate(geoNormal.y);
    if (matId == MAT_LEAVES) facingUp = max(facingUp, 0.55);
    else if (isFoliage(matId)) facingUp = 0.8;
    if (amount < 0.01 || facingUp < 0.4 || matId >= MAT_DYNAMIC || emission > 0.05) return;

    vec3 texel = floor(worldPos * 16.0 + 0.01) / 16.0;
    float n = noise2D(texel.xz * 0.35 + texel.y * 0.2) * 0.45
            + noise2D(texel.xz * 1.7 + 3.0) * 0.3
            + hash13(texel * 16.0) * 0.25;
    float threshold = 1.0 - amount * 1.15;
    float cover = smoothstep(threshold, threshold + 0.25, n) * smoothstep(0.4, 0.8, facingUp);
    albedo = mix(albedo, vec3(0.74, 0.79, 0.86), cover * 0.92);
    smoothness = mix(smoothness, 0.2, cover);
#endif
}

#endif
