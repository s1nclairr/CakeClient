#ifndef LIB_NOISE
#define LIB_NOISE

// =============================================================================
//  Texture based noise. shaders/textures/noise.png layout (256x256, tiling):
//    R  white noise
//    G  R shifted by 37 texels in X  -> single fetch 3D value noise
//    B  tileable Worley (cellular) noise, 1 = cell center
//    A  independent white noise
// =============================================================================

uniform sampler2D noisetex;

const float NOISE_RES = 256.0;

// Smooth 2D value noise, range 0..1.
float noise2D(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return textureLod(noisetex, (i + f + 0.5) / NOISE_RES, 0.0).r;
}

// Smooth 3D value noise from one fetch (uses the shifted G channel for the next Z slice).
float noise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    vec2 uv = i.xy + vec2(37.0, 0.0) * i.z + f.xy;
    vec2 gr = textureLod(noisetex, (uv + 0.5) / NOISE_RES, 0.0).gr;
    return mix(gr.x, gr.y, f.z);
}

// Tileable cellular noise, p in texture repeats.
float worley2D(vec2 p) {
    return textureLod(noisetex, p, 0.0).b;
}

float fbm2D(vec2 p) {
    return noise2D(p) * 0.5 + noise2D(p * 2.03 + 11.7) * 0.3 + noise2D(p * 4.11 + 47.3) * 0.2;
}

#endif
