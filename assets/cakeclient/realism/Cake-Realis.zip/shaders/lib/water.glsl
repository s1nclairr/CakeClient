#ifndef LIB_WATER
#define LIB_WATER

// =============================================================================
//  Procedural water surface.
//  Waves: a sum of directional trochoid-like waves (exp(sin(x) - 1)) where each
//  octave drags the sample position along its own gradient. This reproduces the
//  sharp crests / wide troughs of Gerstner waves but can be evaluated per pixel.
// =============================================================================

#include "/lib/noise.glsl"

// Normalized wave height (0..1) at a world XZ position.
float waterHeight(vec2 pos, float time, int iterations) {
    float frequency = 0.55;
    float speed = 1.5;
    float weight = 1.0;
    float sum = 0.0;
    float total = 0.0;
    float angle = 0.0;
    for (int i = 0; i < iterations; i++) {
        vec2 dir = vec2(sin(angle), cos(angle));
        float x = dot(dir, pos) * frequency + time * speed;
        float wave = exp(sin(x) - 1.0);
        float slope = wave * cos(x);
        pos -= dir * slope * weight * 0.26;
        sum += wave * weight;
        total += weight;
        weight *= 0.8;
        frequency *= 1.19;
        speed *= 1.07;
        angle += 1232.399963;
    }
    return sum / total;
}

float waterTime() {
    return frameTimeCounter * WAVE_SPEED;
}

// Rain drop rings: slope (XZ) of expanding ripples on a cell grid.
vec2 rippleLayer(vec2 p, float time) {
    vec2 cell = floor(p);
    vec2 f = fract(p) - 0.5;
    vec3 rnd = hash32(cell);
    float life = fract(time + rnd.z);
    vec2 d = f - (rnd.xy - 0.5) * 0.4;
    float r = length(d);
    float wave = (r - life * 0.26) * 55.0;
    float ring = sin(wave) * exp(-wave * wave * 0.08);
    float fade = (1.0 - life) * (1.0 - life) * (1.0 - smoothstep(0.24, 0.3, r));
    return d / max(r, 1e-4) * (ring * fade);
}

vec2 rainRipples(vec2 worldXZ, float strength) {
    float t = frameTimeCounter;
    vec2 slope = rippleLayer(worldXZ * 1.7, t * 1.3)
               + rippleLayer(worldXZ * 2.9 + 13.7, t * 1.7 + 0.37) * 0.7
               + rippleLayer(worldXZ * 4.3 + 41.1, t * 2.1 + 0.71) * 0.5;
    return slope * strength;
}

// Rain drops hitting a hard wet surface: a splash dot at the moment of impact that opens
// into a short lived ring. Returns xy: surface slope, z: how much splash water is there.
vec3 impactLayer(vec2 p, float time) {
    vec2 cell = floor(p);
    vec3 rnd = hash32(cell);
    float life = fract(time + rnd.z);
    vec2 d = fract(p) - 0.5 - (rnd.xy - 0.5) * 0.5;
    float r = length(d);
    float w = (r - (0.03 + life * 0.2)) * 38.0;
    float fade = (1.0 - life) * (1.0 - life);
    float ring = exp(-w * w) * fade;
    float splash = (1.0 - smoothstep(0.0, 0.055, r)) * (1.0 - smoothstep(0.0, 0.12, life));
    return vec3(d / max(r, 1e-4) * (ring * clamp(-w, -1.0, 1.0)), max(ring, splash));
}

vec3 rainImpacts(vec2 worldXZ) {
    float t = frameTimeCounter;
    vec3 a = impactLayer(worldXZ * 2.3, t * 1.9);
    vec3 b = impactLayer(worldXZ * 3.7 + 7.1, t * 2.3 + 0.4);
    return vec3(a.xy + b.xy, max(a.z, b.z));
}

// Wake around the player: rings that spread from the camera position while the player
// wades or swims. offset = water fragment relative to the camera eye (scene space).
//   inWater    0..1, smoothed "the player's feet are in water"
//   velocity   smoothed horizontal velocity of the player (blocks / second)
//   agitation  recent motion in any direction (walking, swimming, jumping in)
// Two parts: rings that spread from the body, and a Kelvin wake behind a moving
// swimmer - the V of two wave arms at about 19.5 degrees to the path, plus churned
// water in between, fading with distance behind.
vec2 playerWake(vec3 offset, float inWater, vec2 velocity, float agitation) {
    if (inWater < 0.01) return vec2(0.0);
    // Only the water surface the player is actually standing or floating in.
    float level = smoothstep(-2.1, -1.5, offset.y) * (1.0 - smoothstep(-0.1, 0.4, offset.y));
    float r = length(offset.xz);
    if (level <= 0.0 || r > 16.0) return vec2(0.0);

    float t = frameTimeCounter;
    vec2 slope = vec2(0.0);

    // Rings around the body: barely there when floating still, strong after a jump.
    float ringAmount = saturate(0.08 + agitation / 4.5) * (1.0 - smoothstep(0.8, 3.8, r)) * smoothstep(0.15, 0.45, r);
    slope += offset.xz / max(r, 1e-3) * (cos(r * 8.0 - t * 8.0) * 0.28 * ringAmount);

    float speed = length(velocity);
    if (speed > 0.25) {
        vec2 heading = velocity / speed;
        vec2 across = vec2(-heading.y, heading.x);
        float behind = dot(offset.xz, -heading);
        float side = dot(offset.xz, across);
        float aside = abs(side);

        float amount = saturate(speed / 3.0) * smoothstep(0.0, 0.8, behind) * exp(-behind / (2.0 + 2.2 * speed)) * 0.3;
        // The two arms of the V.
        float arm = exp(-pow2((aside - 0.36 * behind) / (0.28 + 0.1 * behind)));
        float phase = 8.0 * (behind * 0.35 + aside * 0.94) - t * 5.0;
        vec2 gradient = -heading * 0.35 + across * (side < 0.0 ? -0.94 : 0.94);
        slope += gradient * (cos(phase) * arm * amount);
        // Churned water in the middle of the trail.
        float core = exp(-pow2(aside / (0.25 + 0.05 * behind))) * 0.35;
        slope += across * (sin(behind * 11.0 - t * 3.0 + side * 6.0) * core * amount);
    }

    return slope * (inWater * level);
}

// World space normal of a horizontal water surface.
vec3 waterNormal(vec2 worldXZ, float dist, float rain) {
    // Drop the highest octaves in the distance where they would only alias.
    int iterations = dist < 48.0 ? WATER_WAVE_ITERATIONS
                   : (dist < 160.0 ? (WATER_WAVE_ITERATIONS * 2) / 3 : WATER_WAVE_ITERATIONS / 2);
    float time = waterTime();
    float e = 0.06 + dist * 0.0015;
    float h0 = waterHeight(worldXZ, time, iterations);
    float hx = waterHeight(worldXZ + vec2(e, 0.0), time, iterations);
    float hz = waterHeight(worldXZ + vec2(0.0, e), time, iterations);
    float amplitude = 0.75 * WAVE_HEIGHT;
    vec2 slope = vec2(h0 - hx, h0 - hz) * (amplitude / e);

    // Micro ripples from two scrolling noise layers.
    float detailFade = 1.0 / (1.0 + dist * 0.04);
    vec2 n1 = textureLod(noisetex, worldXZ * 0.021 + time * vec2(0.011, 0.007), 0.0).ra;
    vec2 n2 = textureLod(noisetex, worldXZ * 0.057 - time * vec2(0.009, 0.013), 0.0).ar;
    slope += (n1 + n2 - 1.0) * (0.045 * detailFade * WAVE_HEIGHT);

#ifdef RAIN_RIPPLES
    if (rain > 0.01 && dist < 48.0) {
        slope += rainRipples(worldXZ, rain * 0.35 * (1.0 - dist / 48.0));
    }
#endif

    return normalize(vec3(slope.x, 1.0, slope.y));
}

// Light focusing under the surface: bright under crests, dark under troughs.
float waterCaustics(vec2 worldXZ) {
    float time = waterTime();
    const float e = 0.3;
    const int iterations = 5;
    float h = waterHeight(worldXZ, time, iterations);
    float laplacian = waterHeight(worldXZ + vec2(e, 0.0), time, iterations)
                    + waterHeight(worldXZ - vec2(e, 0.0), time, iterations)
                    + waterHeight(worldXZ + vec2(0.0, e), time, iterations)
                    + waterHeight(worldXZ - vec2(0.0, e), time, iterations) - 4.0 * h;
    laplacian /= e * e;
    float focus = clamp(1.0 - laplacian * 0.9, 0.0, 2.6);
    return mix(1.0, focus * focus * 0.6 + 0.25, saturate(CAUSTICS_STRENGTH * 0.6));
}

#endif
