#ifndef LIB_ATMOSPHERE
#define LIB_ATMOSPHERE

// =============================================================================
//  Physically based atmosphere: single scattering ray march with Rayleigh, Mie
//  and ozone, plus a cheap multiple scattering term. Only the prepare pass runs
//  this (once per LUT texel), so the cost does not depend on screen resolution.
//  Distances are in kilometers to keep 32 bit floats well conditioned.
// =============================================================================

const float ATM_PLANET_RADIUS = 6371.0;
const float ATM_TOP_RADIUS = 6471.0;
const vec3 ATM_RAYLEIGH = vec3(5.802e-3, 13.558e-3, 33.1e-3);
const float ATM_MIE = 3.996e-3;
const float ATM_MIE_EXT = 4.44e-3;
const vec3 ATM_OZONE = vec3(0.650e-3, 1.881e-3, 0.085e-3);
const float ATM_MIE_G = 0.76;
const int ATM_LIGHT_STEPS = 6;

// Sun irradiance at the top of the atmosphere (scene units) and the moon ratio.
const vec3 SUN_IRRADIANCE = vec3(12.6, 12.3, 11.8);
const vec3 MOON_IRRADIANCE = vec3(0.30, 0.40, 0.58);

// Rayleigh, Mie and ozone densities at a height (km) above the ground.
vec3 atmDensity(float h) {
    return vec3(exp(-h / 8.0), exp(-h / 1.2), max(0.0, 1.0 - abs(h - 25.0) / 15.0));
}

vec3 atmExtinction(vec3 density) {
    return ATM_RAYLEIGH * density.x + ATM_MIE_EXT * density.y + ATM_OZONE * density.z;
}

// Camera position in atmosphere space.
vec3 atmCameraPos() {
    return vec3(0.0, ATM_PLANET_RADIUS + 0.1 + max(eyeAltitude, 0.0) * 0.001, 0.0);
}

// Transmittance from a point towards a light, including the planet shadow.
vec3 atmLightTransmittance(vec3 p, vec3 lightDir) {
    vec2 ground = raySphere(p, lightDir, ATM_PLANET_RADIUS);
    if (ground.x > 0.0) return vec3(0.0);
    float tEnd = raySphere(p, lightDir, ATM_TOP_RADIUS).y;
    float dt = tEnd / float(ATM_LIGHT_STEPS);
    vec3 density = vec3(0.0);
    for (int i = 0; i < ATM_LIGHT_STEPS; i++) {
        vec3 q = p + lightDir * (dt * (float(i) + 0.5));
        density += atmDensity(max(length(q) - ATM_PLANET_RADIUS, 0.0));
    }
    return exp(-atmExtinction(density) * dt);
}

// In-scattered radiance along a view ray, lit by both the sun and the moon.
vec3 atmosphere(vec3 dir, vec3 sunDir, vec3 moonDir, vec3 sunE, vec3 moonE, int steps) {
    vec3 origin = atmCameraPos();
    float tMax = raySphere(origin, dir, ATM_TOP_RADIUS).y;
    vec2 ground = raySphere(origin, dir, ATM_PLANET_RADIUS);
    bool hitsGround = ground.x > 0.0;
    if (hitsGround) tMax = ground.x;

    float cosSun = dot(dir, sunDir);
    float cosMoon = dot(dir, moonDir);
    const float isotropic = 1.0 / (4.0 * PI);
    float rayleighSun = 3.0 / (16.0 * PI) * (1.0 + cosSun * cosSun);
    float rayleighMoon = 3.0 / (16.0 * PI) * (1.0 + cosMoon * cosMoon);
    float mieSun = phaseHG(cosSun, ATM_MIE_G) * isotropic;
    float mieMoon = phaseHG(cosMoon, ATM_MIE_G) * isotropic;
    // Light that has already scattered at least once arrives from everywhere.
    const float multiScatter = 0.55 * isotropic;

    vec3 transmittance = vec3(1.0);
    vec3 radiance = vec3(0.0);
    float tPrev = 0.0;

    for (int i = 0; i < steps; i++) {
        // Quadratic distribution: dense samples near the camera.
        float f = (float(i) + 1.0) / float(steps);
        float t = tMax * f * f;
        float dt = t - tPrev;
        vec3 p = origin + dir * (0.5 * (t + tPrev));
        tPrev = t;

        vec3 density = atmDensity(max(length(p) - ATM_PLANET_RADIUS, 0.0));
        vec3 extinction = atmExtinction(density);
        vec3 stepTransmittance = exp(-extinction * dt);

        vec3 scatterR = ATM_RAYLEIGH * density.x;
        float scatterM = ATM_MIE * density.y;
        vec3 scatterAll = scatterR + scatterM;

        vec3 source = sunE * atmLightTransmittance(p, sunDir)
                    * (scatterR * rayleighSun + scatterM * mieSun + scatterAll * multiScatter);
        source += moonE * atmLightTransmittance(p, moonDir)
                * (scatterR * rayleighMoon + scatterM * mieMoon + scatterAll * multiScatter);

        // Analytic integration of the source over the step.
        radiance += transmittance * source * (1.0 - stepTransmittance) / max(extinction, vec3(1e-7));
        transmittance *= stepTransmittance;
    }

    if (hitsGround) {
        // A dim, lit planet surface under the horizon (seen in reflections and the void).
        vec3 groundLight = sunE * atmLightTransmittance(origin, sunDir) * max(sunDir.y, 0.0)
                         + moonE * atmLightTransmittance(origin, moonDir) * max(moonDir.y, 0.0);
        radiance += transmittance * vec3(0.07, 0.08, 0.075) * groundLight / PI;
    }

    // Faint airglow so the night sky never reaches pure black.
    radiance += vec3(0.0006, 0.0009, 0.0018) * transmittance;
    return radiance;
}

// LUT coordinate -> world direction (inverse of skyLutCoord in sky.glsl).
vec3 skyLutDir(vec2 uv, vec3 sunDir) {
    float azimuth = uv.x * PI;
    float l = uv.y * 2.0 - 1.0;
    float elevation = sign(l) * l * l * 0.5 * PI;
    vec2 s = sunDir.xz;
    float sl = length(s);
    s = sl > 1e-4 ? s / sl : vec2(1.0, 0.0);
    vec2 t = vec2(-s.y, s.x);
    vec2 h = s * cos(azimuth) + t * sin(azimuth);
    float ce = cos(elevation);
    return vec3(h.x * ce, sin(elevation), h.y * ce);
}

#endif
