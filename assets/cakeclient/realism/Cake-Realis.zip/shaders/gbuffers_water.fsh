#version 130
#define OVERWORLD
#define FSH
#define PROGRAM_WATER
#include "/program/gbuffers_translucent.glsl"
