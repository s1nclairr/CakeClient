#version 130
#define OVERWORLD
#define VSH
#define PROGRAM_TERRAIN
#include "/program/gbuffers_solid.glsl"
