// =============================================================================
//  Translucent geometry, forward shaded after the deferred passes:
//  water (waves, refraction, absorption, reflections, fresnel, sun glitter),
//  glass / ice / slime (lit, with reflections), translucent entities and hand.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/material.glsl"
#include "/lib/water.glsl"

#ifdef VSH

#ifdef PROGRAM_WATER
in vec4 mc_Entity;
#endif

out vec2 texCoord;
out vec2 lmCoord;
out vec4 tint;
out vec3 worldNormal;
out vec3 scenePos;
flat out int matId;

void main() {
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord = saturate(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 0.03125) * 1.06667);
    tint = gl_Color;
    worldNormal = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    matId = MAT_DYNAMIC;

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    scenePos = (gbufferModelViewInverse * viewPos).xyz;

#ifdef PROGRAM_WATER
    matId = materialFromId(mc_Entity.x);
#ifdef WATER_VERTEX_WAVES
    if (matId == MAT_WATER) {
        // Only the free surface moves; vertices resting on block boundaries stay put.
        vec3 worldPos = scenePos + cameraPosition;
        float isSurface = step(0.1, fract(worldPos.y + 0.001));
        scenePos.y += (waterHeight(worldPos.xz, waterTime(), 4) - 0.5) * 0.18 * WAVE_HEIGHT * isSurface;
        viewPos = gbufferModelView * vec4(scenePos, 1.0);
    }
#endif
#endif

    gl_Position = gl_ProjectionMatrix * viewPos;
#ifdef TEMPORAL_AA
    gl_Position.xy += taaJitter() * gl_Position.w;
#endif
}

#endif

#ifdef FSH

#include "/lib/sky.glsl"
#include "/lib/shadows.glsl"
#include "/lib/lighting.glsl"
#include "/lib/raytrace.glsl"
#include "/lib/clouds.glsl"
#include "/lib/wetness.glsl"

uniform sampler2D gtexture;
uniform sampler2D colortex4;  // lit opaque scene (with sky and clouds)
uniform sampler2D colortex5;  // history; alpha of texels 1..4 holds the player state
uniform sampler2D depthtex1;  // depth without translucents
uniform float alphaTestRef;
uniform vec4 entityColor;

in vec2 texCoord;
in vec2 lmCoord;
in vec4 tint;
in vec3 worldNormal;
in vec3 scenePos;
flat in int matId;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 outColor;
// The gbuffer is no longer needed here, so its material channel is reused as a
// "this pixel is open water" mask for the wet shore in composite. Alpha 1 makes the
// write exact whatever blending is active.
layout(location = 1) out vec4 outMask;

// What a mirror-like surface sees: screen space hit if there is one, otherwise sky and clouds.
vec3 reflectionColor(vec3 viewPos, vec3 normal, vec3 reflected, float skyAccess, float dither,
                     vec3 sunDir, vec3 lightDir, vec3 lightColor, vec3 ambientColor) {
    vec3 result = sampleSky(reflected, sunDir) * skyAccess;

#if defined OVERWORLD && defined VOLUMETRIC_CLOUDS && defined CLOUD_REFLECTIONS
    if (skyAccess > 0.01 && reflected.y > 0.0) {
        vec3 camWorld = cameraPosition + scenePos;
        vec4 clouds = renderCloudsReflection(camWorld, reflected, lightColor, ambientColor, lightDir, result);
        result = result * clouds.a + clouds.rgb * skyAccess;
    }
#endif

#ifdef SSR
    vec3 viewNormal = mat3(gbufferModelView) * normal;
    vec3 viewReflected = mat3(gbufferModelView) * reflected;
    vec3 hit;
    if (traceReflection(depthtex1, viewPos + viewNormal * 0.06, viewReflected, dither, SSR_STEPS, hit)) {
        vec3 hitColor = textureLod(colortex4, hit.xy, 0.0).rgb;
        result = mix(result, hitColor, screenEdgeFade(hit.xy));
    }
#endif

    return result;
}

void main() {
    vec4 texel = texture(gtexture, texCoord);
    vec2 screenUV = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    vec3 viewPos = sceneToView(scenePos);
    float dist = length(viewPos);
    vec3 viewDir = normalize(scenePos - gbufferModelViewInverse[3].xyz);  // camera -> fragment
    float dither = ditherT(gl_FragCoord.xy);

    // Geometric normal, always facing the viewer (water is rendered double sided).
    float normalLength = length(worldNormal);
    vec3 geoNormal = normalLength > 1e-4 ? worldNormal / normalLength : -viewDir;
    if (dot(geoNormal, viewDir) > 0.0) geoNormal = -geoNormal;

    vec3 sunDir = worldSunDir();
    vec3 lightDir = worldLightDir();
    vec3 lightColor = getDirectColor();
    vec3 ambientColor = getAmbientColor();

#ifdef OVERWORLD
    float skyAccess = smoothstep(0.2, 0.9, lmCoord.y);
#else
    float skyAccess = 1.0;
#endif

    vec3 shadow = vec3(1.0);
#if defined DIRECT_LIGHT && defined SHADOWS
    if (maxOf(lightColor) > 1e-4) {
        shadow = getShadow(scenePos, geoNormal, dither, 4);
#if defined CLOUD_SHADOWS && defined VOLUMETRIC_CLOUDS && defined OVERWORLD
        shadow *= cloudShadow(scenePos + cameraPosition, lightDir);
#endif
    }
#elif defined OVERWORLD
    shadow = vec3(skyAccess);
#endif

    if (matId == MAT_WATER) {
        // ======================= WATER =======================
        vec3 worldPos = scenePos + cameraPosition;
        vec3 normal;
        if (abs(geoNormal.y) > 0.5) {
            normal = waterNormal(worldPos.xz, dist, rainStrength * skyAccess);
#ifdef WATER_PLAYER_RIPPLES
            // Smoothed player state kept in the bottom row of the history buffer (composite1).
            vec2 wake = playerWake(scenePos,
                                   texelFetch(colortex5, ivec2(1, 0), 0).a,
                                   vec2(texelFetch(colortex5, ivec2(2, 0), 0).a, texelFetch(colortex5, ivec2(3, 0), 0).a),
                                   texelFetch(colortex5, ivec2(4, 0), 0).a);
            normal = normalize(normal + vec3(wake.x, 0.0, wake.y));
#endif
            if (geoNormal.y < 0.0) normal = -normal;
        } else {
            // Falling water: reuse the wave field on a scrolling vertical sheet.
            vec3 n = waterNormal(vec2(worldPos.x + worldPos.z, worldPos.y * 0.6 + waterTime() * 2.0), dist, 0.0);
            normal = normalize(geoNormal + vec3(n.x, 0.0, n.z) * 0.5);
        }
        // Keep the perturbed normal on the viewer side.
        float facing = dot(normal, -viewDir);
        if (facing < 0.03) normal = normalize(normal - viewDir * (0.03 - facing));
        float NoV = saturate(dot(normal, -viewDir));

        vec3 offsetView = mat3(gbufferModelView) * (normal - geoNormal);
        vec3 scatterLight = lightColor * shadow * 0.25 + ambientColor * skyAccess
                          + blockLightColor() * blockLightFalloff(lmCoord.x) * 0.3;
        vec3 biomeTint = srgbToLinear(tint.rgb);
        biomeTint = mix(vec3(1.0), biomeTint / max(maxOf(biomeTint), 0.05), WATER_VANILLA_TINT);

        vec3 color;

        if (isEyeInWater == 1) {
            // ---- Looking at the surface from below: Snell window + total internal reflection ----
            vec2 uv = screenUV;
#ifdef WATER_REFRACTION
            uv = clamp(screenUV + offsetView.xy * (0.12 * REFRACTION_STRENGTH), 0.002, 0.998);
            if (textureLod(depthtex1, uv, 0.0).r < gl_FragCoord.z) uv = screenUV;
#endif
            vec3 above = textureLod(colortex4, uv, 0.0).rgb;

            vec3 refracted = refract(viewDir, normal, 1.333);
            bool totalReflection = dot(refracted, refracted) < 0.5;
            float fresnel = totalReflection ? 1.0 : fresnelSchlick(0.02, dot(refracted, -normal));
            // Soften the edge of the window.
            float cosCritical = 0.661;
            fresnel = max(fresnel, 1.0 - smoothstep(cosCritical - 0.03, cosCritical + 0.05, NoV));

            vec3 mirrored = waterInscatter(64.0, scatterLight) * biomeTint;
#ifdef SSR
            vec3 hit;
            vec3 viewReflected = mat3(gbufferModelView) * reflect(viewDir, normal);
            vec3 viewNormal = mat3(gbufferModelView) * normal;
            if (traceReflection(depthtex1, viewPos + viewNormal * 0.06, viewReflected, dither, SSR_STEPS, hit)) {
                mirrored = mix(mirrored, textureLod(colortex4, hit.xy, 0.0).rgb, screenEdgeFade(hit.xy));
            }
#endif
            color = mix(above, mirrored, fresnel);
        } else {
            // ---- Looking at the surface from above ----
            vec2 uv = screenUV;
#ifdef WATER_REFRACTION
            uv = clamp(screenUV + offsetView.xy * (0.07 * REFRACTION_STRENGTH / (1.0 + dist * 0.08)), 0.002, 0.998);
            // Do not pull in things that are in front of the water.
            if (textureLod(depthtex1, uv, 0.0).r < gl_FragCoord.z) uv = screenUV;
#endif
            float behindDepth = textureLod(depthtex1, uv, 0.0).r;
            vec3 behind = textureLod(colortex4, uv, 0.0).rgb;
            float waterDepth = max(length(screenToView(uv, behindDepth)) - dist, 0.0);

            // Beer-Lambert absorption (red dies first) plus light scattered inside the water body.
            vec3 body = behind * waterTransmittance(waterDepth) + waterInscatter(waterDepth, scatterLight) * biomeTint;

            vec3 reflected = reflect(viewDir, normal);
            if (geoNormal.y > 0.5) reflected.y = abs(reflected.y);
            vec3 mirrored = reflectionColor(viewPos, normal, reflected, skyAccess, dither,
                                            sunDir, lightDir, lightColor, ambientColor);

            float fresnel = fresnelSchlick(0.02, NoV);
            color = mix(body, mirrored, fresnel);

            // Sun / moon glitter.
            vec3 glint = specularGGX(normal, -viewDir, lightDir, 0.075, vec3(0.02));
            color += min(lightColor * shadow * PI * glint, vec3(50.0));
        }

        outColor = vec4(color, 1.0);
        // Only the level surface soaks a shore, not a waterfall.
        outMask = vec4(0.0, 0.0, abs(geoNormal.y) > 0.5 ? 1.0 : 0.0, 1.0);
    } else {
        // ======================= GLASS, ICE, ENTITIES =======================
        vec4 albedo;
        float ao = 1.0;
#ifdef PROGRAM_WATER
        albedo = vec4(texel.rgb * tint.rgb, texel.a);
        ao = tint.a;
#else
        albedo = texel * tint;
        albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
#endif
        if (albedo.a < max(alphaTestRef, 0.004)) discard;

        float emission;
        float smoothness;
        float metalness;
        getMaterial(matId, albedo.rgb, emission, smoothness, metalness);

        Surface s;
        s.albedo = srgbToLinear(albedo.rgb);
        s.normal = geoNormal;
        s.toView = -viewDir;
        s.dist = dist;
        s.lightmap = lmCoord;
        s.ao = ao;
        s.emission = emission;
        s.metalness = 0.0;
        s.f0 = 0.04;
        s.subsurface = 0.0;
#ifdef PROGRAM_WATER
        s.smoothness = 0.9;
#else
        s.smoothness = 0.0;
#endif

        LightEnv l;
        l.directColor = lightColor;
        l.directDir = lightDir;
        l.ambientColor = ambientColor;
        l.skyColor = ambientColor;
        l.blockTint = vec4(0.0);
        l.shadow = shadow;
        l.indirect = vec3(0.0);

        vec3 color = shadeSurface(s, l);
        float alpha = albedo.a;

        vec3 surfaceNormal = geoNormal;

#if defined PROGRAM_WATER && defined WALL_DRIPS && defined OVERWORLD
        // Rain running down window panes. Glass counts as rained on from both sides (the
        // inner face of a window sits at sky light 14), so the drops are visible from
        // inside the house, where they belong.
        float glassRain = rainStrength * (1.0 - biomeNoRain) * smoothstep(0.8, 0.9, lmCoord.y);
        if (glassRain > 0.01 && abs(geoNormal.y) < 0.5 && dist < 22.0) {
            vec3 drips = wallDrips(scenePos + cameraPosition, geoNormal, 0.5 * glassRain, dist);
            if (drips.x > 0.0) {
                vec3 tangent = abs(geoNormal.x) > 0.5 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
                surfaceNormal = normalize(geoNormal + (tangent * drips.y + vec3(0.0, 1.0, 0.0) * drips.z) * 0.7);
                if (dot(surfaceNormal, -viewDir) < 0.05) surfaceNormal = geoNormal;

                // Water on glass catches the daylight: bright at the bottom of each drop,
                // a faint shadow at the top and one glint.
                float lens = clamp(drips.z, -1.0, 1.0);
                float glint = dropGlint(drips);
                vec3 dropLight = ambientColor * skyAccess + lightColor * shadow * 0.4
                               + blockLightColor() * blockLightFalloff(lmCoord.x) * 0.5;
                color = mix(color, dropLight * (0.5 - 0.3 * lens), 0.5 * drips.x);
                color += dropLight * (1.5 * glint);
                alpha = max(alpha, max(0.3 * drips.x, 0.7 * glint));
            }
        }
#endif

#ifdef PROGRAM_WATER
        // Smooth translucent blocks reflect their surroundings at grazing angles.
        float fresnel = fresnelSchlick(0.04, dot(surfaceNormal, -viewDir));
        vec3 mirrored = reflectionColor(viewPos, surfaceNormal, reflect(viewDir, surfaceNormal), skyAccess, dither,
                                        sunDir, lightDir, lightColor, ambientColor);
        color = mix(color, mirrored, fresnel);
        alpha = mix(alpha, 1.0, fresnel);
#endif

        outColor = vec4(color, alpha);
        outMask = vec4(0.0, 0.0, 0.0, 1.0);
    }
}

#endif
