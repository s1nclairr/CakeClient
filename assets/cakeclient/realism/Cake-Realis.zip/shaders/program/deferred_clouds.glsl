// =============================================================================
//  deferred (clouds): volumetric clouds into their own buffer (colortex10).
//
//  Marching the cloud layer is the most expensive thing the pack does, so it is
//  spread over time: every frame only one pixel of each 2x2 block is marched;
//  the other three reuse last frame's result, reprojected for camera rotation.
//  A full refresh therefore takes four frames, during which clouds barely move.
//  The lighting pass composites this buffer over the sky.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"
#include "/lib/clouds.glsl"

uniform sampler2D colortex10;  // clouds of the previous frame
uniform sampler2D depthtex0;

in vec2 texCoord;

/* RENDERTARGETS: 10 */
layout(location = 0) out vec4 outClouds;  // rgb: in-scattered light, a: transmittance

void main() {
    float depth = texelFetch(depthtex0, ivec2(gl_FragCoord.xy), 0).r;
    outClouds = vec4(0.0, 0.0, 0.0, 1.0);
    // Nothing to do behind the hand.
    if (depth < HAND_DEPTH_LIMIT) return;

    bool isSky = depth >= 1.0;
    vec3 viewPos = screenToView(texCoord, depth);
    vec3 viewDir = normalize(mat3(gbufferModelViewInverse) * viewPos);
    vec3 eyeOffset = gbufferModelViewInverse[3].xyz;

    vec4 history = vec4(0.0, 0.0, 0.0, 1.0);
    bool hasHistory = false;
    bool march = true;

#if defined CLOUD_TEMPORAL && defined TEMPORAL_AA
    // Terrain pixels are always marched: below the layer that exits immediately, and
    // inside it the depth changes too quickly to trust old data.
    if (isSky) {
        // Clouds are far away: reproject a distant point on the view ray, so only the
        // camera rotation (and a little parallax) is taken into account.
        vec3 prev = reprojectScene(eyeOffset + viewDir * 2500.0);
#ifdef TEMPORAL_AA
        // The old buffer was drawn with the old sub-pixel jitter: follow it, otherwise
        // the clouds would be resampled half a pixel off every frame and visibly tremble.
        prev.xy += taaJitterPrevious() * 0.5;
#endif
        if (prev.x > 0.0 && prev.x < 1.0 && prev.y > 0.0 && prev.y < 1.0) {
            history = textureLod(colortex10, prev.xy, 0.0);
            hasHistory = !any(isnan(history));
        }
        const int order[4] = int[4](0, 3, 1, 2);
        ivec2 cell = ivec2(gl_FragCoord.xy) & 1;
        march = !hasHistory || (cell.x + cell.y * 2) == order[frameCounter % 4];
    }
#endif

    if (!march) {
        outClouds = history;
        return;
    }

    vec3 sunDir = worldSunDir();
    vec3 lightDir = worldLightDir();
    vec3 camWorld = cameraPosition + eyeOffset;
    float sceneDist = isSky ? 1e9 : length(viewPos);
#ifdef TEMPORAL_AA
    float dither = ditherT(gl_FragCoord.xy);
#else
    // Without accumulation over frames: a 4x4 ordered pattern, which the lighting pass
    // removes with a 4x4 filter.
    float dither = bayer4(gl_FragCoord.xy);
#endif
    vec4 clouds = renderClouds(camWorld, viewDir, sceneDist, dither,
                               getDirectColor(), getAmbientColor(), lightDir, sampleSky(viewDir, sunDir),
                               CLOUD_STEPS, CLOUD_LIGHT_STEPS);

    // Blend the new march into the old one: averages the step dither over time.
    // A slow blend: one march only nudges the stored value, so the step dither averages
    // out over several refreshes instead of flickering.
    outClouds = hasHistory ? mix(history, clouds, 0.3) : clouds;
}
