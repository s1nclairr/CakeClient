// =============================================================================
//  deferred3 (reflections): reflections on opaque surfaces (puddles, wet ground, polished
//  blocks, metals) and hand-off of the finished opaque scene to colortex4,
//  where the water shader reads it for refraction and its own reflections.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/material.glsl"
#include "/lib/sky.glsl"
#include "/lib/lighting.glsl"
#include "/lib/wetness.glsl"
#include "/lib/raytrace.glsl"

uniform sampler2D colortex0;  // lit scene
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;  // albedo
uniform sampler2D depthtex0;

in vec2 texCoord;

/* RENDERTARGETS: 0,4 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outOpaque;

void main() {
    ivec2 pixel = ivec2(gl_FragCoord.xy);
    vec3 color = texelFetch(colortex0, pixel, 0).rgb;

#ifdef SURFACE_REFLECTIONS
    float depth = texelFetch(depthtex0, pixel, 0).r;
    if (depth < 1.0 && depth > HAND_DEPTH_LIMIT) {
        vec4 g1 = texelFetch(colortex1, pixel, 0);
        vec3 g2 = texelFetch(colortex2, pixel, 0).rgb;
        vec3 g3 = texelFetch(colortex3, pixel, 0).rgb;
        int matId = int(g1.b * 255.0 + 0.5);
        vec3 geoNormal = decodeNormal(g1.rg);
        vec3 normal = geoNormal;
        float smoothness = g3.g;
        float metalness = g3.b;
        float f0 = 0.04;

        vec3 viewPos = screenToView(texCoord, depth);
        vec3 worldPos = viewToScene(viewPos) + cameraPosition;
        vec3 albedo = srgbToLinear(texelFetch(colortex4, pixel, 0).rgb);

        // Same wetness evaluation as the lighting pass, so both agree on where puddles are.
        float wet = (matId == MAT_END_PORTAL || matId == MAT_END_GATEWAY) ? 0.0 : surfaceWetness(g2.y, worldPos);
        applyWetness(worldPos, geoNormal, wet, g2.y, matId, albedo, normal, smoothness, f0);

        if (smoothness > 0.3) {
            float dist = length(viewPos);
            float dither = ditherT(gl_FragCoord.xy);
            vec3 viewDir = normalize(mat3(gbufferModelViewInverse) * viewPos);

            // Rough surfaces: jitter the mirror direction inside a cone (resolved by TAA).
            float roughness = pow2(1.0 - smoothness);
            vec3 reflected = reflect(viewDir, normal);
            vec3 jitter = vec3(ditherT(gl_FragCoord.xy + 19.0), ditherT(gl_FragCoord.yx + 67.0), dither) - 0.5;
#ifdef TEMPORAL_AA
            // Only where the result is averaged over frames; a fixed jitter would just be grain.
            reflected = normalize(reflected + jitter * roughness * 1.2);
#endif
            if (dot(reflected, geoNormal) < 0.0) reflected = reflect(reflected, geoNormal);

#ifdef OVERWORLD
            float skyAccess = smoothstep(0.3, 0.9, g2.y);
#else
            float skyAccess = 1.0;
#endif
            vec3 mirrored = sampleSky(reflected, worldSunDir()) * skyAccess;

#ifdef SSR
            vec3 hit;
            vec3 viewNormal = mat3(gbufferModelView) * geoNormal;
            vec3 viewReflected = mat3(gbufferModelView) * reflected;
            if (traceReflection(depthtex0, viewPos + viewNormal * (0.04 + dist * 0.004), viewReflected,
                                dither, SSR_STEPS, hit)) {
                // Clamped: a single very bright pixel (a crystal, a torch flame) caught by one
                // ray must not turn into a white speck on the reflecting surface.
                vec3 hitColor = min(textureLod(colortex0, hit.xy, 0.0).rgb, vec3(4.0));
                mirrored = mix(mirrored, hitColor, screenEdgeFade(hit.xy));
            }
#endif

            vec3 specularColor = mix(vec3(f0), albedo, metalness);
            vec3 fresnel = fresnelSchlick(specularColor, dot(normal, -viewDir));
            // Rough surfaces only get a faint, even sheen instead of a noisy mirror image.
            float strength = smoothstep(0.3, 0.6, smoothness) * mix(0.35, 1.0, smoothstep(0.5, 0.9, smoothness));
            // Dielectrics keep their diffuse color underneath; metals are all reflection.
            color = color * (1.0 - fresnel * strength * (1.0 - metalness)) + mirrored * fresnel * strength;
        }
    }
#endif

    outColor = vec4(color, 1.0);
    outOpaque = vec4(color, 1.0);
}
