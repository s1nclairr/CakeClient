// =============================================================================
//  final: lens effects and the HDR -> display transform.
//    1. image distortion: rain drops on the lens, underwater wobble, heat haze
//    2. sharpening (counters TAA softness), bloom, lens flare
//    3. exposure (eye adaptation), tone mapping, grading, vignette, sRGB, dither
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/material.glsl"
#include "/lib/sky.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex5;
uniform sampler2D colortex7;
uniform sampler2D depthtex0;

in vec2 texCoord;

layout(location = 0) out vec4 outColor;

// ---- Rain on the lens ---------------------------------------------------------
// Returns the UV offset caused by drops; mask = how much water covers the pixel.
// shade = signed brightness change: dark rim, small highlight (each drop is a tiny lens).
vec2 lensDroplets(vec2 uv, float amount, out float mask, out float shade) {
    vec2 offset = vec2(0.0);
    mask = 0.0;
    shade = 0.0;
    float t = frameTimeCounter;
    vec2 p = uv * vec2(aspectRatio, 1.0);

    // Resting drops in three sizes, down to a fine mist of micro droplets. They appear,
    // sit for a while and evaporate; each one is slightly out of round.
    for (int layer = 0; layer < 3; layer++) {
        float scale = layer == 0 ? 13.0 : (layer == 1 ? 24.0 : 41.0);
        vec2 g = p * scale + float(layer) * 17.3;
        vec2 f = fract(g) - 0.5;
        vec3 rnd = hash32(floor(g));
        float life = fract(t * (0.035 + 0.045 * rnd.z) + rnd.x);
        float exists = step(1.0 - (layer == 2 ? 0.05 : 0.1) * amount, rnd.y);
        float radius = (0.07 + 0.12 * rnd.z) * sqrt(1.0 - life) * smoothstep(0.0, 0.03, life);
        vec2 d = f - (rnd.xy - 0.5) * 0.4;
        vec2 n = d / max(radius, 1e-4);
        // Irregular outline: lumpy, sagging, sometimes two drops fused together.
        float r = dropShape(n, rnd.zxy);
        float m = (1.0 - smoothstep(0.86, 1.0, r)) * exists;
        // A drop is a small lens: it shows the scene behind it upside down, bent more
        // strongly towards its edge.
        offset -= d * (m * (1.3 + 0.7 * r * r)) / scale;
        mask += m;
        // Clear water: a touch brighter inside, one small crisp glint, a thin soft rim.
        float glint = 1.0 - smoothstep(0.0, 0.26, length(n - vec2(-0.36, 0.42)));
        float rim = layer == 2 ? 0.0 : smoothstep(0.72, 1.0, r);
        shade += m * (0.07 + 0.55 * glint - 0.2 * rim);
    }

    // Running drops: a small head sliding down the glass with a thin trail that breaks
    // up into beads behind it.
    for (int layer = 0; layer < 2; layer++) {
        vec2 grid = layer == 0 ? vec2(15.0, 2.6) : vec2(26.0, 4.2);
        vec2 g = p * grid + float(layer) * 5.7;
        float column = floor(g.x);
        float rnd = hash12(vec2(column, 7.0 + float(layer)));
        g.y += t * (0.1 + 0.22 * rnd) + rnd * 10.0;
        float fy = fract(g.y);
        float rnd2 = hash12(vec2(column, floor(g.y)) + float(layer) * 3.1);
        if (rnd2 < 0.16 * amount) {
            float wobble = sin(g.y * 6.0 + rnd2 * 40.0) * 0.1;
            // Offsets in units of the cell width, so the head stays round.
            vec2 d = vec2(fract(g.x) - 0.5 - (rnd2 / 0.16 - 0.5) * 0.4 - wobble, (fy - 0.2) * grid.x / grid.y);
            float taper = d.y > 0.0 ? 0.6 : 1.0;
            vec2 n = vec2(d.x, d.y * taper) / 0.17;
            float head = 1.0 - smoothstep(0.75, 1.0, length(n));
            float beads = mix(1.0, smoothstep(0.3, 0.6, fract(fy * 11.0 + rnd2 * 9.0)), smoothstep(0.35, 0.6, fy));
            float trail = (1.0 - smoothstep(0.02, 0.055, abs(d.x))) * smoothstep(0.2, 0.28, fy)
                        * (1.0 - smoothstep(0.4, 1.0, fy)) * beads;
            float m = max(head, trail * 0.5);
            offset -= (n * head * (0.17 * 1.6) + vec2(d.x, 0.0) * trail) / grid.x;
            mask += m;
            float glint = 1.0 - smoothstep(0.0, 0.26, length(n - vec2(-0.34, 0.4)));
            shade += head * (0.07 + 0.55 * glint - 0.2 * smoothstep(0.7, 1.0, length(n)));
        }
    }

    mask = saturate(mask);
    // The grid lives in aspect corrected space; convert the offset back to UV.
    return offset / vec2(aspectRatio, 1.0);
}

#if defined FXAA && !defined TEMPORAL_AA
// ---- FXAA ---------------------------------------------------------------------
// Fallback anti-aliasing for when TAA is switched off: finds the direction of the
// local edge from four diagonal neighbors and blurs along it. Luma is taken from a
// range compressed color so that HDR highlights do not dominate the edge test.
float fxaaLuma(vec3 c) { return luma(c / (1.0 + c)); }

vec3 fxaa(vec2 uv, vec2 px, vec3 center) {
    vec3 nw = textureLod(colortex0, uv + vec2(-0.5, -0.5) * px, 0.0).rgb;
    vec3 ne = textureLod(colortex0, uv + vec2( 0.5, -0.5) * px, 0.0).rgb;
    vec3 sw = textureLod(colortex0, uv + vec2(-0.5,  0.5) * px, 0.0).rgb;
    vec3 se = textureLod(colortex0, uv + vec2( 0.5,  0.5) * px, 0.0).rgb;
    float lM = fxaaLuma(center);
    float lNW = fxaaLuma(nw);
    float lNE = fxaaLuma(ne);
    float lSW = fxaaLuma(sw);
    float lSE = fxaaLuma(se);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    if (lMax - lMin < max(0.03, lMax * 0.125)) return center;

    vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));
    float reduce = max((lNW + lNE + lSW + lSE) * 0.03125, 1.0 / 128.0);
    dir = clamp(dir / (min(abs(dir.x), abs(dir.y)) + reduce), -8.0, 8.0) * px;

    vec3 a = 0.5 * (textureLod(colortex0, uv + dir * (1.0 / 3.0 - 0.5), 0.0).rgb
                  + textureLod(colortex0, uv + dir * (2.0 / 3.0 - 0.5), 0.0).rgb);
    vec3 b = a * 0.5 + 0.25 * (textureLod(colortex0, uv - dir * 0.5, 0.0).rgb
                             + textureLod(colortex0, uv + dir * 0.5, 0.0).rgb);
    float lB = fxaaLuma(b);
    return (lB < lMin || lB > lMax) ? a : b;
}
#endif

// ---- Tone mapping -------------------------------------------------------------
// ACES (RRT + ODT fit by Stephen Hill).
vec3 tonemapAces(vec3 color) {
    const mat3 inputMat = mat3(0.59719, 0.35458, 0.04823,
                               0.07600, 0.90834, 0.01566,
                               0.02840, 0.13383, 0.83777);
    const mat3 outputMat = mat3( 1.60475, -0.53108, -0.07367,
                                -0.10208,  1.10813, -0.00605,
                                -0.00327, -0.07276,  1.07602);
    // Constructors are column major, so "v * M" applies the rows written above.
    vec3 v = color * inputMat;
    vec3 a = v * (v + 0.0245786) - 0.000090537;
    vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081;
    return saturate((a / b) * outputMat);
}

vec3 hableCurve(vec3 x) {
    return ((x * (0.15 * x + 0.05) + 0.004) / (x * (0.15 * x + 0.5) + 0.06)) - 0.02 / 0.3;
}

vec3 tonemapHable(vec3 color) {
    return saturate(hableCurve(color * 2.0) / hableCurve(vec3(11.2)));
}

vec3 tonemapReinhard(vec3 color) {
    float l = luma(color);
    return saturate(color * (1.0 + l / 16.0) / (1.0 + l));
}

// ---- Bloom ----------------------------------------------------------------------
vec3 bloomTile(float lod, vec2 offset, vec2 uv) {
    return textureLod(colortex7, uv / exp2(lod) + offset, 0.0).rgb;
}

vec3 sampleBloom(vec2 uv) {
    uv = clamp(uv, 0.002, 0.998);
    vec3 bloom = bloomTile(1.0, vec2(0.0, 0.0), uv) * 0.6
               + bloomTile(2.0, vec2(0.51, 0.0), uv) * 0.9
               + bloomTile(3.0, vec2(0.51, 0.26), uv)
               + bloomTile(4.0, vec2(0.645, 0.26), uv)
               + bloomTile(5.0, vec2(0.7175, 0.26), uv)
               + bloomTile(6.0, vec2(0.645, 0.3325), uv)
               + bloomTile(7.0, vec2(0.670625, 0.3325), uv);
    return bloom / 6.5;
}

void main() {
    vec2 uv = texCoord;
    vec2 pixelSize = 1.0 / vec2(viewWidth, viewHeight);
    float dropletMask = 0.0;
    float dropletShade = 0.0;

    // ---- 1. Distortion ----
#ifdef UNDERWATER_DISTORTION
    if (isEyeInWater == 1) {
        float t = frameTimeCounter;
        uv += vec2(sin(uv.y * 24.0 + t * 1.7), cos(uv.x * 19.0 + t * 1.3)) * 0.0022;
    }
#endif

#ifdef HEAT_HAZE
    {
        // Hot air above lava and fire, found through the material id buffer.
        float t = frameTimeCounter;
        float hot = 0.0;
        for (int i = 0; i < 3; i++) {
            vec2 probe = texCoord - vec2(0.0, 0.035 * float(i));
            int id = int(textureLod(colortex1, probe, 0.0).b * 255.0 + 0.5);
            float d = textureLod(depthtex0, probe, 0.0).r;
            if (isHotMaterial(id) && d < 1.0) hot = max(hot, 1.0 - float(i) * 0.3);
        }
#ifdef NETHER
        hot = max(hot, 0.35);
#endif
        if (hot > 0.0 && isEyeInWater == 0) {
            float nearFade = 1.0 - smoothstep(24.0, 48.0, linearizeDepth(textureLod(depthtex0, texCoord, 0.0).r));
            uv += vec2(sin(texCoord.y * 120.0 + t * 7.0), sin(texCoord.x * 90.0 + t * 5.0))
                * (0.0011 * hot * max(nearFade, 0.25));
        }
    }
#endif

#if defined CAMERA_DROPLETS && defined OVERWORLD
    {
        // Only while it rains and only with open sky straight above the camera: sky light
        // 15 (240). Indoors it is at most 14 (224 = 0.933) even right at a window or in
        // a doorway, so no drops appear there. The amount follows rainStrength directly
        // (squared), so the lens clears within seconds once the rain stops.
        float amount = rainStrength * rainStrength * (1.0 - biomeNoRain)
                     * smoothstep(0.95, 0.995, eyeSkyExposure()) * DROPLET_AMOUNT;
        if (amount > 0.01 && isEyeInWater == 0) {
            uv += lensDroplets(texCoord, saturate(amount), dropletMask, dropletShade);
        }
    }
#endif

    uv = clamp(uv, pixelSize, 1.0 - pixelSize);

    // ---- 2. Color fetch, sharpening ----
    vec3 color = textureLod(colortex0, uv, 0.0).rgb;
#if defined FXAA && !defined TEMPORAL_AA
    color = fxaa(uv, pixelSize, color);
#endif
    vec3 neighbors = textureLod(colortex0, uv + vec2(pixelSize.x, 0.0), 0.0).rgb
                   + textureLod(colortex0, uv - vec2(pixelSize.x, 0.0), 0.0).rgb
                   + textureLod(colortex0, uv + vec2(0.0, pixelSize.y), 0.0).rgb
                   + textureLod(colortex0, uv - vec2(0.0, pixelSize.y), 0.0).rgb;
    if (dropletMask > 0.0) {
        // Water on the lens blurs what is behind it and catches a little light.
        color = mix(color, (color + neighbors) / 5.0, dropletMask * 0.5);
        color *= 1.0 + clamp(dropletShade, -0.25, 0.7);
    } else {
        vec3 sharpened = color + (color - neighbors * 0.25) * SHARPENING;
        color = clamp(sharpened, color * 0.5, color * 2.0 + 0.001);
    }

#ifdef BLOOM
    color = mix(color, sampleBloom(uv), 0.085 * BLOOM_STRENGTH);
#endif

#if defined LENS_FLARE && defined OVERWORLD
    {
        // Sun glare as a camera lens would record it: a soft glow, a star of thin rays,
        // a faint horizontal streak and a chain of ghosts on the line through the screen
        // center. Everything fades when the sun is covered by terrain or thick cloud.
        vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
        if (sunClip.w > 0.0 && sunAngle < 0.5 && isEyeInWater == 0) {
            vec2 sunUV = sunClip.xy / sunClip.w * 0.5 + 0.5;
            float edge = min(min(sunUV.x, 1.0 - sunUV.x), min(sunUV.y, 1.0 - sunUV.y));
            if (edge > 0.0) {
                // Occlusion: how many taps around the sun still see the sky, and whether the
                // disk is actually shining through (a cloud dims it by orders of magnitude).
                float visible = 0.0;
                for (int i = 0; i < 5; i++) {
                    vec2 tap = sunUV + vec2(float(i % 2) * 2.0 - 1.0, float(i / 2) - 1.0) * (i == 4 ? 0.0 : 0.008);
                    visible += step(1.0, textureLod(depthtex0, tap, 0.0).r) * 0.2;
                }
                visible *= smoothstep(3.0, 40.0, luma(textureLod(colortex0, sunUV, 0.0).rgb));
                visible *= smoothstep(0.0, 0.05, edge) * (1.0 - rainStrength);

                if (visible > 0.001) {
                    vec3 sunTint = getSunColor();
                    vec2 aspect = vec2(aspectRatio, 1.0);
                    vec2 toSun = (texCoord - sunUV) * aspect;
                    float dist = length(toSun);
                    float angle = atan(toSun.y, toSun.x);

                    float glow = exp(-dist * 4.0) * 0.2 + exp(-dist * 14.0) * 0.4;
                    // Soft, short rays of uneven length instead of a regular star, and no
                    // straight streak: those are what made the sun look pasted on.
                    float rays = pow(abs(sin(angle * 3.0 + 0.6)), 10.0) * (0.6 + 0.4 * sin(angle * 5.0 + 2.1))
                               * exp(-dist * 9.0) * 0.09
                               + pow(abs(sin(angle * 5.0 + 1.3)), 14.0) * exp(-dist * 14.0) * 0.06;
                    vec3 flare = sunTint * (glow + rays);

                    vec2 axis = vec2(0.5) - sunUV;
                    for (int i = 1; i <= 5; i++) {
                        float k = float(i);
                        vec2 center = sunUV + axis * (0.4 + 0.33 * k);
                        float size = 0.018 + 0.014 * k * fract(k * 0.618);
                        float d = length((texCoord - center) * aspect) / size;
                        // Soft disc with a slightly brighter rim, like an aperture ghost.
                        float ghost = (1.0 - smoothstep(0.75, 1.0, d)) * (0.5 + 0.5 * d * d);
                        vec3 tint = mix(vec3(1.0, 0.75, 0.45), vec3(0.45, 0.75, 1.0), fract(k * 0.37));
                        flare += sunTint * tint * (ghost * 0.035);
                    }
                    // A thin halo ring opposite the sun.
                    float ring = length((texCoord - (sunUV + axis * 2.0)) * aspect);
                    flare += sunTint * vec3(0.6, 0.8, 1.0) * (exp(-pow2((ring - 0.33) * 40.0)) * 0.02);

                    color += flare * (visible * LENS_FLARE_STRENGTH);
                }
            }
        }
    }
#endif

    // ---- 3. Exposure ----
    float exposure = 0.5;
#ifdef AUTO_EXPOSURE
    float average = texelFetch(colortex5, ivec2(0), 0).a;
    if (average > 0.0 && !isnan(average)) {
        // Do not fully compensate: nights stay dark, noon stays bright.
        exposure = clamp(0.3 / pow(average, 0.8), 0.12, 4.5);
    }
#endif
    color *= exposure * EXPOSURE;

    // ---- Tone mapping ----
#if TONEMAP == 0
    color = tonemapAces(color);
#elif TONEMAP == 1
    color = tonemapHable(color);
#else
    color = tonemapReinhard(color);
#endif

    // ---- Grading (display referred) ----
    color = linearToSrgb(color);
    color = mix(vec3(luma(color)), color, SATURATION);
    color = saturate((color - 0.5) * CONTRAST + 0.5);

#ifdef VIGNETTE
    float v = length((texCoord - 0.5) * vec2(1.0, 0.85));
    color *= 1.0 - VIGNETTE_STRENGTH * smoothstep(0.35, 0.95, v);
#endif

    // Break up 8 bit banding in smooth gradients (sky, fog).
    color += (ign(gl_FragCoord.xy) - 0.5) / 255.0;

    outColor = vec4(color, 1.0);
}
