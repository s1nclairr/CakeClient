// =============================================================================
//  deferred1 (GI): screen space ambient occlusion and one bounce global illumination.
//  A few cosine distributed rays are marched against the depth buffer:
//    - a ray that hits something nearby darkens the ambient light (AO);
//    - the hit point's color from the previous frame is gathered as bounce
//      light (SSGI), which is what tints surfaces next to lava or glowstone.
//  The result is noisy by design; deferred1 filters it and TAA integrates it.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/raytrace.glsl"

uniform sampler2D colortex0;  // overlay of unlit geometry drawn so far
uniform sampler2D colortex1;
uniform sampler2D colortex5;
uniform sampler2D colortex8;  // this buffer, previous frame
uniform sampler2D depthtex0;

in vec2 texCoord;

/* RENDERTARGETS: 8 */
layout(location = 0) out vec4 outAoGi;

const float RT_RADIUS = 3.0;
const float RT_MAX_DISTANCE = 96.0;

void main() {
    ivec2 pixel = ivec2(gl_FragCoord.xy);
    float depth = texelFetch(depthtex0, pixel, 0).r;
    outAoGi = vec4(0.0, 0.0, 0.0, 1.0);
    if (depth >= 1.0 || depth < HAND_DEPTH_LIMIT) return;

    vec3 viewPos = screenToView(texCoord, depth);
    float dist = length(viewPos);
    if (dist > RT_MAX_DISTANCE) return;

    vec3 normal = mat3(gbufferModelView) * decodeNormal(texelFetch(colortex1, pixel, 0).rg);
    vec3 helper = abs(normal.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 tangent = normalize(cross(helper, normal));
    vec3 bitangent = cross(normal, tangent);

#ifdef TEMPORAL_AA
    float d1 = ditherT(gl_FragCoord.xy);
    float d2 = ditherT(gl_FragCoord.yx + vec2(41.0, 17.0));
#else
    // No accumulation over frames here (OptiFine): use a pattern with a 4x4 period, which
    // the 4x4 filter in the lighting pass cancels exactly instead of leaving grain.
    float d1 = bayer4(gl_FragCoord.xy);
    float d2 = bayer4(gl_FragCoord.yx + vec2(1.0, 2.0));
#endif
    vec3 origin = viewPos + normal * (0.03 + dist * 0.003);

    float occlusion = 0.0;
    vec3 bounce = vec3(0.0);

    for (int i = 0; i < RT_RAYS; i++) {
        // R2 low discrepancy sequence, cosine weighted hemisphere.
        vec2 xi = fract(vec2(d1, d2) + float(i) * vec2(0.7548776662, 0.5698402910));
        float phi = TAU * xi.x;
        float sinTheta = sqrt(xi.y);
        vec3 dir = tangent * (cos(phi) * sinTheta) + bitangent * (sin(phi) * sinTheta)
                 + normal * sqrt(1.0 - xi.y);

        vec3 hit;
        float t = traceShort(depthtex0, origin, dir, RT_RADIUS, fract(d1 + float(i) * 0.618034), RT_STEPS, 1.2, hit);
        // Block outline and particles are in the depth buffer too; they occlude nothing.
        if (t < 0.0 || textureLod(colortex0, hit.xy, 0.0).a > 0.01) continue;

        // Close hits occlude fully, hits at the end of the ray barely.
        occlusion += 1.0 - t * t;

#if defined SSGI && defined TEMPORAL_AA
        // Bounce light needs many samples per pixel to be smooth; they only exist where
        // frames are accumulated. Without that it is left out rather than shown as noise.
        vec3 hitScene = viewToScene(screenToView(hit.xy, hit.z));
        vec3 prev = reprojectScene(hitScene);
        if (prev.x > 0.0 && prev.x < 1.0 && prev.y > 0.0 && prev.y < 1.0) {
            // Brightness is capped (keeping the hue). The light of a flame or a lamp already
            // arrives through the block light; if a single ray that happens to hit those few
            // very bright pixels were taken at face value, it would show up as a bright
            // speck, and the surface around a torch would look grainy.
            vec3 radiance = textureLod(colortex5, prev.xy, 0.0).rgb;
            bounce += radiance * min(1.0, 1.0 / max(luma(radiance), 1e-4));
        }
#endif
    }

    float rays = float(RT_RAYS);
    float fade = 1.0 - smoothstep(0.7 * RT_MAX_DISTANCE, RT_MAX_DISTANCE, dist);
    float ao = 1.0 - occlusion / rays * fade;
    vec4 result = vec4(max(bounce / rays * fade, vec3(0.0)), ao);

#ifdef TEMPORAL_AA
    // Accumulate over frames: with only a couple of rays per pixel, time is where the
    // remaining samples come from. The surface point is looked up where it was last frame.
    vec3 before = reprojectScene(viewToScene(viewPos));
    before.xy += taaJitterPrevious() * 0.5;
    if (before.x > 0.0 && before.x < 1.0 && before.y > 0.0 && before.y < 1.0) {
        vec4 history = textureLod(colortex8, before.xy, 0.0);
        if (!any(isnan(history))) {
            // Trust the history less while the image moves, so nothing smears.
            float motion = length((before.xy - texCoord) * vec2(viewWidth, viewHeight));
            result = mix(result, history, mix(0.88, 0.5, saturate(motion * 0.04)));
        }
    }
#endif

    outAoGi = result;
}
