// =============================================================================
//  Small special purpose programs writing to the scene color:
//    MISC_DISCARD - vanilla sky, sun, moon and clouds (replaced by our own)
//    MISC_GLINT   - enchantment glint (additive)
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VSH

out vec2 texCoord;
out vec4 tint;

void main() {
    gl_Position = (gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex);
#if defined TEMPORAL_AA && !defined MISC_DISCARD
    gl_Position.xy += taaJitter() * gl_Position.w;
#endif
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    tint = gl_Color;
}

#endif

#ifdef FSH

uniform sampler2D gtexture;

in vec2 texCoord;
in vec4 tint;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
#ifdef MISC_DISCARD
    outColor = vec4(0.0);
    discard;
#else
    vec4 color = texture(gtexture, texCoord) * tint;
    color.rgb = srgbToLinear(color.rgb) * 1.5;
    outColor = color;
#endif
}

#endif
