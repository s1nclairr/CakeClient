// Vertex stage shared by every full screen pass (prepare, deferred, composite, final).

out vec2 texCoord;

void main() {
    gl_Position = (gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex);
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}
