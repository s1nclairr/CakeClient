// =============================================================================
//  Simple forward lit geometry: particles, lines, leashes, world border,
//  beacon beams, glowing eyes. These may be drawn before OR after the deferred
//  passes, so they always output final lit color with alpha blending:
//    before deferred -> colortex0 was cleared to (0,0,0,0) and accumulates a
//                       premultiplied overlay that deferred1 composites;
//    after deferred  -> blends straight onto the lit scene.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VSH

out vec2 texCoord;
out vec2 lmCoord;
out vec4 tint;

void main() {
#if defined PROGRAM_LINE && !defined IS_IRIS
    // Block outline and other lines. Since 1.17 the game sends lines as quads whose
    // vertices all sit on the line itself, with the line direction in the normal; the
    // shader has to push them apart to give the line its width. Iris does that for the
    // pack, OptiFine does not.
    const float shrink = 1.0 - 1.0 / 256.0;  // pulls the outline in front of the block face
    vec4 startClip = gl_ProjectionMatrix * vec4((gl_ModelViewMatrix * gl_Vertex).xyz * shrink, 1.0);
    vec4 endClip = gl_ProjectionMatrix * vec4((gl_ModelViewMatrix * vec4(gl_Vertex.xyz + gl_Normal, 1.0)).xyz * shrink, 1.0);
    vec3 startNdc = startClip.xyz / startClip.w;
    vec3 endNdc = endClip.xyz / endClip.w;
    vec2 screen = vec2(viewWidth, viewHeight);
    vec2 lineDir = normalize((endNdc.xy - startNdc.xy) * screen);
    vec2 lineOffset = vec2(-lineDir.y, lineDir.x) * (2.5 * max(viewHeight / 1080.0, 1.0)) / screen;
    if (lineOffset.x < 0.0) lineOffset = -lineOffset;
    if (gl_VertexID % 2 != 0) lineOffset = -lineOffset;
    gl_Position = vec4((startNdc + vec3(lineOffset, 0.0)) * startClip.w, startClip.w);
#else
    gl_Position = (gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex);
#endif
#ifdef TEMPORAL_AA
    gl_Position.xy += taaJitter() * gl_Position.w;
#endif
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord = saturate(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 0.03125) * 1.06667);
    tint = gl_Color;
}

#endif

#ifdef FSH

#include "/lib/sky.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;

in vec2 texCoord;
in vec2 lmCoord;
in vec4 tint;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
#ifdef PROGRAM_BASIC
    vec4 color = tint;
#else
    vec4 color = texture(gtexture, texCoord) * tint;
#endif
    if (color.a < max(alphaTestRef, 0.004)) discard;

    vec3 albedo = srgbToLinear(color.rgb);

#ifdef OVERLAY_EMISSIVE
    // Beacon beams, spider eyes, dragon beams: self lit.
    vec3 lit = albedo * (5.0 * EMISSIVE_STRENGTH);
#else
#ifdef OVERWORLD
    float skyAccess = lmCoord.y * lmCoord.y * lmCoord.y;
#else
    float skyAccess = 1.0;
#endif
    vec3 light = getAmbientColor() * (skyAccess * AMBIENT_STRENGTH)
               + getDirectColor() * (0.35 * skyAccess)
               + blockLightColor() * blockLightFalloff(lmCoord.x)
               + vec3(0.010, 0.012, 0.018) * MIN_LIGHT + vec3(0.25) * nightVision;
    vec3 lit = albedo * light;
#endif

    outColor = vec4(lit, color.a);
}

#endif
