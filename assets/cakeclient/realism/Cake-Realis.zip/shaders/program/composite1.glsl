// =============================================================================
//  composite1: temporal anti-aliasing and exposure metering.
//  TAA reprojects the previous frame with the depth buffer, clips the history
//  to the color range of the current 3x3 neighborhood (YCoCg) and blends.
//  It also integrates all the per frame dithering used by clouds, shadows,
//  AO/GI, reflections and volumetric fog.
//  The alpha channel of the history buffer carries the smoothed average scene
//  luminance used for eye adaptation in the final pass.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;
uniform bool feetInWater;

const bool colortex0MipmapEnabled = true;

in vec2 texCoord;

/* RENDERTARGETS: 0,5 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outHistory;

vec3 rgbToYcocg(vec3 c) {
    return vec3(0.25 * c.r + 0.5 * c.g + 0.25 * c.b, 0.5 * c.r - 0.5 * c.b, -0.25 * c.r + 0.5 * c.g - 0.25 * c.b);
}

vec3 ycocgToRgb(vec3 c) {
    return vec3(c.x + c.y - c.z, c.x + c.z, c.x - c.y - c.z);
}

// Compress HDR before filtering so single bright pixels do not flicker.
vec3 tonemapForTaa(vec3 c) { return c / (1.0 + luma(c)); }
vec3 untonemapForTaa(vec3 c) { return c / max(1.0 - luma(c), 1e-4); }

void main() {
    ivec2 pixel = ivec2(gl_FragCoord.xy);
    vec3 current = texelFetch(colortex0, pixel, 0).rgb;
    vec3 result = current;

#ifdef TEMPORAL_AA
    // Use the closest depth in the neighborhood so edges reproject with the foreground.
    float depth = 1.0;
    vec3 minColor = vec3(1e9);
    vec3 maxColor = vec3(-1e9);
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            ivec2 p = pixel + ivec2(x, y);
            depth = min(depth, texelFetch(depthtex0, p, 0).r);
            vec3 c = rgbToYcocg(tonemapForTaa(texelFetch(colortex0, p, 0).rgb));
            minColor = min(minColor, c);
            maxColor = max(maxColor, c);
        }
    }

    vec2 prevUV = texCoord;
    if (depth > HAND_DEPTH_LIMIT) {
        vec3 scenePos = viewToScene(screenToView(texCoord, depth));
        // Sky has no position of its own: only the camera rotation applies.
        if (depth >= 1.0) scenePos -= cameraPosition - previousCameraPosition;
        // screenToView removed this frame's sub-pixel jitter to find the world point, so
        // the reprojected position is off by exactly that jitter. Put it back: with a
        // still camera a pixel must read its own history, not a spot that wanders by
        // half a pixel every frame (that made the whole picture tremble).
        prevUV = reprojectScene(scenePos).xy + taaJitter() * 0.5;
    }

    bool onScreen = prevUV.x > 0.0 && prevUV.x < 1.0 && prevUV.y > 0.0 && prevUV.y < 1.0;
    if (onScreen) {
        vec3 history = textureLod(colortex5, prevUV, 0.0).rgb;
        if (!any(isnan(history))) {
            vec3 h = rgbToYcocg(tonemapForTaa(max(history, vec3(0.0))));
            h = clamp(h, minColor, maxColor);
            vec3 c = rgbToYcocg(tonemapForTaa(current));
            // Trust the history less when it moved a lot on screen.
            float motion = length((prevUV - texCoord) * vec2(viewWidth, viewHeight));
            float blend = mix(0.92, 0.8, saturate(motion * 0.05));
            result = untonemapForTaa(ycocgToRgb(mix(c, h, blend)));
        }
    }
#endif

    // ---- Exposure metering ----
    // Only texel (0,0) of the history alpha is ever read, so only that pixel pays for it.
    // A log average (geometric mean) of a coarse mip is used: unlike a plain average it
    // is not dominated by the sun or a bright sky, so the ground stays readable.
    float smoothed = 0.0;
    if (pixel == ivec2(0)) {
        float lod = max(log2(max(viewWidth, viewHeight)) - 5.0, 0.0);
        float logSum = 0.0;
        float weightSum = 0.0;
        for (int y = 0; y < 5; y++) {
            for (int x = 0; x < 8; x++) {
                vec2 uv = (vec2(float(x), float(y)) + 0.5) / vec2(8.0, 5.0);
                float w = 1.0 - 0.6 * length(uv - 0.5);
                logSum += log(max(luma(textureLod(colortex0, uv, lod).rgb), 1e-4)) * w;
                weightSum += w;
            }
        }
        float average = clamp(exp(logSum / weightSum), 0.002, 60.0);
        float previous = texelFetch(colortex5, ivec2(0), 0).a;
        smoothed = average;
        if (previous > 0.0 && !isnan(previous) && !isnan(average)) {
            // Adapt faster to bright scenes than to dark ones, like the eye.
            float speed = average > previous ? 2.2 : 0.9;
            smoothed = mix(previous, average, saturate(1.0 - exp(-frameTime * speed)));
        }
        if (isnan(smoothed)) smoothed = 1.0;
    }

    // ---- Player state for the water wake (texels 1..4 of the bottom row) ----
    // Shaders have no memory except buffers that are not cleared, so the smoothed state
    // lives next to the exposure value:
    //   1: how much the player is in water (fades in and out instead of switching)
    //   2, 3: smoothed horizontal velocity (the wake trails behind it and turns gradually)
    //   4: agitation - recent motion in any direction, including jumping in
    if (pixel.y == 0 && pixel.x >= 1 && pixel.x <= 4) {
        float previous = texelFetch(colortex5, pixel, 0).a;
        if (isnan(previous) || isinf(previous)) previous = 0.0;
        float dt = clamp(frameTime, 0.001, 0.1);
        vec3 velocity = (cameraPosition - previousCameraPosition) / dt;
        // Teleports and chunk jumps are not motion.
        if (length(velocity) > 20.0) velocity = vec3(0.0);

        if (pixel.x == 1) {
            float target = feetInWater ? 1.0 : 0.0;
            smoothed = mix(previous, target, 1.0 - exp(-dt * (target > previous ? 3.5 : 1.3)));
        } else if (pixel.x == 2) {
            smoothed = mix(previous, velocity.x, 1.0 - exp(-dt * 1.6));
        } else if (pixel.x == 3) {
            smoothed = mix(previous, velocity.z, 1.0 - exp(-dt * 1.6));
        } else {
            float motion = length(velocity);
            smoothed = motion > previous ? mix(previous, motion, 1.0 - exp(-dt * 8.0))
                                         : mix(previous, motion, 1.0 - exp(-dt * 0.9));
        }
    }

    result = max(result, vec3(0.0));
    outColor = vec4(result, 1.0);
    outHistory = vec4(result, smoothed);
}
