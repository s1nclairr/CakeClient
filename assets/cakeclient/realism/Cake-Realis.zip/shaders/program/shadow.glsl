// =============================================================================
//  Shadow pass: renders the world from the sun / moon into the distorted
//  shadow map. Translucent casters store their tint; water stores caustics.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/material.glsl"
#include "/lib/shadows.glsl"

#ifdef VSH

#include "/lib/waving.glsl"

in vec4 mc_Entity;
in vec4 mc_midTexCoord;
in vec4 at_midBlock;

out vec2 texCoord;
out vec4 tint;
out vec3 worldPos;
flat out int matId;

void main() {
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    tint = gl_Color;
    matId = materialFromId(mc_Entity.x);

    vec4 shadowView = gl_ModelViewMatrix * gl_Vertex;
    vec3 scenePos = (shadowModelViewInverse * shadowView).xyz;
    worldPos = scenePos + cameraPosition;

#if defined WAVING_PLANTS || defined WAVING_LEAVES || defined WAVING_LANTERNS
    if (isWaving(matId)) {
        float skyLight = saturate(((gl_TextureMatrix[1] * gl_MultiTexCoord1).y - 0.03125) * 1.06667);
        bool isTopVertex = gl_MultiTexCoord0.t < mc_midTexCoord.t;
        scenePos += wavingOffset(worldPos, matId, isTopVertex, skyLight, at_midBlock.xyz / 64.0);
        shadowView = shadowModelView * vec4(scenePos, 1.0);
    }
#endif

    vec4 clip = gl_ProjectionMatrix * shadowView;
    gl_Position = vec4(distortShadowClip(clip.xyz), clip.w);
}

#endif

#ifdef FSH

#include "/lib/water.glsl"

uniform sampler2D gtexture;

in vec2 texCoord;
in vec4 tint;
in vec3 worldPos;
flat in int matId;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 outTint;   // shadowcolor0
layout(location = 1) out vec4 outFlags;  // shadowcolor1

void main() {
    vec4 color = texture(gtexture, texCoord);

    if (matId == MAT_WATER) {
        // Water does not block light; it focuses it. Stored at half scale (0..2 range).
        float caustics = 1.0;
#ifdef WATER_CAUSTICS
        caustics = waterCaustics(worldPos.xz);
#endif
        outTint = vec4(vec3(caustics * 0.5), 1.0);
        outFlags = vec4(1.0, 0.0, 0.0, 1.0);
        return;
    }

    if (color.a < 0.1) discard;
    color.rgb *= tint.rgb;

    if (matId == MAT_LEAVES) {
        // Flagged so the lighting can let some tinted light through the crown.
        outTint = vec4(color.rgb, 1.0);
        outFlags = vec4(0.0, 1.0, 0.0, 1.0);
        return;
    }

    // Stained glass and similar: the more opaque the texel, the stronger the tint,
    // fading to black for fully opaque texels.
    vec3 transmitted = mix(vec3(1.0), color.rgb, sqrt(color.a)) * (1.0 - pow4(color.a));
    outTint = vec4(transmitted, 1.0);
    outFlags = vec4(0.0, 0.0, 0.0, 1.0);
}

#endif
