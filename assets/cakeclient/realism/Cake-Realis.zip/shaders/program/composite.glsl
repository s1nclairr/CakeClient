// =============================================================================
//  composite: everything that happens in the air (or water) between the camera
//  and the scene - atmospheric / height / rain / morning fog, volumetric light
//  shafts through the shadow map, underwater scattering with caustic shafts,
//  lava and powder snow fog, border fog, blindness.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"
#include "/lib/shadows.glsl"
#include "/lib/fog.glsl"
#include "/lib/noise.glsl"
#include "/lib/material.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;  // B: material id of opaque pixels, 1.0 where the water surface is
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

in vec2 texCoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

#ifdef UNDERWATER_BUBBLES
// Air bubbles that exist in the world, not on the lens: a grid of cells anchored in world
// space, some columns of which carry bubbles that rise and wobble. The view ray is tested
// analytically against the bubble of every cell it passes, so a bubble keeps its place
// and size when the camera moves or turns.
// Returns x: brightness, y: distance to the bubble.
vec2 underwaterBubbles(vec3 eyeOffset, vec3 dir, float maxDist) {
    const float cell = 1.6;
    const float stepLen = 0.8;
    float t = frameTimeCounter;
    float range = min(maxDist, 14.0);

    // Work relative to a cell aligned anchor near the camera to keep float precision.
    vec3 anchor = floor(cameraPosition / cell);
    vec3 origin = cameraPosition - anchor * cell + eyeOffset;

    vec2 result = vec2(0.0);
    for (int i = 0; i < 18; i++) {
        float s = (float(i) + 0.5) * stepLen;
        if (s > range + stepLen) break;
        vec3 p = origin + dir * s;

        vec2 column = floor(p.xz / cell);
        vec3 columnRnd = hash32(column + anchor.xz);
        if (columnRnd.x > 0.12) continue;  // only a few columns release bubbles

        float rise = t * (0.7 + 0.5 * columnRnd.y);
        float level = floor((p.y - rise) / cell);
        vec3 rnd = hash32((column + anchor.xz) * 1.37 + (level + anchor.y) * 7.13 + 3.0);
        if (fract(rnd.z * 7.31) > 0.5) continue;  // and those columns have gaps

        vec3 center = vec3((column.x + 0.3 + 0.4 * rnd.x) * cell,
                           (level + 0.3 + 0.4 * rnd.y) * cell + rise,
                           (column.y + 0.3 + 0.4 * rnd.z) * cell);
        center.xz += vec2(sin(t * 2.0 + rnd.x * 20.0), cos(t * 1.7 + rnd.z * 20.0)) * 0.07;

        vec3 toCenter = center - origin;
        float along = dot(toCenter, dir);
        if (along < 0.25 || along > range) continue;

        float radius = 0.009 + 0.013 * rnd.z;
        vec3 q = (dir * along - toCenter) / radius;  // offset from the bubble center, in radii
        float d = length(q);
        if (d < 1.0) {
            // An air bubble in water is a mirror at its edge: a bright thin rim, a nearly
            // clear middle and one glint towards the surface light.
            float rim = smoothstep(0.5, 0.92, d) * (1.0 - smoothstep(0.92, 1.0, d));
            float glint = 1.0 - smoothstep(0.0, 0.32, length(q - vec3(0.0, 0.5, 0.0)));
            float fade = 1.0 - smoothstep(range * 0.6, range, along);
            float value = (0.08 + 0.7 * rim + 1.0 * glint) * fade;
            if (value > result.x) result = vec2(value, along);
        }
    }
    return result;
}
#endif

#if defined END && defined END_HAZE
// Banks of haze that drift slowly between the islands: flat, wide, thicker towards the
// depths. Returns the density at a world position.
float endHazeDensity(vec3 worldPos) {
    vec3 p = worldPos * vec3(0.011, 0.02, 0.011) + vec3(frameTimeCounter * 0.006, 0.0, frameTimeCounter * 0.004);
    float n = noise3D(p) * 0.65 + noise3D(p * 2.7 + 11.0) * 0.35;
    float low = 1.0 - smoothstep(30.0, 95.0, worldPos.y);
    return smoothstep(0.45, 0.8, n) * (0.08 + 0.92 * low);
}
#endif

#if defined END && defined END_MOTES
// Glowing motes that rise out of the void. Like the underwater bubbles they live in the
// world: a grid of cells, some of which hold one mote, tested analytically against the
// view ray. Returns x: brightness, y: distance.
vec2 endMotes(vec3 eyeOffset, vec3 dir, float maxDist) {
    const float cell = 2.2;
    const float stepLen = 1.1;
    float t = frameTimeCounter;
    float range = min(maxDist, 26.0);

    vec3 anchor = floor(cameraPosition / cell);
    vec3 origin = cameraPosition - anchor * cell + eyeOffset;

    vec2 result = vec2(0.0);
    for (int i = 0; i < 24; i++) {
        float s = (float(i) + 0.5) * stepLen;
        if (s > range + stepLen) break;
        vec3 p = origin + dir * s;

        vec2 column = floor(p.xz / cell);
        vec3 columnRnd = hash32(column + anchor.xz);
        if (columnRnd.x > 0.3) continue;

        float rise = t * (0.1 + 0.14 * columnRnd.y);
        float level = floor((p.y - rise) / cell);
        vec3 rnd = hash32((column + anchor.xz) * 1.37 + (level + anchor.y) * 7.13 + 3.0);
        if (fract(rnd.z * 7.31) > 0.45) continue;

        vec3 center = vec3((column.x + 0.3 + 0.4 * rnd.x) * cell,
                           (level + 0.3 + 0.4 * rnd.y) * cell + rise,
                           (column.y + 0.3 + 0.4 * rnd.z) * cell);
        center.xz += vec2(sin(t * 0.5 + rnd.x * 20.0), cos(t * 0.4 + rnd.z * 20.0)) * 0.22;

        vec3 toCenter = center - origin;
        float along = dot(toCenter, dir);
        if (along < 1.5 || along > range) continue;

        // Never thinner than about a pixel and a half, or distant motes would flicker.
        float radius = max(0.022 + 0.03 * rnd.z, along * 1.6 / viewHeight);
        float d = length(dir * along - toCenter) / radius;
        if (d < 1.0) {
            float glow = (1.0 - d) * (1.0 - d);
            float twinkle = 0.6 + 0.4 * sin(t * (1.0 + 2.0 * rnd.x) + rnd.y * 40.0);
            float value = glow * twinkle * smoothstep(1.5, 3.5, along) * (1.0 - smoothstep(range * 0.55, range, along));
            if (value > result.x) result = vec2(value, along);
        }
    }
    return result;
}
#endif

#ifdef WET_SHORE
// Ground soaked by the water next to it: a dark band along every shore, a little above
// the waterline. The water pass marks its pixels in colortex1; here a few points around
// the fragment, at water level, are looked up on screen. If open water is really there
// (close by and at the right height), the fragment is wet. Returns 0..1.
float shoreWetness(vec3 scenePos) {
    vec3 worldPos = scenePos + cameraPosition;
    // The band has an uneven width and breathes slowly with the waves.
    float reach = 0.55 + 0.7 * noise2D(worldPos.xz * 0.7)
                + 0.07 * sin(frameTimeCounter * WAVE_SPEED * 0.8 + noise2D(worldPos.xz * 0.25) * 12.0);
    vec2 size = vec2(viewWidth, viewHeight);
    float wet = 0.0;
    for (int i = 0; i < 12; i++) {
        float a = (float(i) + 0.5) * 2.39996323;
        float r = reach * sqrt((float(i) + 0.5) / 12.0);
        // Two probe heights: block tops sit just above the water, bank walls rise higher.
        vec3 probe = scenePos + vec3(cos(a) * r, (i & 1) == 0 ? -0.12 : -0.45, sin(a) * r);
        vec3 screen = viewToScreen(sceneToView(probe));
        if (screen.x <= 0.0 || screen.x >= 1.0 || screen.y <= 0.0 || screen.y >= 1.0 || screen.z >= 1.0) continue;
        ivec2 p = ivec2(screen.xy * size);
        if (texelFetch(colortex1, p, 0).b < 0.99) continue;
        vec3 d = viewToScene(screenToView(screen.xy, texelFetch(depthtex0, p, 0).r)) - scenePos;
        // d.y: water level relative to the fragment. Soaked from a little below the
        // surface up to about half a block above it.
        float level = smoothstep(-0.75, -0.3, d.y) * (1.0 - smoothstep(0.05, 0.35, d.y));
        float nearby = 1.0 - smoothstep(reach * 0.45, reach, length(d.xz));
        wet = max(wet, level * nearby);
    }
    return wet;
}
#endif

void main() {
    ivec2 pixel = ivec2(gl_FragCoord.xy);
    vec3 color = texelFetch(colortex0, pixel, 0).rgb;
    float depth = texelFetch(depthtex0, pixel, 0).r;

    // The hand is never fogged.
    if (depth < HAND_DEPTH_LIMIT) {
        outColor = vec4(color, 1.0);
        return;
    }

    bool isSky = depth >= 1.0;
    vec3 viewPos = screenToView(texCoord, depth);
    float dist = length(viewPos);
    vec3 viewDir = normalize(mat3(gbufferModelViewInverse) * viewPos);
    vec3 eyeOffset = gbufferModelViewInverse[3].xyz;
    float dither = ditherT(gl_FragCoord.xy);

    vec3 sunDir = worldSunDir();
    vec3 lightDir = worldLightDir();
    vec3 lightColor = getDirectColor();
    vec3 ambientColor = getAmbientColor();

#ifdef WET_SHORE
    // Only bare opaque ground: nothing translucent in front, no entities, no light sources.
    if (!isSky && isEyeInWater == 0 && dist < 48.0 && texelFetch(depthtex1, pixel, 0).r <= depth) {
        int matId = int(texelFetch(colortex1, pixel, 0).b * 255.0 + 0.5);
        if (matId < MAT_DYNAMIC && (matId < MAT_EMISSIVE || matId > MAT_HANGING_SOUL)) {
            float soaked = shoreWetness(viewToScene(viewPos)) * (1.0 - smoothstep(32.0, 48.0, dist));
#ifdef OVERWORLD
            // Ground that the rain has already darkened does not get much darker.
            soaked *= 1.0 - 0.6 * wetness * (1.0 - biomeNoRain);
#endif
            color *= mix(1.0, mix(0.8, 0.56, materialPorosity(matId)), soaked);
        }
    }
#endif

    if (isEyeInWater == 1) {
        // ======================= UNDERWATER =======================
        float skyAccess = max(eyeSkyExposure(), 0.04);
        vec3 ambientLight = ambientColor * skyAccess * 0.6 + vec3(0.004, 0.008, 0.012);
        float phase = 0.25 * mix(1.0, phaseHG(dot(viewDir, lightDir), 0.6), 0.5);

#if defined OVERWORLD && defined VOLUMETRIC_FOG && defined SHADOWS
        // March through the water sampling the shadow map: the water surface writes
        // caustics into it, which become moving shafts of light.
        float marchDist = min(dist, 40.0);
        float stepLen = marchDist / float(VL_STEPS);
        vec3 transmittance = vec3(1.0);
        vec3 scattered = vec3(0.0);
        vec3 stepTransmittance = waterTransmittance(stepLen);
        vec3 p = eyeOffset + viewDir * (stepLen * dither);
        for (int i = 0; i < VL_STEPS; i++) {
            // The shadow map holds the caustic pattern of the surface, so the direct light
            // arrives as separate bright shafts with dark gaps between them.
            vec3 shafts = getShadowFast(p);
            shafts *= 0.4 + 0.6 * shafts;
            vec3 light = lightColor * (phase * VL_STRENGTH * 1.8) * shafts + ambientLight;
            scattered += transmittance * waterInscatter(stepLen, light);
            transmittance *= stepTransmittance;
            p += viewDir * stepLen;
        }
        if (dist > marchDist) {
            float rest = min(dist - marchDist, 256.0);
            scattered += transmittance * waterInscatter(rest, ambientLight);
            transmittance *= waterTransmittance(rest);
        }
        color = color * transmittance + scattered;
#else
        float d = min(dist, 256.0);
        vec3 light = lightColor * phase * skyAccess + ambientLight;
        color = color * waterTransmittance(d) + waterInscatter(d, light);
#endif

#ifdef UNDERWATER_BUBBLES
        vec2 bubble = underwaterBubbles(eyeOffset, viewDir, dist);
        if (bubble.x > 0.0) {
            vec3 bubbleLight = ambientColor * skyAccess * 2.0 + lightColor * (0.5 * skyAccess) + vec3(0.02, 0.03, 0.04);
            color += bubbleLight * waterTransmittance(bubble.y) * bubble.x;
        }
#endif
    } else if (isEyeInWater == 2) {
        // Lava: you see almost nothing but glow.
        color = mix(vec3(3.0, 0.55, 0.06), color, exp(-dist * 1.2));
    } else if (isEyeInWater == 3) {
        // Powder snow.
        color = mix((ambientColor + lightColor * 0.2) * 0.9 + 0.02, color, exp(-dist * 0.6));
    } else {
#ifdef OVERWORLD
        // ======================= ATMOSPHERIC FOG =======================
        vec2 densities = fogDensities();
        float startY = cameraPosition.y + eyeOffset.y;
        float fogDist = dist;
        if (isSky) {
            // The sky LUT already contains the far atmosphere; only the local ground fog remains.
            densities.x = 0.0;
            fogDist = 3000.0;
        }

#ifdef BORDER_FOG
        // Hide the edge of the loaded world by fading terrain into the sky.
        if (!isSky) {
            float border = smoothstep(0.82, 1.0, length((mat3(gbufferModelViewInverse) * viewPos).xz) / far);
            color = mix(color, sampleSky(viewDir, sunDir), border);
        }
#endif

        // Fog picks up the sky color of the horizon it is seen against.
        vec3 horizonDir = normalize(vec3(viewDir.x, 0.04, viewDir.z));
        vec3 fogAmbient = mix(ambientColor, sampleSky(horizonDir, sunDir), 0.6);
        fogAmbient += vec3(0.6, 0.7, 1.0) * (2.0 * lightningFlash());
        vec3 fogSun = lightColor * fogPhase(dot(viewDir, lightDir));

        float transmittance = 1.0;
        vec3 scattered = vec3(0.0);
        float marched = 0.0;

#if defined VOLUMETRIC_FOG && defined SHADOWS
        // Ray march inside the shadow map range: fog is only lit where the sun reaches it,
        // which produces god rays and shadowed volumes.
        marched = min(fogDist, shadowDistance);

        // Sun shafts: a thin haze that only scatters direct light, strongly forward. It is
        // what makes beams visible where the sun breaks through tree crowns, windows or a
        // cave mouth, without laying a milky veil over the rest of the picture.
        float shaftPhase = 0.25 * phaseHG(dot(viewDir, lightDir), 0.7) * VL_STRENGTH;
        vec3 shaftLight = lightColor * shaftPhase;
        const float shaftDensity = 0.0016;
        vec3 shaftSum = vec3(0.0);
        float litSteps = 0.0;

        for (int i = 0; i < VL_STEPS; i++) {
            // Short steps near the camera (crisp beams), longer ones in the distance.
            float fa = float(i) / float(VL_STEPS);
            float fb = float(i + 1) / float(VL_STEPS);
            float ta = marched * fa * (0.35 + 0.65 * fa);
            float tb = marched * fb * (0.35 + 0.65 * fb);
            float stepLen = tb - ta;
            vec3 p = eyeOffset + viewDir * (ta + stepLen * dither);

            float density = fogDensityAt(p.y + cameraPosition.y, densities);
            float absorbed = 1.0 - exp(-density * stepLen);
            vec3 visibility = getShadowFast(p);
            scattered += transmittance * absorbed * (fogSun * visibility + fogAmbient);
            shaftSum += transmittance * (1.0 - exp(-shaftDensity * stepLen)) * visibility;
            litSteps += min(maxOf(visibility), 1.0);
            transmittance *= 1.0 - absorbed;
        }
        // Beams only stand out against shadow: the more of the ray is occluded, the stronger
        // they are drawn. Out in the open the term nearly vanishes instead of hazing the view.
        float occluded = 1.0 - litSteps / float(VL_STEPS);
        scattered += shaftLight * shaftSum * (0.12 + 0.88 * smoothstep(0.0, 0.45, occluded));
#endif

        // Analytic integration for the remaining distance (or all of it without volumetrics).
        if (fogDist > marched) {
            float opticalDepth = fogOpticalDepth(startY + viewDir.y * marched, viewDir.y, fogDist - marched, densities);
            float absorbed = 1.0 - exp(-min(opticalDepth, 30.0));
            scattered += transmittance * absorbed * (fogSun * smoothstep(0.0, 0.5, eyeSkyExposure()) + fogAmbient);
            transmittance *= 1.0 - absorbed;
        }

        color = color * transmittance + scattered;

#ifdef RAINBOW
        // Rainbow: appears opposite a low sun while the air is still full of droplets,
        // i.e. as the rain eases off and for a while after (the "wetness" timer).
        // Primary bow at 42 degrees from the antisolar point (red outside), a fainter
        // secondary at 51 degrees with the colors reversed, brighter sky inside the bow.
        float rainbowAmount = wetness * (1.0 - rainStrength) * (1.0 - biomeNoRain) * (1.0 - snowyBiome())
                            * smoothstep(0.02, 0.12, sunDir.y) * (1.0 - smoothstep(0.55, 0.68, sunDir.y))
                            * smoothstep(0.3, 0.8, eyeSkyExposure());
        if (rainbowAmount > 0.01 && sunAngle < 0.5) {
            float angle = degrees(acos(clamp(dot(viewDir, -sunDir), -1.0, 1.0)));
            float x1 = (angle - 40.3) / 2.4;  // 0 = violet (inner edge), 1 = red (outer edge)
            float x2 = (53.8 - angle) / 3.4;  // secondary bow, reversed
            vec3 hue1 = saturate(abs(fract(0.78 * (1.0 - x1) + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0);
            vec3 hue2 = saturate(abs(fract(0.78 * (1.0 - x2) + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0);
            float band1 = smoothstep(0.0, 0.2, x1) * (1.0 - smoothstep(0.8, 1.0, x1));
            float band2 = smoothstep(0.0, 0.2, x2) * (1.0 - smoothstep(0.8, 1.0, x2));
            vec3 bow = hue1 * band1 + hue2 * (band2 * 0.3) + vec3(0.05) * smoothstep(40.5, 37.0, angle);
            // Only the air far away holds enough droplets to show it.
            float distant = isSky ? 1.0 : smoothstep(40.0, 160.0, dist);
            color += bow * getSunColor() * (0.13 * rainbowAmount * distant);
        }
#endif
#endif

#ifdef NETHER
        // Nether air: biome colored smoke that drifts in slow swirls, and a furnace glow
        // rising from the lava sea (y = 31) that tints everything hanging above it.
        float fogDist = min(dist, 220.0);
        vec3 mid = eyeOffset + viewDir * (fogDist * 0.5);
        float midY = mid.y + cameraPosition.y;
        float swirl = 0.75 + 0.5 * noise3D(vec3(mid.xz + cameraPosition.xz, midY * 2.0) * 0.035
                                           + vec3(0.0, 0.0, frameTimeCounter * 0.02));
        float lavaGlow = exp(-max(midY - 31.0, 0.0) / 16.0);
        vec3 fog = srgbToLinear(fogColor) * 0.8 + vec3(0.55, 0.15, 0.03) * (0.45 * lavaGlow);
        color = mix(fog, color, exp(-fogDist * 0.011 * swirl * FOG_DENSITY));
#endif

#ifdef END
        // Void haze: thin around the islands, dense in the depths below them, so the land
        // seems to float over a bottomless violet fog. Lit by the dark star, with a glow
        // towards it.
        vec2 voidDensities = vec2(0.0012, 0.016) * FOG_DENSITY;
        float voidDist = dist;

#ifdef END_HAZE
        {
            float hazeDist = min(isSky ? 260.0 : dist, 260.0);
            const int hazeSteps = 10;
            float stepLen = hazeDist / float(hazeSteps);
#ifdef TEMPORAL_AA
            float offset = dither;
#else
            float offset = 0.5;
#endif
            vec3 hazeLight = vec3(0.055, 0.023, 0.1) + lightColor * (0.04 * phaseHG(dot(viewDir, lightDir), 0.5));
            float through = 1.0;
            float gathered = 0.0;
            for (int i = 0; i < hazeSteps; i++) {
                vec3 p = eyeOffset + viewDir * (stepLen * (float(i) + offset));
                float absorbed = 1.0 - exp(-endHazeDensity(p + cameraPosition) * 0.02 * FOG_DENSITY * stepLen);
                gathered += through * absorbed;
                through *= 1.0 - absorbed;
            }
            color = color * through + hazeLight * gathered;
        }
#endif
        if (isSky) {
            // The sky has no distance: follow the ray through the height fog only. That is
            // thin straight up, thick towards the horizon and solid below it, with no
            // step anywhere - a switch at the horizon would show as a seam.
            voidDist = 700.0;
            voidDensities.x = 0.0;
        }
        float h = max(cameraPosition.y + eyeOffset.y - 20.0, -30.0);
        float k = max(viewDir.y * voidDist / 30.0, -30.0);
        float integral = abs(k) > 1e-3 ? (1.0 - exp(-k)) / k : 1.0 - 0.5 * k;
        float voidDepth = voidDensities.x * voidDist + voidDensities.y * exp(-h / 30.0) * voidDist * integral;
        float voidFog = 1.0 - exp(-min(voidDepth, 30.0));
        vec3 voidColor = vec3(0.018, 0.008, 0.036) + lightColor * (0.02 * phaseHG(dot(viewDir, lightDir), 0.6));
        color = mix(color, voidColor, voidFog);

#ifdef END_MOTES
        vec2 mote = endMotes(eyeOffset, viewDir, isSky ? 1000.0 : dist);
        color += vec3(1.5, 0.65, 2.4) * (mote.x * 1.6);
#endif
#endif
    }

    // Blindness and the Warden's darkness close in around the player.
    float blackout = max(blindness, darknessFactor * 0.6);
    if (blackout > 0.0) color *= exp(-dist * 0.25 * blackout) * (1.0 - 0.5 * blackout);

    outColor = vec4(max(color, vec3(0.0)), 1.0);
}
