// =============================================================================
//  deferred2 (lighting): lighting of all opaque geometry, plus the sky; composites
//  the cloud buffer on top.
//  Inputs: gbuffer (colortex1-4), AO/GI (colortex8), clouds (colortex10), shadow map, sky LUT.
//  Output: HDR scene color in colortex0.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/material.glsl"
#include "/lib/sky.glsl"
#include "/lib/shadows.glsl"
#include "/lib/lighting.glsl"
#include "/lib/wetness.glsl"
#include "/lib/raytrace.glsl"
#include "/lib/clouds.glsl"

uniform sampler2D colortex0;  // premultiplied overlay drawn before this pass
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;  // albedo
uniform sampler2D colortex8;  // GI + AO
uniform sampler2D colortex9;  // block light color field of the previous frame
uniform sampler2D colortex10; // volumetric clouds (deferred_clouds)
uniform sampler2D depthtex0;

in vec2 texCoord;

/* RENDERTARGETS: 0,9 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outLightField;

#ifdef COLORED_LIGHT
// Colored block light without voxels: a screen space "light color field" that lives in
// colortex9 across frames. Emissive pixels inject their color; every other pixel takes the
// blurred field of its surroundings from the previous frame, so the color creeps outwards
// from the emitters a little further each frame, as far as block light reaches. Only the
// hue of the field is used; brightness still comes from the game's light levels.
vec3 propagateLightField(vec3 scenePos, float dist, float blockLight, vec3 emitted, float dither) {
    vec3 prev = reprojectScene(scenePos);
    vec3 field = vec3(0.0);
    if (prev.x > 0.0 && prev.x < 1.0 && prev.y > 0.0 && prev.y < 1.0) {
        // About one and a half blocks around the surface point, projected to the screen.
        float radius = clamp(1.05 / max(dist, 0.5), 0.004, 0.09);
        field = textureLod(colortex9, prev.xy, 0.0).rgb * 2.0;
        for (int i = 0; i < 4; i++) {
            // The tap pattern is the same for every pixel and only turns from frame to
            // frame. A per pixel random pattern would make neighbouring pixels disagree
            // about the light color, which shows as grain on every lit surface.
            float a = float(i) * (TAU / 4.0) + float(frameCounter % 16) * (TAU / 16.0);
            vec2 uv = prev.xy + vec2(cos(a) / aspectRatio, sin(a)) * (radius * 0.75);
            field += textureLod(colortex9, clamp(uv, 0.001, 0.999), 0.0).rgb;
        }
        field /= 6.0;
    }
    // Light color does not travel where there is no block light, and it fades with distance.
    field *= 0.955 * smoothstep(0.0, 0.2, blockLight);
    field = max(field, emitted);
    return any(isnan(field)) ? vec3(0.0) : min(field, vec3(200.0));
}
#endif

#if defined SSAO || defined SSGI
// 4x4 depth aware box filter: removes the per pixel ray noise without bleeding over edges.
vec4 filterAoGi(ivec2 pixel, float viewZ) {
    vec4 sum = vec4(0.0);
    float weightSum = 0.0;
    for (int y = -2; y <= 1; y++) {
        for (int x = -2; x <= 1; x++) {
            ivec2 p = pixel + ivec2(x, y);
            float z = linearizeDepth(texelFetch(depthtex0, p, 0).r);
            float w = exp(-abs(z - viewZ) * 6.0 / max(viewZ * 0.1, 0.1)) + 1e-4;
            sum += texelFetch(colortex8, p, 0) * w;
            weightSum += w;
        }
    }
    return sum / weightSum;
}
#endif

void main() {
    ivec2 pixel = ivec2(gl_FragCoord.xy);
    float depth = texelFetch(depthtex0, pixel, 0).r;
    vec4 overlay = texelFetch(colortex0, pixel, 0);
    float dither = ditherT(gl_FragCoord.xy);

    bool isHand = depth < HAND_DEPTH_LIMIT;
    vec3 viewPos = screenToView(texCoord, isHand ? fixHandDepth(depth) : depth);
    vec3 viewDir = normalize(mat3(gbufferModelViewInverse) * viewPos);

    vec3 sunDir = worldSunDir();
    vec3 moonDir = worldMoonDir();
    vec3 lightDir = worldLightDir();
    vec3 lightColor = getDirectColor();
    vec3 ambientColor = getAmbientColor();

    vec3 color;
    float sceneDist = 1e9;
    vec3 lightField = vec3(0.0);

#if defined OVERWORLD && defined AURORA
    // Northern lights: clear nights over snowy biomes. They also cast a faint green
    // glow on the landscape below.
    float auroraAmount = snowyBiome() * (1.0 - smoothstep(-0.22, -0.06, sunDir.y)) * (1.0 - rainStrength);
    ambientColor += vec3(0.012, 0.05, 0.03) * (auroraAmount * AURORA_BRIGHTNESS);
#endif

    if (depth >= 1.0) {
#ifdef END
        // The dark star sits where the light of the End comes from.
        color = renderSky(viewDir, lightDir, moonDir);
#else
        color = renderSky(viewDir, sunDir, moonDir);
#endif
#if defined OVERWORLD && defined AURORA
        if (auroraAmount > 0.001 && viewDir.y > 0.06) {
            color += renderAurora(viewDir, dither) * auroraAmount;
        }
#endif
    } else {
        vec3 scenePos = viewToScene(viewPos);
        vec3 worldPos = scenePos + cameraPosition;
        sceneDist = length(viewPos);

        // ---- Unpack the gbuffer ----
        vec4 g1 = texelFetch(colortex1, pixel, 0);
        vec3 g2 = texelFetch(colortex2, pixel, 0).rgb;
        vec3 g3 = texelFetch(colortex3, pixel, 0).rgb;
        vec3 geoNormal = decodeNormal(g1.rg);
        int matId = int(g1.b * 255.0 + 0.5);

        Surface s;
        s.albedo = srgbToLinear(texelFetch(colortex4, pixel, 0).rgb);
        s.normal = geoNormal;
        s.toView = -viewDir;
        s.dist = sceneDist;
        s.lightmap = g2.xy;
        s.emission = g3.r;
        s.smoothness = g3.g;
#ifdef SURFACE_REFLECTIONS
        s.metalness = g3.b;
#else
        // Without the reflection pass a pure metal would have nothing to show: shade it as a dielectric.
        s.metalness = 0.0;
#endif
        s.f0 = 0.04;
        s.subsurface = isFoliage(matId) ? (matId == MAT_LEAVES ? 0.6 : 1.0) : 0.0;

        // ---- Rain: wet surfaces and puddles ----
        bool isPortal = matId == MAT_END_PORTAL || matId == MAT_END_GATEWAY;
        float wet = (isHand || isPortal) ? 0.0 : surfaceWetness(s.lightmap.y, worldPos);
        applyWetness(worldPos, geoNormal, wet, s.lightmap.y, matId, s.albedo, s.normal, s.smoothness, s.f0);
        if (!isHand && !isPortal) applySnowCover(worldPos, geoNormal, s.lightmap.y, matId, s.emission, s.albedo, s.smoothness);

        // ---- Ambient occlusion and bounce light ----
        float ao = mix(1.0, g2.z, 0.75);
        vec3 bounce = vec3(0.0);
#if defined SSAO || defined SSGI
        if (!isHand) {
            vec4 aoGi = filterAoGi(pixel, -viewPos.z);
#ifdef SSAO
            ao *= pow(saturate(aoGi.a), AO_STRENGTH);
#endif
#ifdef SSGI
            bounce = aoGi.rgb * GI_STRENGTH;
#endif
        }
#endif
#ifdef NETHER
        // No sky and no shadow map here: stronger occlusion is what gives caves their depth.
        ao = pow(ao, 1.6);
#endif
        s.ao = ao;

        // Lava breathes: slow, spatially varying pulse.
        if (matId == MAT_LAVA) {
            s.emission *= 0.82 + 0.18 * sin(frameTimeCounter * 1.6 + noise2D(worldPos.xz * 0.35) * TAU);
        }

        // ---- Direct light visibility ----
        vec3 shadow = vec3(1.0);
#ifdef DIRECT_LIGHT
        float NoL = dot(geoNormal, lightDir);
        bool receivesLight = maxOf(lightColor) > 1e-4 && (NoL > 0.0 || s.subsurface > 0.0);
        if (!receivesLight) {
            shadow = vec3(0.0);
        } else {
#ifdef SHADOWS
            shadow = getShadow(scenePos, geoNormal, dither, SHADOW_SAMPLES);
#ifdef CONTACT_SHADOWS
            // Short screen space rays catch the small occluders the shadow map misses.
            if (!isHand && s.subsurface <= 0.0 && sceneDist < 64.0 && maxOf(shadow) > 0.02) {
                vec3 hit;
                vec3 viewNormal = mat3(gbufferModelView) * geoNormal;
                vec3 viewLight = mat3(gbufferModelView) * lightDir;
                float t = traceShort(depthtex0, viewPos + viewNormal * (0.02 + sceneDist * 0.002), viewLight,
#ifdef TEMPORAL_AA
                                     0.3 + sceneDist * 0.012, dither, 8, 0.25 + sceneDist * 0.02, hit);
#else
                                     0.3 + sceneDist * 0.012, 0.5, 12, 0.25 + sceneDist * 0.02, hit);
#endif
                // Block outline and particles are in the depth buffer too; they cast nothing.
                if (t >= 0.0 && textureLod(colortex0, hit.xy, 0.0).a < 0.01) shadow *= mix(0.25, 1.0, smoothstep(40.0, 64.0, sceneDist));
            }
#endif
#elif defined OVERWORLD
            // No shadow map: fall back to the sky light level.
            shadow = vec3(smoothstep(0.85, 0.97, s.lightmap.y));
#endif
#if defined CLOUD_SHADOWS && defined VOLUMETRIC_CLOUDS && defined OVERWORLD
            shadow *= cloudShadow(worldPos, lightDir);
#endif
        }
#endif

        LightEnv l;
        l.directColor = lightColor;
        l.directDir = lightDir;
        l.ambientColor = ambientColor;
        l.skyColor = sampleSky(normalize(s.normal + vec3(0.0, 0.7, 0.0)), sunDir) * 1.6;
        l.blockTint = vec4(0.0);
#ifdef COLORED_LIGHT
        if (!isHand) {
            // Emitters write a strong version of their own color.
            vec3 emitted = s.albedo * (s.emission * 60.0);
            lightField = propagateLightField(scenePos, sceneDist, s.lightmap.x, emitted, dither);
            float strength = maxOf(lightField);
            l.blockTint = vec4(lightField / max(strength, 1e-5), smoothstep(0.0004, 0.02, strength) * COLORED_LIGHT_STRENGTH);
        }
#endif
        l.shadow = shadow;
        l.indirect = bounce;

        color = shadeSurface(s, l);
        // The End portal is a view into space: it shows its own light and nothing else.
        if (isPortal) color = s.albedo * 2.5;
        // A gateway is an active rift: on top of the star field it gives off a slowly
        // pulsing violet light of its own, which the bloom turns into a halo.
        if (matId == MAT_END_GATEWAY) color += vec3(0.55, 0.2, 1.0) * (0.75 + 0.25 * sin(frameTimeCounter * 1.3));
    }

    // ---- Clouds (in front of the sky, and in front of terrain when flying through them) ----
#if defined OVERWORLD && defined VOLUMETRIC_CLOUDS
    vec3 camWorld = cameraPosition + gbufferModelViewInverse[3].xyz;
#ifdef CIRRUS_CLOUDS
    if (depth >= 1.0) {
        vec4 cirrus = renderCirrus(camWorld, viewDir, lightColor, ambientColor, lightDir);
        color = color * cirrus.a + cirrus.rgb;
    }
#endif
#ifdef TEMPORAL_AA
    vec4 clouds = texelFetch(colortex10, pixel, 0);
#else
    // The cloud pass used a 4x4 ordered dither; averaging one full period cancels it.
    vec4 clouds = vec4(0.0);
    for (int y = -2; y <= 1; y++) {
        for (int x = -2; x <= 1; x++) {
            clouds += texelFetch(colortex10, pixel + ivec2(x, y), 0);
        }
    }
    clouds /= 16.0;
#endif
    if (!isHand && !any(isnan(clouds))) color = color * clouds.a + clouds.rgb;
#endif

    // ---- Unlit / forward geometry drawn before this pass (premultiplied alpha) ----
    color = color * (1.0 - saturate(overlay.a)) + overlay.rgb;

    outColor = vec4(max(color, vec3(0.0)), 1.0);
    outLightField = vec4(lightField, 1.0);
}
