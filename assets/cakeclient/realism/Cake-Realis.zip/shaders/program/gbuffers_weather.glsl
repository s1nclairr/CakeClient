// =============================================================================
//  Rain and snow sheets. Rain is restyled into thin, lit, wind tilted streaks;
//  snow keeps its texture and is simply lit. No extra particles are spawned:
//  the vanilla quads are reshaped and shaded on the GPU.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VSH

out vec2 texCoord;
out vec2 lmCoord;
out vec4 tint;

void main() {
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec3 scenePos = (gbufferModelViewInverse * viewPos).xyz;

    // Shear the sheets with height so drops fall at an angle; gusts vary the angle.
    float gust = 0.75 + 0.25 * sin(frameTimeCounter * 0.7);
    scenePos.xz += vec2(0.85, 0.4) * (RAIN_WIND * gust * rainStrength * scenePos.y);

    gl_Position = gl_ProjectionMatrix * (gbufferModelView * vec4(scenePos, 1.0));
#ifdef TEMPORAL_AA
    gl_Position.xy += taaJitter() * gl_Position.w;
#endif
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord = saturate(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 0.03125) * 1.06667);
    tint = gl_Color;
}

#endif

#ifdef FSH

#include "/lib/sky.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;

in vec2 texCoord;
in vec2 lmCoord;
in vec4 tint;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
    vec4 texel = texture(gtexture, texCoord);
    float alpha = texel.a * tint.a;
    if (alpha < 0.01) discard;

    // Drops are lit by the sky around them and by nearby torches; lightning makes them flash.
    vec3 light = getAmbientColor() * 1.4 + getDirectColor() * 0.25
               + blockLightColor() * blockLightFalloff(lmCoord.x) * 0.6
               + vec3(0.6, 0.7, 1.0) * (4.0 * lightningFlash()) + vec3(0.01);

    // The vanilla rain texture is blue, snow is white.
    bool isRain = texel.b - texel.r > 0.08;
    vec3 color;
    if (isRain) {
        // Vary drop size / brightness per streak column.
        float column = hash12(vec2(floor(texCoord.x * 64.0), 3.0));
        color = vec3(0.72, 0.82, 1.0) * light * (0.5 + 0.5 * column);
        alpha *= (0.25 + 0.3 * column) * RAIN_OPACITY;
    } else {
        color = srgbToLinear(texel.rgb * tint.rgb) * light;
        alpha *= 0.85;
    }

    outColor = vec4(color, saturate(alpha));
}

#endif
