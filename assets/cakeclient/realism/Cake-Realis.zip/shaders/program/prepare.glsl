// =============================================================================
//  prepare: renders the sky-view LUT and the light colors of this frame into a
//  corner of colortex6. Layout (pixels):
//    [0, SKY_LUT_W) x [0, SKY_LUT_H)   sky radiance (see lib/sky.glsl)
//    row SKY_LUT_H + 2, x = 0..3        sun, moon, shadow light, ambient
//  The atmosphere is ray marched for ~33k texels instead of every screen pixel.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/atmosphere.glsl"

in vec2 texCoord;

/* RENDERTARGETS: 6 */
layout(location = 0) out vec4 outSky;

#ifdef OVERWORLD

// Overcast: clouds scatter the sunlight into a dim, grey, directionless glow.
vec3 overcastSky(vec3 sky) {
    vec3 grey = vec3(luma(sky)) * vec3(0.82, 0.88, 1.0) * 0.7;
    return mix(sky, grey, rainStrength * 0.92) * (1.0 - 0.45 * thunderStrength);
}

float moonPhaseBrightness() {
    return (0.2 + 0.8 * (0.5 + 0.5 * cos(float(moonPhase) * (PI / 4.0)))) * MOON_BRIGHTNESS;
}

#endif

void main() {
    vec2 fragCoord = gl_FragCoord.xy;
    vec3 result = vec3(0.0);

    if (fragCoord.x < float(SKY_LUT_W) && fragCoord.y < float(SKY_LUT_H + 4)) {
        bool inLut = fragCoord.y < float(SKY_LUT_H);
        int index = int(fragCoord.x);
        bool inLightRow = int(fragCoord.y) == SKY_LUT_H + 2 && index < 4;

#ifdef OVERWORLD
        vec3 sunDir = worldSunDir();
        vec3 moonDir = worldMoonDir();
        vec3 sunE = SUN_IRRADIANCE;
        vec3 moonE = MOON_IRRADIANCE * moonPhaseBrightness();

        if (inLut) {
            vec2 uv = (fragCoord - 0.5) / vec2(float(SKY_LUT_W - 1), float(SKY_LUT_H - 1));
            vec3 dir = skyLutDir(uv, sunDir);
            result = overcastSky(atmosphere(dir, sunDir, moonDir, sunE, moonE, ATMOSPHERE_STEPS));
        } else if (inLightRow) {
            vec3 origin = atmCameraPos();
            // Under a rain deck the sun is no longer a directional light: almost all of it
            // arrives as diffuse sky light, so no cast shadows remain on the ground.
            float clearing = 1.0 - rainStrength;
            float directFade = 0.012 + 0.988 * clearing * clearing;
            vec3 sunColor = sunE * atmLightTransmittance(origin, sunDir) / PI;
            vec3 moonColor = moonE * atmLightTransmittance(origin, moonDir) / PI;

            if (index == 0) {
                result = sunColor * directFade;
            } else if (index == 1) {
                result = moonColor * directFade;
            } else if (index == 2) {
                // The light that owns the shadow map. Faded at the horizon so the
                // sun -> moon hand-over never pops.
                vec3 lightDir = worldLightDir();
                vec3 color = sunAngle < 0.5 ? sunColor : moonColor;
                result = color * directFade * smoothstep(0.0, 0.07, lightDir.y);
            } else {
                // Sky irradiance on flat ground: cosine weighted average of the sky.
                vec3 sum = vec3(0.0);
                const int samples = 12;
                for (int i = 0; i < samples; i++) {
                    float u = (float(i) + 0.5) / float(samples);
                    float phi = float(i) * 2.39996323;
                    float sinTheta = sqrt(u);
                    vec3 dir = vec3(cos(phi) * sinTheta, sqrt(1.0 - u), sin(phi) * sinTheta);
                    sum += atmosphere(dir, sunDir, moonDir, sunE, moonE, 8);
                }
                vec3 ambient = sum / float(samples);
                // Under overcast part of the blocked sunlight arrives as diffuse light.
                vec3 diffused = (sunColor + moonColor) * (0.26 * rainStrength);
                // Starlight and airglow: a soft blue fill so that surfaces facing away from
                // the moon keep their shape and color instead of dropping to black.
                float night = 1.0 - smoothstep(-0.18, 0.05, sunDir.y);
                vec3 nightFill = vec3(0.018, 0.028, 0.052) * (night * MOON_BRIGHTNESS);
                result = overcastSky(ambient * 1.6 + diffused) + nightFill;
            }
        }
#endif

#ifdef NETHER
        // No sky: the biome fog color acts as a dim, omnidirectional light.
        vec3 fog = srgbToLinear(fogColor);
        if (inLut) result = fog * 0.7;
        else if (inLightRow && index == 3) result = fog * 0.9 + vec3(0.16, 0.09, 0.06);
#endif

#ifdef END
        if (inLut) {
            vec2 uv = (fragCoord - 0.5) / vec2(float(SKY_LUT_W - 1), float(SKY_LUT_H - 1));
            float horizon = 1.0 - abs(uv.y * 2.0 - 1.0);
            result = mix(vec3(0.006, 0.003, 0.012), vec3(0.03, 0.014, 0.055), horizon * horizon);
        } else if (inLightRow) {
            // The dark star above the End is a real light: cold, violet, casting shadows.
            // The glow of the void fills in the shaded sides.
            result = index == 3 ? vec3(0.075, 0.05, 0.14) : (index == 1 ? vec3(0.0) : vec3(0.36, 0.25, 0.62));
        }
#endif
    }

    outSky = vec4(max(result, vec3(0.0)), 1.0);
}
