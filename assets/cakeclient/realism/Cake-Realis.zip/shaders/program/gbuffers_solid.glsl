// =============================================================================
//  Opaque geometry (terrain, block entities, entities, hand).
//  Writes the gbuffer; all lighting happens later in the deferred passes.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/material.glsl"

#ifdef VSH

#include "/lib/waving.glsl"

#ifdef PROGRAM_TERRAIN
in vec4 mc_Entity;
in vec4 mc_midTexCoord;
in vec4 at_midBlock;
#endif
in vec4 at_tangent;

out vec2 texCoord;
out vec2 lmCoord;
out vec4 tint;
out vec3 worldNormal;
out vec4 worldTangent;
out vec3 scenePos;
out vec4 texBounds;  // xy: corner of this quad's sprite in the atlas, zw: its size
flat out int matId;

void main() {
    // Tangent for normal maps of PBR resource packs (w = handedness).
    worldTangent = vec4(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * at_tangent.xyz), at_tangent.w);
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord = saturate(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 0.03125) * 1.06667);
    tint = gl_Color;
    worldNormal = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    matId = MAT_DEFAULT;
    texBounds = vec4(0.0);

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;

#ifdef PROGRAM_TERRAIN
    matId = materialFromId(mc_Entity.x);

    // The sprite of this quad: every corner is half a sprite away from the middle.
    vec2 midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).xy;
    vec2 halfSize = abs(texCoord - midCoord);
    texBounds = vec4(midCoord - halfSize, halfSize * 2.0);

    // Cross shaped plants have sideways normals; light them like the ground they grow on.
    if (matId >= MAT_PLANT && matId <= MAT_PLANT_UPPER) worldNormal = vec3(0.0, 1.0, 0.0);

#if defined WAVING_PLANTS || defined WAVING_LEAVES || defined WAVING_LANTERNS
    if (isWaving(matId)) {
        vec3 moved = (gbufferModelViewInverse * viewPos).xyz;
        bool isTopVertex = gl_MultiTexCoord0.t < mc_midTexCoord.t;
        moved += wavingOffset(moved + cameraPosition, matId, isTopVertex, lmCoord.y, at_midBlock.xyz / 64.0);
        viewPos = gbufferModelView * vec4(moved, 1.0);
    }
#endif
#endif

    scenePos = (gbufferModelViewInverse * viewPos).xyz;
    gl_Position = gl_ProjectionMatrix * viewPos;
#ifdef TEMPORAL_AA
    gl_Position.xy += taaJitter() * gl_Position.w;
#endif
}

#endif

#ifdef FSH

#if defined PROGRAM_TERRAIN && defined WALL_DRIPS && defined OVERWORLD
#define GLASS_DRIPS
#include "/lib/wetness.glsl"
#endif
#ifdef PROGRAM_BLOCK
#include "/lib/noise.glsl"
#endif

uniform sampler2D gtexture;
#ifdef PBR_TEXTURES
uniform sampler2D normals;   // labPBR: RG normal, B ambient occlusion, A height
uniform sampler2D specular;  // labPBR: R smoothness, G reflectance / metal, A emission
#endif
uniform float alphaTestRef;
uniform vec4 entityColor;
uniform int entityId;
uniform int blockEntityId;
uniform int currentRenderedItemId;  // Iris
uniform int heldItemId;             // OptiFine

in vec2 texCoord;
in vec2 lmCoord;
in vec4 tint;
in vec3 worldNormal;
in vec4 worldTangent;
in vec3 scenePos;
in vec4 texBounds;
flat in int matId;

/* RENDERTARGETS: 4,1,2,3 */
layout(location = 0) out vec4 outAlbedo;
layout(location = 1) out vec4 outNormal;
layout(location = 2) out vec4 outLight;
layout(location = 3) out vec4 outMaterial;

#ifdef PROGRAM_BLOCK
// The End portal and gateway are drawn as a window into space: near-black depth with a
// faint drift of violet and teal gas, and layers of small sharp stars lying at different
// distances behind the surface. Each layer is shifted along the view ray by its depth, so
// the stars slide against each other as the camera moves, like looking down a well.
vec3 endPortalColor(vec3 worldPos, vec3 viewDir, vec3 normal) {
    // Coordinates in the plane of the portal, and how the view ray slides across it.
    vec3 an = abs(normal);
    vec2 plane;
    vec2 slide;
    float into;
    if (an.y > 0.5) { plane = worldPos.xz; slide = viewDir.xz; into = abs(viewDir.y); }
    else if (an.x > 0.5) { plane = worldPos.zy; slide = viewDir.zy; into = abs(viewDir.x); }
    else { plane = worldPos.xy; slide = viewDir.xy; into = abs(viewDir.z); }
    slide /= max(into, 0.15);

    float t = frameTimeCounter;
    vec2 g = plane + slide * 7.0;
    float gas = noise2D(g * 0.35 + t * 0.01) * 0.6 + noise2D(g * 0.9 - t * 0.013) * 0.4;
    vec3 gasColor = mix(vec3(0.012, 0.04, 0.055), vec3(0.05, 0.015, 0.08), noise2D(g * 0.2 + 9.0));
    vec3 color = mix(vec3(0.002, 0.003, 0.008), gasColor, smoothstep(0.45, 0.9, gas));

    for (int i = 0; i < 5; i++) {
        float layer = float(i);
        vec2 p = (plane + slide * (0.4 + layer * 0.9)) * (7.0 + layer * 3.0) + layer * 23.7;
        vec3 rnd = hash32(floor(p));
        if (rnd.z < 0.7) continue;
        float d = length(fract(p) - 0.5 - (rnd.xy - 0.5) * 0.7);
        float size = 0.035 + 0.05 * fract(rnd.z * 13.0);
        float star = 1.0 - smoothstep(0.0, size, d);
        float twinkle = 0.7 + 0.3 * sin(t * (2.0 + rnd.x * 3.0) + rnd.y * 40.0);
        vec3 starTint = mix(vec3(0.7, 0.95, 1.0), vec3(0.8, 0.6, 1.0), fract(rnd.x * 7.7));
        color += starTint * (star * star * twinkle * 1.2 / (1.0 + layer * 0.5));
    }
    return color;
}
#endif
void main() {
    vec2 coord = texCoord;
    vec2 dcdx = dFdx(texCoord);
    vec2 dcdy = dFdy(texCoord);

    // Face basis. With the bitangent defined as cross(tangent, normal) * handedness, the
    // red and green channels of a labPBR normal map and the UV directions line up.
    float normalLength = length(worldNormal);
    vec3 normal = normalLength > 1e-4 ? worldNormal / normalLength : vec3(0.0, 1.0, 0.0);
    float tangentLength = length(worldTangent.xyz);
    bool hasBasis = tangentLength > 1e-4;
    vec3 tangent = hasBasis ? worldTangent.xyz / tangentLength : vec3(1.0, 0.0, 0.0);
    vec3 bitangent = cross(tangent, normal) * (worldTangent.w < 0.0 ? -1.0 : 1.0);

#if defined PBR_TEXTURES && defined PARALLAX && defined PROGRAM_TERRAIN
    // Parallax occlusion mapping: the view ray is stepped through the height map of the
    // resource pack (alpha of the normal texture), so bricks and stones get real depth.
    // Vanilla textures and packs without height data are left untouched.
    {
        float dist = length(scenePos);
        float startHeight = textureGrad(normals, coord, dcdx, dcdy).a;
        bool flatPlant = matId >= MAT_PLANT && matId <= MAT_PLANT_UPPER;
        if (hasBasis && !flatPlant && dist < 28.0 && texBounds.z > 0.0 && texBounds.w > 0.0
            && startHeight > 0.001 && startHeight < 0.999) {
            vec3 toFragment = scenePos / max(dist, 1e-4);
            vec3 viewTangent = vec3(dot(toFragment, tangent), dot(toFragment, bitangent), dot(toFragment, normal));
            if (viewTangent.z < -0.05) {
                float fade = 1.0 - smoothstep(18.0, 28.0, dist);
                vec2 local = (texCoord - texBounds.xy) / texBounds.zw;
                vec2 stepUV = viewTangent.xy * (0.25 * PARALLAX_DEPTH * fade)
                            / (-viewTangent.z * float(PARALLAX_STEPS));
                float height = startHeight;
                for (int i = 0; i < PARALLAX_STEPS; i++) {
                    if (height > 1.0 - float(i) / float(PARALLAX_STEPS)) break;
                    local += stepUV;
                    height = textureGrad(normals, fract(local) * texBounds.zw + texBounds.xy, dcdx, dcdy).a;
                }
                coord = fract(local) * texBounds.zw + texBounds.xy;
            }
        }
    }
#endif

    vec4 albedo = textureGrad(gtexture, coord, dcdx, dcdy);
    float ao = 1.0;

#ifdef PROGRAM_TERRAIN
    // separateAo: vertex alpha carries the vanilla ambient occlusion.
    albedo.rgb *= tint.rgb;
    ao = tint.a;
#else
    albedo *= tint;
#endif

    bool isGlassDrop = false;
#ifdef GLASS_DRIPS
    // Clear glass is cutout geometry: its see-through texels are simply discarded, so
    // there is no surface for rain to sit on. Where a drop covers such a texel we keep a
    // dithered fraction of the pixels instead (TAA blends them into a translucent film):
    // a faint body, brighter at the bottom, and a solid glint.
    if (matId == MAT_GLASS && albedo.a < 0.5 && abs(worldNormal.y) < 0.5) {
        float glassRain = rainStrength * (1.0 - biomeNoRain) * smoothstep(0.8, 0.9, lmCoord.y);
        float dist = length(scenePos);
        if (glassRain > 0.01 && dist < 22.0) {
            vec3 drips = wallDrips(scenePos + cameraPosition, worldNormal, 0.5 * glassRain, dist);
            float lens = clamp(drips.z, -1.0, 1.0);
            float coverage = drips.x * (0.2 - 0.14 * lens) + 0.8 * dropGlint(drips);
            if (coverage > ditherT(gl_FragCoord.xy)) {
                albedo = vec4(0.84, 0.9, 0.96, 1.0);
                isGlassDrop = true;
            }
        }
    }
#endif

    if (albedo.a < max(alphaTestRef, 0.004)) discard;

#if defined PROGRAM_ENTITIES && !defined IS_IRIS
    // OptiFine has no separate pass for translucent entities (slimes, ghosts of armor
    // stands ...). Dithered coverage, resolved by TAA, stands in for alpha blending.
    if (albedo.a < 0.95 && albedo.a < ditherT(gl_FragCoord.xy)) discard;
#endif

    int id = matId;
#ifndef PROGRAM_TERRAIN
    // Dynamic geometry: never gets world space puddles. Held / dropped items may glow.
    id = MAT_DYNAMIC;
#ifdef IS_IRIS
#if defined PROGRAM_HAND || defined PROGRAM_ENTITIES
    // Iris reports the item that is being drawn right now (hand, dropped, worn).
    int itemId = currentRenderedItemId - 10000;
    if (itemId > 0 && itemId < MAT_DYNAMIC) id = itemId;
#endif
#else
#ifdef PROGRAM_HAND
    // OptiFine only knows the item in the main hand.
    int itemId = heldItemId - 10000;
    if (itemId > 0 && itemId < MAT_DYNAMIC) id = itemId;
#endif
#endif
#endif

#ifdef PROGRAM_ENTITIES
    // Hurt flash / creeper flash.
    albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
#endif

    float emission;
    float smoothness;
    float metalness;
    getMaterial(id, albedo.rgb, emission, smoothness, metalness);
    if (isGlassDrop) smoothness = 0.9;

#ifdef PROGRAM_ENTITIES
    if (entityId == 10001) {
        // Lightning bolt: pure light.
        albedo.rgb = vec3(0.75, 0.85, 1.0);
        emission = 1.0;
    } else if (entityId == 10002) {
        // End crystal: the bright core glows and lights its tower.
        emission = max(emission, smoothstep(0.45, 0.9, maxOf(albedo.rgb)) * 0.8);
    }
#endif

    bool isPortal = false;
#ifdef PROGRAM_BLOCK
    if (blockEntityId == 10060 || blockEntityId == 10062) {
        // Stored gamma encoded; the lighting pass shows it as is, with no shading on top.
        vec3 portal = endPortalColor(scenePos + cameraPosition, normalize(scenePos), normal);
        albedo.rgb = sqrt(saturate(portal));
        emission = 0.0;
        smoothness = 0.0;
        metalness = 0.0;
        id = blockEntityId == 10062 ? MAT_END_GATEWAY : MAT_END_PORTAL;
        isPortal = true;
    }
#endif

#ifdef PBR_TEXTURES
    // Resource pack material maps (labPBR 1.3). Without such a pack the loader binds
    // neutral textures (flat normal, zero specular), which leave everything unchanged.
    if (!isGlassDrop && !isPortal) {
        vec4 normalTex = textureGrad(normals, coord, dcdx, dcdy);
        vec4 specularTex = textureGrad(specular, coord, dcdx, dcdy);

        vec2 slope = normalTex.xy * 2.0 - 1.0;
        float slopeLength2 = dot(slope, slope);
        // A real normal map is never fully white or black in RG; that guards against
        // unexpected placeholder textures.
        if (hasBasis && slopeLength2 > 1e-5 && slopeLength2 < 1.0) {
            normal = normalize(tangent * slope.x + bitangent * slope.y + normal * sqrt(1.0 - slopeLength2));
            ao *= mix(1.0, normalTex.b, step(0.001, normalTex.b));
        }

        smoothness = max(smoothness, specularTex.r);
        if (specularTex.g > 0.898) metalness = 1.0;
        if (specularTex.a > 0.0 && specularTex.a < 0.999) emission = max(emission, specularTex.a);
    }
#endif

    // Alpha is forced to 1 so that blending (enabled for some entity layers) replaces
    // the previous gbuffer contents instead of mixing encoded data.
    outAlbedo = vec4(albedo.rgb, 1.0);
    outNormal = vec4(encodeNormal(normal), float(id) / 255.0, 1.0);
    outLight = vec4(lmCoord, ao, 1.0);
    outMaterial = vec4(emission, smoothness, metalness, 1.0);
}

#endif
