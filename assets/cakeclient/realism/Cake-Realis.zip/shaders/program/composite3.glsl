// =============================================================================
//  composite3: bloom. Seven progressively smaller, gaussian blurred copies of
//  the scene are packed into one atlas (colortex7). The final pass adds them
//  back, giving a wide, energy conserving glow around bright pixels.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;

const bool colortex0MipmapEnabled = true;

in vec2 texCoord;

/* RENDERTARGETS: 7 */
layout(location = 0) out vec4 outBloom;

const float bloomWeights[5] = float[5](0.0625, 0.25, 0.375, 0.25, 0.0625);

vec3 bloomTile(float lod, vec2 offset) {
    float scale = exp2(lod);
    vec2 pixelSize = 1.0 / vec2(viewWidth, viewHeight);
    vec2 uv = (texCoord - offset) * scale;
    vec2 padding = pixelSize * scale * 2.0;
    if (uv.x < -padding.x || uv.y < -padding.y || uv.x > 1.0 + padding.x || uv.y > 1.0 + padding.y) {
        return vec3(0.0);
    }

    vec3 sum = vec3(0.0);
    for (int y = 0; y < 5; y++) {
        for (int x = 0; x < 5; x++) {
            vec2 tap = uv + vec2(float(x - 2), float(y - 2)) * pixelSize * scale;
            vec3 c = textureLod(colortex0, clamp(tap, 0.0, 1.0), lod - 1.0).rgb;
            sum += min(c, vec3(64.0)) * (bloomWeights[x] * bloomWeights[y]);
        }
    }
    return sum;
}

void main() {
    vec3 bloom = bloomTile(1.0, vec2(0.0, 0.0))
               + bloomTile(2.0, vec2(0.51, 0.0))
               + bloomTile(3.0, vec2(0.51, 0.26))
               + bloomTile(4.0, vec2(0.645, 0.26))
               + bloomTile(5.0, vec2(0.7175, 0.26))
               + bloomTile(6.0, vec2(0.645, 0.3325))
               + bloomTile(7.0, vec2(0.670625, 0.3325));
    outBloom = vec4(bloom, 1.0);
}
