// =============================================================================
//  Block breaking cracks. The game draws them with multiplicative blending.
//  Depending on the loader and game version they arrive either before the
//  deferred passes or after them, so the cracks are written to both places:
//    colortex4 - the gbuffer albedo (before lighting: the cracks get lit)
//    colortex0 - the scene color    (after lighting: the cracks darken the image)
//  Before the deferred passes colortex0 is still the empty overlay buffer and a
//  multiplication leaves it empty, so the cracks are never applied twice.
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VSH

out vec2 texCoord;
out vec4 tint;

void main() {
    gl_Position = (gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex);
#ifdef TEMPORAL_AA
    gl_Position.xy += taaJitter() * gl_Position.w;
#endif
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    tint = gl_Color;
}

#endif

#ifdef FSH

uniform sampler2D gtexture;

in vec2 texCoord;
in vec4 tint;

/* RENDERTARGETS: 4,0 */
layout(location = 0) out vec4 outAlbedo;
layout(location = 1) out vec4 outScene;

void main() {
    vec4 color = texture(gtexture, texCoord) * tint;
    // Only the crack texels count; the rest of the texture is transparent.
    if (color.a < 0.1) discard;
    // Alpha is left to the destination (see blend.gbuffers_damagedblock).
    outAlbedo = color;
    outScene = color;
}

#endif
