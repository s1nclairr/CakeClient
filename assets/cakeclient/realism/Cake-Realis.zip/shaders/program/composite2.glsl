// =============================================================================
//  composite2: camera effects that blur the image (the program is disabled when
//  both options are off).
//    DOF          depth of field with autofocus on whatever is at the crosshair
//    MOTION_BLUR  camera motion blur along the reprojection vector
// =============================================================================

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float centerDepthSmooth;

in vec2 texCoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

#ifdef DOF
// Blur radius (fraction of the screen height) for a view distance, thin lens style:
// proportional to the difference of the reciprocal distances.
float circleOfConfusion(float z, float focus) {
    return min(abs(1.0 / focus - 1.0 / z) * 0.035 * DOF_STRENGTH, 0.011);
}
#endif

void main() {
    vec3 color = texelFetch(colortex0, ivec2(gl_FragCoord.xy), 0).rgb;
    float depth = texelFetch(depthtex0, ivec2(gl_FragCoord.xy), 0).r;
    float dither = ditherT(gl_FragCoord.xy);

#ifdef DOF
    // The hand stays sharp, and so does everything while looking at the hand itself.
    if (depth > HAND_DEPTH_LIMIT && centerDepthSmooth > HAND_DEPTH_LIMIT) {
        float focus = max(linearizeDepth(centerDepthSmooth), 1.2);
        float z = linearizeDepth(depth);
        float radius = circleOfConfusion(z, focus);

        if (radius > 0.6 / viewHeight) {
            const int taps = 16;
            vec3 sum = color;
            float weight = 1.0;
            for (int i = 0; i < taps; i++) {
                float r = sqrt((float(i) + 0.5) / float(taps));
                float a = float(i) * 2.39996323 + dither * TAU;
                vec2 uv = texCoord + vec2(cos(a) / aspectRatio, sin(a)) * (r * radius);
                if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) continue;
                float tapDepth = textureLod(depthtex0, uv, 0.0).r;
                if (tapDepth < HAND_DEPTH_LIMIT) continue;
                float tapZ = linearizeDepth(tapDepth);
                // A sharp object in front must not smear over the blurred background.
                float w = tapZ < z - 0.2 ? saturate(circleOfConfusion(tapZ, focus) / radius) : 1.0;
                sum += textureLod(colortex0, uv, 0.0).rgb * w;
                weight += w;
            }
            color = sum / weight;
        }
    }
#endif

#ifdef MOTION_BLUR
    if (depth > HAND_DEPTH_LIMIT) {
        vec3 scenePos = viewToScene(screenToView(texCoord, depth));
        if (depth >= 1.0) scenePos -= cameraPosition - previousCameraPosition;
        vec2 velocity = (texCoord - reprojectScene(scenePos).xy) * (0.5 * MOTION_BLUR_STRENGTH);
        // Limit the blur length so fast turns stay readable.
        float len = length(velocity);
        if (len > 0.04) velocity *= 0.04 / len;

        const int samples = 6;
        vec3 sum = color;
        float weight = 1.0;
        for (int i = 0; i < samples; i++) {
            vec2 uv = texCoord + velocity * ((float(i) + dither) / float(samples) - 0.5);
            if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) continue;
            // Never smear the hand over the world.
            if (textureLod(depthtex0, uv, 0.0).r < HAND_DEPTH_LIMIT) continue;
            sum += textureLod(colortex0, uv, 0.0).rgb;
            weight += 1.0;
        }
        color = sum / weight;
    }
#endif

    outColor = vec4(color, 1.0);
}
