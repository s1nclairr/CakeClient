#version 130
#define OVERWORLD
#define FSH
#include "/program/deferred_gi.glsl"
