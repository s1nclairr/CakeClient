#version 130
#define OVERWORLD
#define VSH
#define PROGRAM_HAND
#include "/program/gbuffers_solid.glsl"
