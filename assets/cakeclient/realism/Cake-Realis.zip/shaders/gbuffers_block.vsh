#version 130
#define OVERWORLD
#define VSH
#define PROGRAM_BLOCK
#include "/program/gbuffers_solid.glsl"
