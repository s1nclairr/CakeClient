#version 130
#define NETHER
#define VSH
#define PROGRAM_HAND
#include "/program/gbuffers_solid.glsl"
