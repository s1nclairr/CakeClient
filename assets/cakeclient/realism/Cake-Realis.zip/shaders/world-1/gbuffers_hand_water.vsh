#version 130
#define NETHER
#define VSH
#define PROGRAM_HAND_WATER
#include "/program/gbuffers_translucent.glsl"
