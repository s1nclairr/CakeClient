#version 130
#define NETHER
#define VSH
#define MISC_GLINT
#include "/program/gbuffers_misc.glsl"
