#version 130
#define NETHER
#define FSH
#define PROGRAM_HAND_WATER
#include "/program/gbuffers_translucent.glsl"
