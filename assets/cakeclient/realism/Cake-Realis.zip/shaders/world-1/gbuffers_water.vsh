#version 130
#define NETHER
#define VSH
#define PROGRAM_WATER
#include "/program/gbuffers_translucent.glsl"
