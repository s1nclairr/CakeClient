#version 130
#define NETHER
#define FSH
#define MISC_GLINT
#include "/program/gbuffers_misc.glsl"
