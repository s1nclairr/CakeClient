#version 130
#define NETHER
#define VSH
#define PROGRAM_ENTITIES_TRANSLUCENT
#include "/program/gbuffers_translucent.glsl"
