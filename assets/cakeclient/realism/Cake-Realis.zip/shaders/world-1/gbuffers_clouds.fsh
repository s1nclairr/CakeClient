#version 130
#define NETHER
#define FSH
#define MISC_DISCARD
#include "/program/gbuffers_misc.glsl"
