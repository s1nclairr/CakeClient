#version 130
#define NETHER
#define VSH
#define MISC_DISCARD
#include "/program/gbuffers_misc.glsl"
