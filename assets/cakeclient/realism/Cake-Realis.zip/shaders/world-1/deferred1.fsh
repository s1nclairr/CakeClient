#version 130
#define NETHER
#define FSH
#include "/program/deferred_gi.glsl"
