#version 130
#define NETHER
#define VSH
#define PROGRAM_ENTITIES
#include "/program/gbuffers_solid.glsl"
