#version 130
#define NETHER
#define FSH
#define PROGRAM_ENTITIES
#include "/program/gbuffers_solid.glsl"
