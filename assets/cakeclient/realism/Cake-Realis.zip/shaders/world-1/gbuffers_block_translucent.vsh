#version 130
#define NETHER
#define VSH
#define PROGRAM_BLOCK_TRANSLUCENT
#include "/program/gbuffers_translucent.glsl"
