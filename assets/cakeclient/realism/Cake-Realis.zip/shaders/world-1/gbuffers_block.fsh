#version 130
#define NETHER
#define FSH
#define PROGRAM_BLOCK
#include "/program/gbuffers_solid.glsl"
