#version 130
#define NETHER
#define FSH
#define PROGRAM_WATER
#include "/program/gbuffers_translucent.glsl"
