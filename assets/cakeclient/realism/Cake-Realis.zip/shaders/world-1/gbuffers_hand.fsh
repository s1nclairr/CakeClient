#version 130
#define NETHER
#define FSH
#define PROGRAM_HAND
#include "/program/gbuffers_solid.glsl"
