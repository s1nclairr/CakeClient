#version 130
#define NETHER
#define FSH
#define PROGRAM_BLOCK_TRANSLUCENT
#include "/program/gbuffers_translucent.glsl"
