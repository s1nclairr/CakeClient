#version 130
#define NETHER
#define VSH
#define PROGRAM_BLOCK
#include "/program/gbuffers_solid.glsl"
