#version 130
#define NETHER
#define FSH
#define PROGRAM_TERRAIN
#include "/program/gbuffers_solid.glsl"
