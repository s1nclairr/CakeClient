#version 130
#define OVERWORLD
#define VSH
#define PROGRAM_ENTITIES
#include "/program/gbuffers_solid.glsl"
