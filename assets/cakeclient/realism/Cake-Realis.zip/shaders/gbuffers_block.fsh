#version 130
#define OVERWORLD
#define FSH
#define PROGRAM_BLOCK
#include "/program/gbuffers_solid.glsl"
