#version 130
#define OVERWORLD
#define VSH
#include "/program/gbuffers_damage.glsl"
