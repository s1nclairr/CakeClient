#version 130
#define OVERWORLD
#define FSH
#define PROGRAM_HAND
#include "/program/gbuffers_solid.glsl"
